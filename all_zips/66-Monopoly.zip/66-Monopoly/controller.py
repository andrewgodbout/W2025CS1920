import csv
import os
import view
import random
import gameboard
import player as plr
import gamesquare
import observer
import tkinter.simpledialog as simpledialog
import datetime




class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")


    def _create_players(self, num_players):
        """Create players with custom names and tokens"""
        players = []
        token_choices = ["🐶", "🚗", "🧢", "🎩", "🐱", "🛩️"]
        used_tokens = []

        for i in range(num_players):
            name = simpledialog.askstring("Player Name", f"Enter name for Player {i + 1}:")
            if not name:
                name = f"Player {i + 1}"


            token = None
            while token not in token_choices or token in used_tokens:
                token = simpledialog.askstring("Token", f"Pick your token {token_choices} (one emoji):")
                if token in used_tokens:
                    print("That token is already taken.")
                if token not in token_choices:
                    print("Invalid token.")

            used_tokens.append(token)

            player = plr.Player(name, 1500)
            player.token = token
            players.append(player)

        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:

            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self._log_event(f"{self._gameboard.get_current_player().name} rolled doubles: {dice1} + {dice2}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
            self._log_event(f"{self._gameboard.get_current_player().name} rolled {dice1} + {dice2} = {dice_sum}")

        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        player = self._gameboard.get_current_player()
        if self.__dice_rolled:

            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        if player.in_jail:
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            observer.Event("update_state", f"In Jail - Rolled: {dice1} + {dice2}")
            if dice1 == dice2:
                player.in_jail = False
                observer.Event("update_state", f"{player.name} rolled doubles and got out of jail!")
            else:
                player.jail_turns += 1
                if player.jail_turns >= 3:
                    player.in_jail = False
                    player.money -= 50
                    observer.Event("update_state", f"{player.name} paid $50 after 3 turns and is out of jail.")
                else:
                    observer.Event("update_state", f"{player.name} stays in jail (Turn {player.jail_turns}/3)")
                    return False

        dice_sum = self._roll_dice()


        #moving the player
        player.move(dice_sum)
        self._log_event(f"{player.name} moved to position {player.position}")

        position = player.position
        square = self._gameboard.get_square(position)
        # Checking Community Chest
        if square.space == "Chance":
            self._draw_card("Chance")
        elif square.space == "Chest":
            self._draw_card("Chest")

        # checking if square is "GotoJail"
        if square.space == "GotoJail":
            player.in_jail = True
            player.jail_turns = 0
            player.position = 10  # Jail position
            observer.Event("update_state", f"{player.name} was sent to Jail!")
            self._log_event(f"{player.name} was sent to Jail.")
            return True


        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")
            self._log_event(f"{player.name} paid rent: ${rent}")

        #no money left
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties

        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    def _draw_card(self, type_):
        filename = "chance_cards.txt" if type_ == "Chance" else "community_chest.txt"
        path = os.path.join("resources", "text_docs", filename)

        with open(path, "r") as f:
            cards = list(csv.reader(f))
        card = random.choice(cards)
        message, action, value = card[0], card[1], card[2] if len(card) > 2 else None

        observer.Event("update_state", f"Card Drawn: {message}")
        player = self._gameboard.get_current_player()
        self._log_event(f"{player.name} drew a {type_} card: {message}")

        player = self._gameboard.get_current_player()

        if action == "money":
            player.money += int(value)
            observer.Event("update_state", f"{player.name} {'gains' if int(value) > 0 else 'loses'} ${abs(int(value))}")
            self._log_event(f"{player.name} {'gained' if int(value) > 0 else 'lost'} ${abs(int(value))}")

        elif action == "move":
            player.position = int(value)
            observer.Event("update_state", f"{player.name} moves to tile {value}")
            self._log_event(f"{player.name} {'gained' if int(value) > 0 else 'lost'} ${abs(int(value))}")

        elif action == "jail":
            player.in_jail = True
            player.jail_turns = 0
            player.position = 10
            observer.Event("update_state", f"{player.name} was sent to Jail!")
            self._log_event(f"{player.name} {'gained' if int(value) > 0 else 'lost'} ${abs(int(value))}")

    def _log_event(self, msg):
        log_path = os.path.join("resources", "logs", "game_log.txt")
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a") as f:
            f.write(f"[{timestamp}] {msg}\n")


