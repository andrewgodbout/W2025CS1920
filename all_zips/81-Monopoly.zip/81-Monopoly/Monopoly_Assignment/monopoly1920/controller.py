import os
import view
import random
import gameboard
import player as plr
import gamesquare
import observer
import tkinter.simpledialog as simpledialog


class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)
        self._root = root  # Store root reference for restarting
        self._initialize_game()

    def _initialize_game(self):
        """Initialize or reinitialize the game state"""
        csv_path = os.path.join("resources", "data", "board.csv")
        self.players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, self.players)

        self._add_listeners()

        self.__dice_rolled = False
        self.__roll_count = 0
        self.__doubles_count = 0
        self.__last_was_double = False

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("restart_game", self._restart_game)  # Add restart listener

    def _restart_game(self, data):
        """Handle game restart"""
        # Reinitialize the game state
        self._initialize_game()
        observer.Event("update_state", "Game has been restarted!")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player_name = simpledialog.askstring(f"Player {i + 1}", f"Enter Player {i + 1}'s name:")
            if player_name:
                player = plr.Player(player_name, 1500)
            else:
                player = plr.Player(f"Player {i + 1}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        player.luck += ev

    def _roll_dice(self):
        """Simulate rolling of two dice"""
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__roll_count += 1

        if dice1 == dice2:
            self.__last_was_double = True
            self.__doubles_count += 1
            self.__dice_rolled = False  # Allow another roll
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum} - Roll again!")
        else:
            self.__last_was_double = False
            self.__dice_rolled = True  # Prevent further rolls
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Handle the roll dice button click event"""
        if self.__dice_rolled and not self.__last_was_double:
            observer.Event("update_state", "You can only roll again after doubles")
            return False

        player = self._gameboard.get_current_player()

        # Check for 3 doubles (go to jail)
        if self.__doubles_count >= 3:
            observer.Event("update_state", "Three doubles! Go to jail!")
            player.go_to_jail()
            self.__doubles_count = 0
            self.__dice_rolled = True
            return True

        dice_sum = self._roll_dice()
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return

        # Reset all roll tracking variables
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__doubles_count = 0
        self.__last_was_double = False

        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        self._set_expected_val()

    def _buy_square(self, data):
        """Try to buy the square the active player is currently on"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return

        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Unmortgage a property (FIFO order)"""
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        """Roll the dice and handle game events"""
        player = self._gameboard.get_current_player()

        # Only prevent rolling if we've already rolled and it wasn't a double
        if self.__dice_rolled and not self.__last_was_double:
            observer.Event("update_state", "You can only roll again after doubles")
            return

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)