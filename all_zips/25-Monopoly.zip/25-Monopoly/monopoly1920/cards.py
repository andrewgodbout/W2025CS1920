import random
import observer

class Card:
    """Base class for Chance and Community Chest cards"""
    def __init__(self, title, description, action):
        self.title = title
        self.description = description
        self.action = action
    
    def execute(self, player, gameboard):
        """Execute the card's action"""
        return self.action(player, gameboard)
    
    def __str__(self):
        return f"{self.title}: {self.description}"

class CardDeck:
    """Class to represent a deck of cards (Chance or Community Chest)"""
    def __init__(self, card_type):
        self.card_type = card_type  # "Chance" or "Community Chest"
        self.cards = []
        self.initialize_cards()
        self.shuffle()
    
    def initialize_cards(self):
        """Initialize the cards in the deck"""
        if self.card_type == "Chance":
            self._initialize_chance_cards()
        else:  # Community Chest
            self._initialize_community_chest_cards()
    
    def _initialize_chance_cards(self):
        """Initialize the Chance cards"""
        # Advance to Go
        self.cards.append(Card(
            "Advance to Go", 
            "Advance to Go. Collect $200.", 
            lambda player, gameboard: self._advance_to_go(player, gameboard)
        ))
        
        # Advance to Illinois Avenue
        self.cards.append(Card(
            "Advance to Illinois Avenue", 
            "Advance to Illinois Avenue. If you pass Go, collect $200.", 
            lambda player, gameboard: self._advance_to_position(player, gameboard, 24)
        ))
        
        # Advance to St. Charles Place
        self.cards.append(Card(
            "Advance to St. Charles Place", 
            "Advance to St. Charles Place. If you pass Go, collect $200.", 
            lambda player, gameboard: self._advance_to_position(player, gameboard, 11)
        ))
        
        # Advance to nearest Railroad
        self.cards.append(Card(
            "Advance to nearest Railroad", 
            "Advance to the nearest Railroad. If unowned, you may buy it from the Bank. If owned, pay owner twice the rental.", 
            lambda player, gameboard: self._advance_to_nearest_railroad(player, gameboard)
        ))
        
        # Advance to nearest Utility
        self.cards.append(Card(
            "Advance to nearest Utility", 
            "Advance to the nearest Utility. If unowned, you may buy it from the Bank. If owned, throw dice and pay owner 10 times the amount thrown.", 
            lambda player, gameboard: self._advance_to_nearest_utility(player, gameboard)
        ))
        
        # Bank pays you dividend of $50
        self.cards.append(Card(
            "Bank pays you dividend", 
            "Bank pays you dividend of $50.", 
            lambda player, gameboard: self._collect_money(player, 50)
        ))
        
        # Get out of Jail Free
        self.cards.append(Card(
            "Get out of Jail Free", 
            "Get out of Jail Free. This card may be kept until needed or sold.", 
            lambda player, gameboard: self._get_out_of_jail_free(player)
        ))
        
        # Go back 3 spaces
        self.cards.append(Card(
            "Go back 3 spaces", 
            "Go back 3 spaces.", 
            lambda player, gameboard: self._go_back_spaces(player, gameboard, 3)
        ))
        
        # Go to Jail
        self.cards.append(Card(
            "Go to Jail", 
            "Go directly to Jail. Do not pass Go, do not collect $200.", 
            lambda player, gameboard: self._go_to_jail(player, gameboard)
        ))
        
        # Make general repairs on all your property
        self.cards.append(Card(
            "Property repairs", 
            "Make general repairs on all your property. For each house pay $25, for each hotel pay $100.", 
            lambda player, gameboard: self._property_repairs(player, 25, 100)
        ))
        
        # Pay poor tax of $15
        self.cards.append(Card(
            "Pay poor tax", 
            "Pay poor tax of $15.", 
            lambda player, gameboard: self._pay_money(player, 15)
        ))
        
        # Take a trip to Reading Railroad
        self.cards.append(Card(
            "Take a trip to Reading Railroad", 
            "Take a trip to Reading Railroad. If you pass Go, collect $200.", 
            lambda player, gameboard: self._advance_to_position(player, gameboard, 5)
        ))
        
        # Take a walk on the Boardwalk
        self.cards.append(Card(
            "Take a walk on the Boardwalk", 
            "Take a walk on the Boardwalk. Advance to Boardwalk.", 
            lambda player, gameboard: self._advance_to_position(player, gameboard, 39)
        ))
        
        # You have been elected Chairman of the Board
        self.cards.append(Card(
            "Chairman of the Board", 
            "You have been elected Chairman of the Board. Pay each player $50.", 
            lambda player, gameboard: self._pay_each_player(player, gameboard, 50)
        ))
        
        # Your building loan matures
        self.cards.append(Card(
            "Building loan matures", 
            "Your building loan matures. Collect $150.", 
            lambda player, gameboard: self._collect_money(player, 150)
        ))
    
    def _initialize_community_chest_cards(self):
        """Initialize the Community Chest cards"""
        # Advance to Go
        self.cards.append(Card(
            "Advance to Go", 
            "Advance to Go. Collect $200.", 
            lambda player, gameboard: self._advance_to_go(player, gameboard)
        ))
        
        # Bank error in your favor
        self.cards.append(Card(
            "Bank error in your favor", 
            "Bank error in your favor. Collect $200.", 
            lambda player, gameboard: self._collect_money(player, 200)
        ))
        
        # Doctor's fee
        self.cards.append(Card(
            "Doctor's fee", 
            "Doctor's fee. Pay $50.", 
            lambda player, gameboard: self._pay_money(player, 50)
        ))
        
        # From sale of stock
        self.cards.append(Card(
            "From sale of stock", 
            "From sale of stock you get $50.", 
            lambda player, gameboard: self._collect_money(player, 50)
        ))
        
        # Get out of Jail Free
        self.cards.append(Card(
            "Get out of Jail Free", 
            "Get out of Jail Free. This card may be kept until needed or sold.", 
            lambda player, gameboard: self._get_out_of_jail_free(player)
        ))
        
        # Go to Jail
        self.cards.append(Card(
            "Go to Jail", 
            "Go directly to Jail. Do not pass Go, do not collect $200.", 
            lambda player, gameboard: self._go_to_jail(player, gameboard)
        ))
        
        # Grand Opera Night
        self.cards.append(Card(
            "Grand Opera Night", 
            "Grand Opera Night. Collect $50 from every player for opening night seats.", 
            lambda player, gameboard: self._collect_from_each_player(player, gameboard, 50)
        ))
        
        # Holiday Fund matures
        self.cards.append(Card(
            "Holiday Fund matures", 
            "Holiday Fund matures. Receive $100.", 
            lambda player, gameboard: self._collect_money(player, 100)
        ))
        
        # Income tax refund
        self.cards.append(Card(
            "Income tax refund", 
            "Income tax refund. Collect $20.", 
            lambda player, gameboard: self._collect_money(player, 20)
        ))
        
        # It is your birthday
        self.cards.append(Card(
            "It is your birthday", 
            "It is your birthday. Collect $10 from every player.", 
            lambda player, gameboard: self._collect_from_each_player(player, gameboard, 10)
        ))
        
        # Life insurance matures
        self.cards.append(Card(
            "Life insurance matures", 
            "Life insurance matures. Collect $100.", 
            lambda player, gameboard: self._collect_money(player, 100)
        ))
        
        # Hospital Fees
        self.cards.append(Card(
            "Hospital Fees", 
            "Pay hospital fees of $100.", 
            lambda player, gameboard: self._pay_money(player, 100)
        ))
        
        # School fees
        self.cards.append(Card(
            "School fees", 
            "Pay school fees of $50.", 
            lambda player, gameboard: self._pay_money(player, 50)
        ))
        
        # Receive consultancy fee
        self.cards.append(Card(
            "Receive consultancy fee", 
            "Receive $25 consultancy fee.", 
            lambda player, gameboard: self._collect_money(player, 25)
        ))
        
        # Street repairs
        self.cards.append(Card(
            "Street repairs", 
            "You are assessed for street repairs. $40 per house, $115 per hotel.", 
            lambda player, gameboard: self._property_repairs(player, 40, 115)
        ))
        
        # You have won second prize in a beauty contest
        self.cards.append(Card(
            "Beauty contest", 
            "You have won second prize in a beauty contest. Collect $10.", 
            lambda player, gameboard: self._collect_money(player, 10)
        ))
        
        # You inherit
        self.cards.append(Card(
            "You inherit", 
            "You inherit $100.", 
            lambda player, gameboard: self._collect_money(player, 100)
        ))
    
    def shuffle(self):
        """Shuffle the deck of cards"""
        random.shuffle(self.cards)
    
    def draw(self):
        """Draw a card from the deck"""
        if not self.cards:
            self.initialize_cards()
            self.shuffle()
        
        card = self.cards.pop(0)
        # If it's not a "keep" card (like Get out of Jail Free), put it at the bottom of the deck
        if card.title != "Get out of Jail Free":
            self.cards.append(card)
        return card
    
    # Card actions
    def _advance_to_go(self, player, gameboard):
        """Advance to Go and collect $200"""
        old_position = player.position
        player.position = 0
        player.collect(200)
        observer.Event("update_state", f"{player.name} advances to Go and collects $200")
        return True
    
    def _advance_to_position(self, player, gameboard, position):
        """Advance to a specific position"""
        old_position = player.position
        # If the new position is behind the current position, player passed Go
        if position < old_position:
            player.collect(200)
            observer.Event("update_state", f"{player.name} passes Go and collects $200")
        
        player.position = position
        square = gameboard.get_square(position)
        observer.Event("update_state", f"{player.name} advances to {square.name}")
        return True
    
    def _advance_to_nearest_railroad(self, player, gameboard):
        """Advance to the nearest Railroad"""
        position = player.position
        # Railroad positions are 5, 15, 25, 35
        if position < 5:
            new_position = 5
        elif position < 15:
            new_position = 15
        elif position < 25:
            new_position = 25
        elif position < 35:
            new_position = 35
        else:
            new_position = 5  # Wrap around to Reading Railroad
            player.collect(200)  # Passed Go
            observer.Event("update_state", f"{player.name} passes Go and collects $200")
        
        player.position = new_position
        square = gameboard.get_square(new_position)
        observer.Event("update_state", f"{player.name} advances to {square.name}")
        
        # If owned, pay twice the rent
        if square.owner and square.owner != player:
            # Double the rent for railroads when landing via Chance card
            rent = square.calculate_rent_or_tax(0) * 2
            player.money -= rent
            square.owner.money += rent
            observer.Event("update_state", f"{player.name} pays {square.owner.name} ${rent} (double rent)")
        
        return True
    
    def _advance_to_nearest_utility(self, player, gameboard):
        """Advance to the nearest Utility"""
        position = player.position
        # Utility positions are 12 (Electric Company) and 28 (Water Works)
        if position < 12 or position > 28:
            new_position = 12
        else:
            new_position = 28
        
        # Check if passed Go
        if new_position < position:
            player.collect(200)
            observer.Event("update_state", f"{player.name} passes Go and collects $200")
        
        player.position = new_position
        square = gameboard.get_square(new_position)
        observer.Event("update_state", f"{player.name} advances to {square.name}")
        
        # If owned, pay 10 times the dice roll
        if square.owner and square.owner != player:
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            dice_sum = dice1 + dice2
            rent = 10 * dice_sum
            player.money -= rent
            square.owner.money += rent
            observer.Event("update_state", f"{player.name} rolls {dice_sum} and pays {square.owner.name} ${rent} (10 times dice)")
        
        return True
    
    def _collect_money(self, player, amount):
        """Collect money from the bank"""
        player.collect(amount)
        observer.Event("update_state", f"{player.name} collects ${amount}")
        return True
    
    def _pay_money(self, player, amount):
        """Pay money to the bank"""
        player.money -= amount
        observer.Event("update_state", f"{player.name} pays ${amount}")
        return True
    
    def _get_out_of_jail_free(self, player):
        """Get out of Jail Free card"""
        player.jail_free_cards += 1
        observer.Event("update_state", f"{player.name} gets a Get Out of Jail Free card")
        return True
    
    def _go_back_spaces(self, player, gameboard, spaces):
        """Go back a number of spaces"""
        old_position = player.position
        new_position = (old_position - spaces) % 40
        player.position = new_position
        square = gameboard.get_square(new_position)
        observer.Event("update_state", f"{player.name} goes back {spaces} spaces to {square.name}")
        return True
    
    def _go_to_jail(self, player, gameboard):
        """Go to Jail"""
        player.go_to_jail()
        observer.Event("update_state", f"{player.name} goes to Jail")
        return True
    
    def _property_repairs(self, player, house_cost, hotel_cost):
        """Pay for property repairs"""
        # In a real implementation, we would count houses and hotels
        # For now, we'll just charge a flat fee
        player.money -= 50
        observer.Event("update_state", f"{player.name} pays $50 for property repairs")
        return True
    
    def _pay_each_player(self, player, gameboard, amount):
        """Pay each player"""
        total = 0
        for other_player in gameboard.get_all_players():
            if other_player != player and not other_player.bankrupt_declared:
                player.money -= amount
                other_player.money += amount
                total += amount
        
        observer.Event("update_state", f"{player.name} pays ${total} to other players")
        return True
    
    def _collect_from_each_player(self, player, gameboard, amount):
        """Collect from each player"""
        total = 0
        for other_player in gameboard.get_all_players():
            if other_player != player and not other_player.bankrupt_declared:
                other_player.money -= amount
                player.money += amount
                total += amount
        
        observer.Event("update_state", f"{player.name} collects ${total} from other players")
        return True
