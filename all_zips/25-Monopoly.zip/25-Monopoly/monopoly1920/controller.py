import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        # Get the directory where the script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        csv_path = os.path.join(script_dir, "resources", "data", "board.csv")
        self._num_players = 3
        self._player_names = self._get_player_names()
        players = self._create_players(self._num_players)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("pay_jail", self._pay_jail_fee)
        self.observe("use_jail_card", self._use_jail_card)
        self.observe("set_player_name", self._set_player_name)
        self.observe("set_player_token", self._set_player_token)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _get_player_names(self):
        """Get custom player names or use defaults"""
        return [f"Player {i}" for i in range(self._num_players)]
        
    def _set_player_name(self, data):
        """Set a player's name"""
        player_index, new_name = data
        if 0 <= player_index < self._num_players:
            self._player_names[player_index] = new_name
            observer.Event("update_state", f"Player {player_index} renamed to {new_name}")
            
    def _set_player_token(self, data):
        """Set a player's token"""
        player_index, token = data
        player = self._gameboard.get_current_player()
        player.token = token
        observer.Event("update_state", f"{player.name} selected token: {token}")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(self._player_names[i], 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values and a tuple of the dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum, (dice1, dice2)

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        player = self._gameboard.get_current_player()
        
        # Check if player is in jail
        if player.in_jail:
            dice_sum, (dice1, dice2) = self._roll_dice()
            # Try to leave jail by rolling doubles
            if player.attempt_to_leave_jail(dice1, dice2):
                # If player got out of jail with doubles, they can move
                if dice1 == dice2:
                    player.move(dice_sum)
                    position = player.position
                    square = self._gameboard.get_square(position)
                    
                    # Handle special squares
                    self._gameboard.handle_special_squares(player, position)
                    
                    # Pay rent if applicable
                    rent = player.pay_rent(square, dice_sum)
                    if rent != 0:
                        print(f"rent paid: {rent}")
                        player.luck -= rent
                        observer.Event("update_state", f"Rent paid: {rent}")
                    
                    # Check for bankruptcy
                    if player.money < 0:
                        player.declare_bankrupt()
                    
                    return True
            return False

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum, (dice1, dice2) = self._roll_dice()
        
        # Check for three doubles in a row
        if dice1 == dice2:
            player.doubles_count += 1
            if player.doubles_count >= 3:
                observer.Event("update_state", f"{player.name} rolled doubles 3 times in a row and goes to jail!")
                player.go_to_jail()
                player.doubles_count = 0
                return False
        else:
            player.doubles_count = 0

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)
        
        # Handle special squares (Chance, Community Chest, Go to Jail)
        self._gameboard.handle_special_squares(player, position)
        
        # If player was sent to jail, don't process rent
        if player.in_jail:
            return False

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        player = self._gameboard.get_current_player()

        if player.in_jail:
            # Player in jail can end their turn without rolling
            self.__dice_rolled = False
            self.__roll_count = 0
            player.doubles_count = 0
            player_name = self._gameboard.next_turn()
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", self._gameboard.get_current_player().position)
            callback()
            observer.Event("update_state", f"{player_name}'s turn")
            self._set_expected_val()
            return

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player.doubles_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))
            
    def _pay_jail_fee(self, data):
        """Pay the jail fee to get out of jail"""
        player = self._gameboard.get_current_player()
        if player.pay_to_leave_jail():
            observer.Event("update_state_box", str(self._gameboard))
        
    def _use_jail_card(self, data):
        """Use a Get Out of Jail Free card"""
        player = self._gameboard.get_current_player()
        if player.use_jail_free_card():
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
