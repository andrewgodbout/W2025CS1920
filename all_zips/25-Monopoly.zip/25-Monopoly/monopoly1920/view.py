import tkinter as tk
import os
from tkinter import ttk, simpledialog
import controller
import observer


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    # Get the directory where the script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    square_images = []
    for i in range(40):
        path = os.path.join(script_dir, "resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        # Get the directory where the script is located
        self.script_dir = os.path.dirname(os.path.abspath(__file__))

        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()
        
        # Show player setup dialog
        self._show_player_setup()

        #self.setup_game()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        
    def _show_player_setup(self):
        """Show dialog to set up player names and tokens"""
        setup_window = tk.Toplevel(self.root)
        setup_window.title("Player Setup")
        setup_window.geometry("400x300")
        
        # Create a frame for player setup
        setup_frame = ttk.Frame(setup_window, padding=10)
        setup_frame.pack(fill=tk.BOTH, expand=True)
        
        # Player name entries
        ttk.Label(setup_frame, text="Player Names:").grid(row=0, column=0, sticky="w", pady=5)
        
        name_entries = []
        for i in range(3):  # Assuming 3 players
            ttk.Label(setup_frame, text=f"Player {i}:").grid(row=i+1, column=0, sticky="w", pady=2)
            entry = ttk.Entry(setup_frame, width=20)
            entry.insert(0, f"Player {i}")
            entry.grid(row=i+1, column=1, sticky="w", pady=2)
            name_entries.append(entry)
        
        # Token selection
        ttk.Label(setup_frame, text="Select Tokens:").grid(row=4, column=0, sticky="w", pady=5)
        
        tokens = ["Car", "Dog", "Hat", "Ship", "Shoe", "Thimble"]
        token_vars = []
        
        for i in range(3):  # Assuming 3 players
            ttk.Label(setup_frame, text=f"Player {i}:").grid(row=i+5, column=0, sticky="w", pady=2)
            token_var = tk.StringVar(value=tokens[i % len(tokens)])
            token_menu = ttk.Combobox(setup_frame, textvariable=token_var, values=tokens, width=10)
            token_menu.grid(row=i+5, column=1, sticky="w", pady=2)
            token_vars.append(token_var)
        
        # Start game button
        def start_game():
            # Set player names
            for i, entry in enumerate(name_entries):
                observer.Event("set_player_name", (i, entry.get()))
            
            # Set player tokens
            for i, token_var in enumerate(token_vars):
                observer.Event("set_player_token", (i, token_var.get()))
                
            setup_window.destroy()
        
        start_button = ttk.Button(setup_frame, text="Start Game", command=start_game)
        start_button.grid(row=8, column=0, columnspan=2, pady=10)


    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image_path = os.path.join(self.script_dir, "resources", "images", "monopoly.png")
        try:
            board_image = tk.PhotoImage(file=board_image_path)
            board = ttk.Label(middle_frame, image=board_image)
            board.pack(side='left', anchor='n', padx=75)
            board.image = board_image
        except Exception as e:
            print(f"Error loading board image: {e}")
            # Create a placeholder label if image can't be loaded
            board = ttk.Label(middle_frame, text="Monopoly Board", width=50, height=20)
            board.pack(side='left', anchor='n', padx=75)

        # preload all the images for the board squares
        self._preload_images()

        # Use a placeholder if no images were loaded
        if not self.images:
            card_image = None
            self.card = ttk.Label(middle_frame, text="Property Card", width=20, height=10)
        else:
            card_image = self.images[0]
            self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)

        #create buttons
        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll") )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)
        
        # Add jail-related buttons
        self.pay_jail_button = ttk.Button(button_frame, text="Pay $50 to Leave Jail", command=lambda: self._action_taken("pay_jail"))
        self.pay_jail_button.pack(side='top', anchor='center', pady=(10, 10))
        self.pay_jail_button.state(['active'])
        self.mid_buttons.append(self.pay_jail_button)
        
        self.use_jail_card_button = ttk.Button(button_frame, text="Use Jail Free Card", command=lambda: self._action_taken("use_jail_card"))
        self.use_jail_card_button.pack(side='top', anchor='center', pady=(10, 10))
        self.use_jail_card_button.state(['active'])
        self.mid_buttons.append(self.use_jail_card_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        if card_image:
            self.card.image = card_image

        return middle_frame

    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))

        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,100))

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image_path = os.path.join(self.script_dir, "resources", "images", "monopoly_logo.png")
        try:
            logo_image = tk.PhotoImage(file=logo_image_path)
            logo = ttk.Label(logo_frame, image=logo_image)
            logo.pack(side='top', anchor='n')
            logo.image = logo_image
        except Exception as e:
            print(f"Error loading logo image: {e}")
            # Create a text label as a fallback
            logo = ttk.Label(logo_frame, text="MONOPOLY", font=("Arial", 24, "bold"))
            logo.pack(side='top', anchor='n')

        return logo_frame

    def _action_taken(self, action):

        if action == "roll":
            #tell the controller roll was clicked
            print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)
            
        if action == "pay_jail":
            observer.Event("pay_jail", None)
            
        if action == "use_jail_card":
            observer.Event("use_jail_card", None)

        if action == "end_turn":
            #self.text_box.delete(1.0, tk.END)
            observer.Event("end_turn", self._clear_text)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        if index < len(self.images) and self.images[index]:
            card_image = self.images[index]
            try:
                self.card['image'] = card_image
                self.card.image = card_image  # Keep a reference
            except:
                pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        #good idea disable all buttons

        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                         command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)



    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            try:
                img = tk.PhotoImage(file=image)
                self.images.append(img)
            except Exception as e:
                # If image can't be loaded, add a placeholder
                print(f"Warning: Could not load image {image}: {e}")
                self.images.append(None)

'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()
