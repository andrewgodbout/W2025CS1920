import gameboard
import gamesquare
import observer


class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0

        # Jail related attributes
        self.__in_jail = False
        self.__jail_turns = 0
        self.__jail_free_cards = 0

        # Token for player representation
        self.__token = "default"

        #big numbers are lucky, negative numbers are unlucky
        self.__luck = 0

        #add a Data structure to track mortgaging order
        self.__mortgaging_order = []

    def __str__(self):
        """String representation of the player"""
        jail_status = " (in jail)" if self.__in_jail else ""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}{jail_status}"

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        
        # Check if owner has a monopoly on this color group (and property is not mortgaged)
        if square.owner is not None and not square.is_mortgaged and not square.is_utility and not square.is_railroad:
            # Check if owner has all properties of this color
            color_properties = [p for p in square.owner.properties if p.color == square.color]
            color_count = len([p for p in square.owner.properties if p.color == square.color])
            
            # If there are 2 or 3 properties in the color group and the owner has all of them
            if color_count >= 2 and color_count == sum(1 for p in square.owner.properties if p.color == square.color):
                # Double the rent for monopoly
                rent *= 2
                observer.Event("update_state", f"Monopoly! Rent doubled to ${rent}")
        
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        # If in jail, don't move
        if self.__in_jail:
            observer.Event("update_state", f"{self.name} is in jail and cannot move")
            return
            
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    def go_to_jail(self):
        """Send player to jail"""
        self.__board_position = 10  # Jail is at position 10
        self.__in_jail = True
        self.__jail_turns = 0
        observer.Event("update_state", f"{self.name} goes to jail")

    def attempt_to_leave_jail(self, dice1, dice2):
        """Attempt to leave jail by rolling doubles or after 3 turns"""
        if not self.__in_jail:
            return True
            
        self.__jail_turns += 1
        
        # Check if player rolled doubles
        if dice1 == dice2:
            self.__in_jail = False
            observer.Event("update_state", f"{self.name} rolled doubles and is out of jail")
            return True
            
        # Check if player has been in jail for 3 turns
        if self.__jail_turns >= 3:
            self.__in_jail = False
            # Pay $50 fine
            self.__money -= 50
            observer.Event("update_state", f"{self.name} pays $50 and is out of jail after 3 turns")
            return True
            
        observer.Event("update_state", f"{self.name} remains in jail (turn {self.__jail_turns} of 3)")
        return False

    def pay_to_leave_jail(self):
        """Pay $50 to leave jail"""
        if not self.__in_jail:
            return False
            
        if self.__money >= 50:
            self.__money -= 50
            self.__in_jail = False
            observer.Event("update_state", f"{self.name} pays $50 to get out of jail")
            return True
        else:
            observer.Event("update_state", f"{self.name} doesn't have enough money to get out of jail")
            return False

    def use_jail_free_card(self):
        """Use a Get Out of Jail Free card"""
        if not self.__in_jail or self.__jail_free_cards <= 0:
            return False
            
        self.__jail_free_cards -= 1
        self.__in_jail = False
        observer.Event("update_state", f"{self.name} uses a Get Out of Jail Free card")
        return True

    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name
        
    @name.setter
    def name(self, name):
        self.__name = name

    @property
    def position(self):
        return self.__board_position
        
    @position.setter
    def position(self, position):
        self.__board_position = position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]
        
    @property
    def in_jail(self):
        return self.__in_jail
        
    @property
    def jail_free_cards(self):
        return self.__jail_free_cards
        
    @jail_free_cards.setter
    def jail_free_cards(self, count):
        self.__jail_free_cards = count
        
    @property
    def token(self):
        return self.__token
        
    @token.setter
    def token(self, token):
        self.__token = token