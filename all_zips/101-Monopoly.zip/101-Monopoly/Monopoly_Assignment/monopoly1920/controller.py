# Change 6 Sounds
import pygame
from pygame import mixer
import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import tkinter
import observer

import pickle

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root,load_existing=False):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        #Change 6 Sound effects
        pygame.init()
        mixer.init()
        self.sounds = {
            'dice_roll': mixer.Sound('resources/sounds/dice_roll.wav'),
            'player_move': mixer.Sound('resources/sounds/player_move.wav')
        }
        self.sounds_muted = False

        self._view = view.View(root)
        self._view.controller = self


        if load_existing and os.path.exists("savegame.pkl"):
            self.load_game()  # Change 1 Load the game from file if it exists
        else:

            csv_path = os.path.join("resources", "data", "board.csv")
            player_names= self._view.prompt_player_names(3)              #Change 2 Players custom name
            players = self._create_players(player_names)
            self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()
        #Change 4
        self._add_chat_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()




    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

        # Change 1 Add save and load game event listeners
        self.observe("save_game", lambda _: self.save_game())
        self.observe("load_game", lambda _: self.load_game())

        #change 6 Sound
        self.observe("toggle_sound", self._toggle_sound)




    def save_game(self):
        """Change 1 Save the game state to a file"""
        try:
            with open("savegame.pkl", "wb") as f:
                pickle.dump(self._gameboard, f)
            observer.Event("update_state", "Game saved successfully!")
        except Exception as e:
            observer.Event("update_state", f"Error saving game: {e}")

    def load_game(self):
        """ Change 1 Load the game state from a file"""
        try:
            with open("savegame.pkl", "rb") as f:
                self._gameboard = pickle.load(f)
            observer.Event("update_state", "Game loaded successfully!")
            observer.Event("update_state_box", str(self._gameboard))
        except Exception as e:
            observer.Event("update_state", f"Error loading game: {e}")

    def _toggle_sound(self, data=None):
        """Change 6 Toggle sound effects on/off"""
        self.sounds_muted = not self.sounds_muted
        volume = 0.0 if self.sounds_muted else 1.0
        for sound in self.sounds.values():
            sound.set_volume(volume)
        observer.Event("update_state", "Sounds muted" if self.sounds_muted else "Sounds unmuted")

    def _add_chat_listeners(self):
        """Change 4 Add listeners for chat functionality"""
        self.observe("chat_message", self._handle_chat_message)

    def _handle_chat_message(self, data):
        """Change 4 Broadcast chat messages to all players"""
        # You could add filtering or logging here if needed
        observer.Event("update_chat", data)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")



    def _create_players(self, player_names):
        """Create players with custom names"""
        players = []
        for name in player_names:
            player = plr.Player(name, 1500)  # Create the player with the custom name
            players.append(player)
        return players



    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Change 5 Simulate the rolling of two dice and animate using text."""
        #Change 6 for sound
        if not self.sounds_muted:
            self.sounds['dice_roll'].play()

        # Generate the final dice values
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)

        # Animate the dice roll in the View (text-based)
        self._view.animate_text_dice(dice1)
        # For simplicity, we delay dice2 animation by a bit
        self._view.root.after(2200, lambda: self._view.animate_text_dice(dice2))

        dice_sum = dice1 + dice2
        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            observer.Event("update_state", f"Doubles rolled: {dice1} + {dice2} = {dice_sum}")
            self.__dice_rolled = False  # Allow rolling again
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")

        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        #Change 6 Sound
        if not self.sounds_muted:
            self.sounds['player_move'].play()

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        #Change 6
        if not self.sounds_muted:
            self.sounds['player_move'].play()

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()


        """End the current player's turn Change 3 """
        observer.Event("update_state", f"{self._gameboard.next_turn()}'s turn")
        self._view.start_turn_timer()  # 🔥 Restart the timer for the next player
        self._set_expected_val()


    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)







