import tkinter as tk
import os
from tkinter import ttk, messagebox ,simpledialog
import controller
import observer
import random
import pickle

def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 800

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")


        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #Change 5 Dice

        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self.setup_dice_label()  # New: Setup the dice label

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)

        self._add_listeners()

        #self.setup_game()

        # 🕒 Initialize turn timer variables Change 3
        self.timer_running = False
        self.time_remaining = 30




    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        """Add event listeners to the view. Change 3"""
        self.observe("start_turn_timer", self.start_turn_timer)
        #Change 4
        self.observe("update_chat", self.add_chat_message)




    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # Timer Label 🔥 (Added inside middle_frame) Change 3
        self.timer_label = ttk.Label(middle_frame, text="Time Left: 30", font=("Arial", 14), foreground="red")
        self.timer_label.pack(side='top', pady=10)  # Ensure it shows up



        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)

        #create buttons
        #Change 6 Sound
        self.sound_button = ttk.Button(button_frame, text="Toggle Sound",
                                       command=lambda: self._action_taken("toggle_sound"))
        self.sound_button.pack(side='top', anchor='center', pady=(10, 10))

        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll") )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        # Change 1 Save and Load Buttons
        self.save_button = ttk.Button(button_frame, text="Save Game", command=self.save_game)
        self.save_button.pack(side='top', anchor='center', pady=(10, 5))

        self.load_button = ttk.Button(button_frame, text="Load Game", command=self.load_game)
        self.load_button.pack(side='top', anchor='center', pady=(5, 10))

        return middle_frame



    def start_turn_timer(self):
        """Start or restart the timer for a player's turn. Change 3"""
        self.time_remaining = 30  # Reset timer
        self.timer_label.config(text=f"Time Left: {self.time_remaining}")  # Update UI
        if not self.timer_running:
            self.timer_running = True
            self._countdown()

    def _countdown(self):
        """Decrease the timer every second and update UI. Change 3"""
        if self.time_remaining > 0:
            self.time_remaining -= 1
            self.timer_label.config(text=f"Time Left: {self.time_remaining}")
            self.root.after(1000, self._countdown)  # Call again in 1 second
        else:
            self.timer_label.config(text="Time's up!")
            self.timer_running = False
            observer.Event("end_turn", self._clear_text)  # Auto end turn


    def prompt_player_names(self, num_players):
        """Prompt players for their names"""  # Change 2 Players custom names
        player_names = []
        for i in range(num_players):
            player_name = tk.simpledialog.askstring("Player Name", f"Enter name for Player {i + 1}:")
            if not player_name:  # Default name if no input is provided
                player_name = f"Player {i + 1}"
            player_names.append(player_name)
        return player_names

    def _create_msg_frame(self):
        """Change 4 Create the frame at the bottom with game state and chat"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        # Left side - Game state box
        state_frame = ttk.Frame(msg_frame)
        self.state_box = tk.Text(
            state_frame,
            width=40,
            height=10,
            background='black',
            foreground='white'
        )
        self.state_box.pack(side='left', fill='both', expand=True)
        state_frame.pack(side='left', fill='both', expand=True, padx=5)

        # Right side - Game messages
        text_frame = ttk.Frame(msg_frame)
        self.text_box = tk.Text(
            text_frame,
            width=40,
            height=10,
            background='black',
            foreground='white'
        )
        self.text_box.pack(side='left', fill='both', expand=True)
        text_frame.pack(side='left', fill='both', expand=True, padx=5)

        # Chat frame
        self._setup_chat_ui(msg_frame)

        return msg_frame

    def _setup_chat_ui(self, parent_frame):
        """Change 4 Add chat interface to the specified parent frame"""
        self.chat_frame = ttk.Frame(parent_frame, padding=5)

        # Chat display area
        self.chat_display = tk.Text(
            self.chat_frame,
            height=8,
            width=30,
            state='disabled',
            wrap='word',
            background='white',
            foreground='black'
        )
        scrollbar = ttk.Scrollbar(self.chat_frame, command=self.chat_display.yview)
        self.chat_display['yscrollcommand'] = scrollbar.set
        self.chat_display.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')

        # Chat input area
        input_frame = ttk.Frame(self.chat_frame)
        self.chat_entry = ttk.Entry(input_frame)
        self.chat_entry.pack(side='left', fill='x', expand=True, padx=5)
        self.chat_entry.bind('<Return>', self._send_chat_message)

        send_button = ttk.Button(
            input_frame,
            text="Send",
            command=self._send_chat_message
        )
        send_button.pack(side='left')
        input_frame.pack(side='bottom', fill='x')

        self.chat_frame.pack(side='right', fill='both', padx=10)


    def _send_chat_message(self, event=None):
        """Change 4 Handle sending a chat message"""
        message = self.chat_entry.get()
        if message.strip():
            # Get current player's name
            current_player = "Player"
            if hasattr(self, 'controller') and hasattr(self.controller, '_gameboard'):
                current_player = self.controller._gameboard.get_current_player().name

            observer.Event("chat_message", {
                'sender': current_player,
                'message': message
            })
            self.chat_entry.delete(0, 'end')

    def add_chat_message(self, data):
        """Change 4 Add a message to the chat display"""
        self.chat_display.config(state='normal')
        self.chat_display.insert('end', f"{data['sender']}: {data['message']}\n")
        self.chat_display.config(state='disabled')
        self.chat_display.see('end')  # Auto-scroll to bottom

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action):
        #Change 6 Sound
        if action == "toggle_sound":
            observer.Event("toggle_sound", None)
        if action == "roll":
            #tell the controller roll was clicked
            print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)

        if action == "end_turn":
            #self.text_box.delete(1.0, tk.END)
            observer.Event("end_turn", self._clear_text)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def save_game(self):
        """ Change 1 Save the game state"""
        self.controller.save_game()
        messagebox.showinfo("Game Saved", "Your game has been saved successfully!")

    def load_game(self):
        """Change 1 Load a saved game"""
        self.controller.load_game()
        messagebox.showinfo("Game Loaded", "Game state loaded successfully!")


    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        #good idea disable all buttons

        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                        command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)



    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def setup_dice_label(self):
        """Change 5 Setup a Label widget to show dice roll result (text-based)."""
        self.dice_label = tk.Label(self.main_frame, text="Dice: ?", font=("Arial", 24))
        # Pack it near the top or wherever you want it in your layout
        self.dice_label.pack(pady=10)

    def animate_text_dice(self, final_value, frames=10, delay=100):
        """Change 5 Animate dice roll by updating text for a few frames then show final value.

        :param final_value: The final dice value (1-6)
        :param frames: Number of flicker frames
        :param delay: Delay between frames in milliseconds
        """

        def flicker(frame):
            if frame > 0:
                temp_value = random.randint(1, 6)
                self.dice_label.config(text=f"Dice: {temp_value}")
                self.root.after(delay, flicker, frame - 1)
            else:
                self.dice_label.config(text=f"Dice: {final_value}")

        flicker(frames)


'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)
    # Change 1 for load and save buttons
    ui= View(root)
    ui.controller = controller

    root.mainloop()

