import gameboard
import gamesquare
import observer
import random
import importlib


class Player:

    def __init__(self, name, money):
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__luck = 0
        self.__mortgaging_order = []
        self.__in_jail = False
        self.__turn_in_jail = 0
        self.__goojfc = 0


    def __str__(self):
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def buy_property(self, board_property):
        if not board_property.can_be_purchased():
            return False
        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1
        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name

    def net_worth(self):
        return self.__money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        self.__money += amount


    def move(self, spaces):
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position == 2 or self.__board_position == 17 or self.__board_position == 33:
            self.draw_cc()
        if self.__board_position == 7 or self.__board_position == 22 or self.__board_position == 36:
            self.draw_chance()
        if self.__board_position == 30:
            self.go_to_jail()
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)
            self.collect(200)


    def advance_to_go(self):
        self.__board_position = 0
        self.__money += 200
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} advances to Go and collects $200.")

    def bank_error(self):
        self.__money += 200
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} receives a $200 bank error.")

    def doctors_fee(self):
        self.__money -= 50
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} pays a $50 doctor’s fee.")

    def get_out_of_jail(self):
        self.__goojfc += 1
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} got a get out of jail free card.")

    def stock_sale(self):
        self.__money += 50
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} collects $50 from sale of stock.")

    def go_to_jail(self):
        self.__in_jail = True
        self.jail_time()
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} Goes to Jail. Goes directly to jail, does not pass Go, does not collect $200")
        observer.Event("reset_roll",f"{self.__name}")

    def holiday_fund(self):
        self.__money += 100
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} receives $100 from the holiday fund.")

    def income_tax_refund(self):
        self.__money += 20
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} collects a $20 income tax refund.")

    def life_insurance(self):
        self.__money += 100
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} collects $100 from life insurance.")

    def hospital_fees(self):
        self.__money -= 100
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} pays $100 in hospital fees.")

    def school_fees(self):
        self.__money -= 50
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} pays $50 in school fees.")

    def consultancy_fee(self):
        self.__money += 25
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} receives $25 consultancy fee.")

    def beauty_contest(self):
        self.__money += 10
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} wins second prize in a beauty contest and collects $10.")

    def inheritance(self):
        self.__money += 100
        observer.Event("update_state", f"{self.__name} drew a community chest card.")
        observer.Event("update_state",f"{self.__name} inherits $100.")

    def draw_cc(self):
        card = random.randint(1,14)
        if card == 1: self.advance_to_go()
        elif card == 2: self.bank_error()
        elif card == 3: self.doctors_fee()
        elif card == 4: self.stock_sale()
        elif card == 5: self.holiday_fund()
        elif card == 6: self.income_tax_refund()
        elif card == 7: self.life_insurance()
        elif card == 8: self.hospital_fees()
        elif card == 9: self.school_fees()
        elif card == 10: self.consultancy_fee()
        elif card == 11: self.beauty_contest()
        elif card == 12: self.inheritance()
        elif card == 13: self.go_to_jail()
        elif card == 14: self.get_out_of_jail()

    def advance_to_boardwalk(self):
        self.__board_position = 39
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        observer.Event("update_state",f"{self.__name} advances to Boardwalk.")

    def advance_to_illinois(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        if self.__board_position > 24:
            self.__money += 200
            observer.Event("update_state",f"{self.__name} passes Go and collects $200.")
        self.__board_position = 24
        observer.Event("update_state",f"{self.__name} advances to Illinois Avenue.")

    def advance_to_st_charles(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        if self.__board_position > 11:
            self.__money += 200
            observer.Event("update_state",f"{self.__name} passes Go and collects $200.")
        self.__board_position = 11
        observer.Event("update_state",f"{self.__name} advances to St. Charles Place.")

    def nearest_railroad(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        railroads = [5, 15, 25, 35]
        self.__board_position = min(filter(lambda x: x >= self.__board_position, railroads), default=5)
        observer.Event("update_state",f"{self.__name} advances to the nearest Railroad.")

    def nearest_utility(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        utilities = [12, 28]
        self.__board_position = min(filter(lambda x: x >= self.__board_position, utilities), default=12)
        observer.Event("update_state",f"{self.__name} advances to the nearest Utility.")

    def bank_dividend(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        self.__money += 50
        observer.Event("update_state",f"{self.__name} receives a $50 bank dividend.")

    def go_back_3_spaces(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        self.__board_position -= 3
        observer.Event("update_state",f"{self.__name} moves back 3 spaces.")

    def speeding_fine(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        self.__money -= 15
        observer.Event("update_state",f"{self.__name} pays a $15 speeding fine.")

    def trip_to_reading_railroad(self):
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        if self.__board_position > 5:
            self.__money += 200
            observer.Event("update_state",f"{self.__name} passes Go and collects $200.")
        self.__board_position = 5
        observer.Event("update_state",f"{self.__name} advances to Reading Railroad.")

    def building_loan_matures(self):
        self.__money += 150
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        observer.Event("update_state",f"{self.__name} collects $150 from a building loan maturity.")

    def get_out_of_jail1(self):
        self.__goojfc += 1
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        observer.Event("update_state",f"{self.__name} got a get out of jail free card.")

    def go_to_jail1(self):
        self.__in_jail = True
        self.jail_time()
        observer.Event("update_state", f"{self.__name} drew a chance card.")
        observer.Event("update_state",f"{self.__name} Goes to Jail. Goes directly to jail, does not pass Go, does not collect $200")
        observer.Event("reset_roll",f"{self.__name}")

    def draw_chance(self):
        num = random.randint(1,13)
        if num == 1: self.advance_to_go()
        elif num == 2: self.advance_to_boardwalk()
        elif num == 3: self.advance_to_illinois()
        elif num == 4: self.advance_to_st_charles()
        elif num == 5: self.nearest_railroad()
        elif num == 6: self.nearest_utility()
        elif num == 7: self.bank_dividend()
        elif num == 8: self.go_back_3_spaces()
        elif num == 9: self.speeding_fine()
        elif num == 10: self.trip_to_reading_railroad()
        elif num == 11: self.building_loan_matures()
        elif num == 12: self.go_to_jail1()
        elif num == 13: self.get_out_of_jail1()






    @property
    def jail(self):
        return self.__in_jail

    @jail.setter
    def jail(self, value):
        self.__in_jail = value

    @property
    def goojfc(self):
        return self.__goojfc

    @goojfc.setter
    def goojfc(self, value):
        self.__goojfc = value

    @property
    def turn_in_jail(self):
        return self.__in_jail

    @turn_in_jail.setter
    def turn_in_jail(self, value):
        self.__in_jail = value


    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @property
    def position(self):
        return self.__board_position

    def jail_time(self):
        self.__board_position = 10

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]


