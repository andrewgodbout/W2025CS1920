from game_log import GameLog

class Observer:
    _observers = []

    def __init__(self):
        self._observers.append(self)
        self._observables = {}

    def observe(self, event_name, callback):
        self._observables[event_name] = callback

    @property
    def observables(self):
        return self._observables

    @staticmethod
    def get_observers():
        return Observer._observers

game_log = GameLog()

class Event:
    def __init__(self, event_name, data):
        self.__name = event_name
        self.__data = data
        game_log.log(f"Event: {self.__name} | Data: {self.__data}")
        print(f"Event created: {self.__name}")
        self.notify()

    def notify(self):
        for observer in Observer.get_observers():
            if self.__name in observer.observables:
                observer.observables[self.__name](self.__data)
