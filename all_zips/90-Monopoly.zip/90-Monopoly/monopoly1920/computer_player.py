import random
from player import Player
import observer

class ComputerPlayer(Player):
    def __init__(self, name, money, strategy="conservative"):
        super().__init__(name, money)
        self.strategy = strategy

    def decide_purchase(self, board_property):
        if self.strategy == "conservative":
            return self.money > board_property.price + 200
        elif self.strategy == "aggressive":
            return self.money >= board_property.price
        elif self.strategy == "random":
            return random.choice([True, False])
        elif self.strategy == "monopoly_hunter":
            owned_colors = [p.color for p in self.properties]
            target_color = board_property.color
            same_color_count = owned_colors.count(target_color)
            return same_color_count >= 1 or self.money >= board_property.price + 100
        else:
            return False
    def take_turn(self, gameboard):
        observer.Event("update_state", f"{self.name} (AI - {self.strategy}) is taking its turn.")
        observer.Event("roll", None)
        current_square = gameboard.get_square(self.position)
        if current_square.can_be_purchased() and self.decide_purchase(current_square):
            observer.Event("purchase", None)
        observer.Event("end_turn", None)
