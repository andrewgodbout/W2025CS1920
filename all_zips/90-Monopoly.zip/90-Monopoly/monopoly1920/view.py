import tkinter as tk
import os
from tkinter import ttk
import controller
import observer

def get_board_square_images():
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View(observer.Observer):
    board_size = 400
    margin = 40
    width = 1280
    height = 720

    def __init__(self, root, controller_instance):
        super().__init__()
        self.controller = controller_instance
        self.root = root
        root.title("Monopoly 1920")
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.token_images = {}
        self.token_ids = {}
        self.timer_seconds = 30

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()
        self._create_timer_bar()  # NEW

        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

    def _add_listeners(self):
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        self.observe("update_stats", self._update_stats_panel)
        self.observe("update_chat", self.update_chat)
        self.observe("update_tokens", self.update_tokens)
        self.observe("start_timer", self._on_start_timer)
        self.observe("stop_timer", self._on_stop_timer)

    def _create_logo_frame(self):
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image
        return logo_frame

    def _create_middle_frame(self):
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        self.board_canvas = tk.Canvas(middle_frame, width=self.board_size, height=self.board_size)
        board_image_path = r"resources/images/monopoly.png"
        self.board_img = tk.PhotoImage(file=board_image_path)
        self.board_canvas.create_image(0, 0, anchor="nw", image=self.board_img)
        self.board_canvas.pack(side='left', anchor='n', padx=75, pady=10)

        self.card_frame = ttk.Frame(middle_frame, padding=10)
        self.card_frame.pack(side='right', anchor='center')
        self.card_label = ttk.Label(self.card_frame, text="Property Card")
        self.card_label.pack()

        button_frame = ttk.Frame(middle_frame, padding=10)
        for text, action in [
            ("Roll Dice", "roll"),
            ("Purchase", "purchase"),
            ("Mortgage", "mortgage"),
            ("Unmortgage", "unmortgage"),
            ("Go Bankrupt", "bankrupt"),
            ("End Turn", "end_turn"),
            ("Save Game", "save"),
            ("Load Game", "load"),
            ("Use Jail Card", "use_jail_card")
        ]:
            ttk.Button(button_frame, text=text, command=lambda a=action: self._action_taken(a)).pack(side='top', anchor='center', pady=5)
        button_frame.pack(side='left', anchor='center', padx=50)
        return middle_frame

    def _create_msg_frame(self):
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)
        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))
        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,30))
        self.stats_box = tk.Text(msg_frame, width=40, height=10, background='black', foreground='white')
        self.stats_box.pack(side='left', padx=(30,30))
        return msg_frame

    def _create_timer_bar(self):
        self.timer_frame = ttk.Frame(self.main_frame, padding=5)
        self.timer_label = ttk.Label(self.timer_frame, text="Time left: 30s", font=("Arial", 12, "bold"))
        self.timer_label.pack()
        self.timer_frame.pack(fill=tk.X, side='bottom')

    def _action_taken(self, action):
        observer.Event(action, None)

    def update_card(self, index):
        card_path = os.path.join("resources", "images", "properties", f"{index}.png")
        if os.path.exists(card_path):
            self.card_img = tk.PhotoImage(file=card_path)
            self.card_label.config(image=self.card_img, text="")
            self.card_label.image = self.card_img
        else:
            self.card_label.config(text=f"No card found for square {index}", image="")
            self.card_label.image = None

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _update_text(self, text=""):
        self.text_box.insert(tk.END, text + "\n")

    def _choose(self, choices):
        self.popup_menu = tk.Menu(self.root, tearoff=0)
        for c in choices:
            self.popup_menu.add_command(label=c, command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()
        lbl = "Cancel" if choices else "No properties to mortgage (click to cancel)"
        self.popup_menu.add_command(label=lbl, command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)

    def _update_stats_panel(self, player):
        self.stats_box.delete("1.0", tk.END)
        props = ", ".join(p.name for p in player.properties) or "None"
        total_value = player.money + sum(p.price for p in player.properties)
        self.stats_box.insert(tk.END, f"Name: {player.name}\n")
        self.stats_box.insert(tk.END, f"Cash: ${player.money}\n")
        self.stats_box.insert(tk.END, f"Net Worth: ${total_value}\n")
        self.stats_box.insert(tk.END, f"Properties: {props}\n")
        self.stats_box.insert(tk.END, f"In Jail: {'Yes' if player.in_jail else 'No'}\n")

    def update_chat(self, message):
        self.text_box.insert(tk.END, f"[Chat] {message}\n")

    def update_tokens(self, players):
        self.board_canvas.delete("token")
        for i, player in enumerate(players):
            x = 20 + (player.position * 10) % self.board_size
            y = 350 + (i * 20)
            try:
                token_img = tk.PhotoImage(file=player.token)
                self.token_images[player.name] = token_img
                self.board_canvas.create_image(x, y, image=token_img, tags="token", anchor="center")
            except Exception as e:
                print(f"Error loading token for {player.name}: {e}")

    def start_timer(self, seconds=30):
        self.timer_seconds = seconds
        self._tick_timer()

    def _tick_timer(self):
        color = "red" if self.timer_seconds <= 10 else "black"
        self.timer_label.config(text=f"Time left: {self.timer_seconds}s", foreground=color)
        if self.timer_seconds <= 0:
            observer.Event("end_turn", None)
            return
        self.timer_seconds -= 1
        self.root.after(1000, self._tick_timer)

    def stop_timer(self):
        self.timer_seconds = 0
        self.timer_label.config(text="Time left: --")

    def _on_start_timer(self, seconds):
        self.start_timer(seconds)

    def _on_stop_timer(self, _):
        self.stop_timer()


class GameSetup:
    def __init__(self, root):
        self.root = root
        self.root.title("Monopoly Setup")
        self.frame = ttk.Frame(root, padding=20)
        self.frame.pack()

        self.entries = []
        self.num_players = tk.IntVar(value=2)

        ttk.Label(self.frame, text="Number of Players (2-4):").grid(row=0, column=0)
        ttk.Spinbox(self.frame, from_=2, to=4, textvariable=self.num_players).grid(row=0, column=1)

        self.cont_button = ttk.Button(self.frame, text="Continue", command=self.build_form)
        self.cont_button.grid(row=1, columnspan=2, pady=10)

    def build_form(self):
        for widget in self.frame.winfo_children()[2:]:
            widget.destroy()

        self.entries.clear()
        for i in range(self.num_players.get()):
            ttk.Label(self.frame, text=f"Player {i + 1} Name:").grid(row=i, column=0)
            name_entry = ttk.Entry(self.frame)
            name_entry.grid(row=i, column=1)

            ttk.Label(self.frame, text="Type:").grid(row=i, column=2)
            type_var = tk.StringVar(value="human")
            ttk.OptionMenu(self.frame, type_var, "human", "human", "computer").grid(row=i, column=3)

            ttk.Label(self.frame, text="Token:").grid(row=i, column=4)
            token_var = tk.StringVar(value=f"resources/images/tokens/token{i}.png")
            ttk.OptionMenu(self.frame, token_var, *[f"resources/images/tokens/token{j}.png" for j in range(4)]).grid(row=i, column=5)

            self.entries.append((name_entry, type_var, token_var))

        ttk.Button(self.frame, text="Start Game", command=self.start_game).grid(row=10, columnspan=6, pady=20)

    def start_game(self):
        configs = []
        for name_entry, type_var, token_var in self.entries:
            configs.append({
                "name": name_entry.get() or "Player",
                "type": type_var.get(),
                "token": token_var.get()
            })

        self.frame.destroy()
        self.controller = controller.Controller()
        self.view = View(self.root, self.controller)
        self.controller.initialize_game(configs)


if __name__ == '__main__':
    root = tk.Tk()
    GameSetup(root)
    root.mainloop()