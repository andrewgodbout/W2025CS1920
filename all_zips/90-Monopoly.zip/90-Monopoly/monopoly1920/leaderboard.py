import json
import os

class Leaderboard:
    def __init__(self, file_path="leaderboard.json"):
        self.file_path = file_path
        self.scores = self.load_leaderboard()

    def load_leaderboard(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                return json.load(f)
        return {}

    def record_result(self, player_name, score):
        self.scores[player_name] = self.scores.get(player_name, 0) + score
        self.save_leaderboard()

    def save_leaderboard(self):
        with open(self.file_path, "w") as f:
            json.dump(self.scores, f, indent=4)

    def get_leaderboard(self):
        return sorted(self.scores.items(), key=lambda x: x[1], reverse=True)
