class GameLog:
    def __init__(self, file_path="game_log.txt"):
        self.file_path = file_path

    def log(self, message):
        with open(self.file_path, "a") as f:
            f.write(message + "\n")
