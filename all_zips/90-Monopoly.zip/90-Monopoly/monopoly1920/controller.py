import os
import random
import json
import observer
import gameboard
import player as plr
import gamesquare
from computer_player import ComputerPlayer

class Controller(observer.Observer):
    """Controls the game flow for the Monopoly game using a web frontend."""

    def __init__(self):
        super().__init__()
        self.player_configs = []
        self.house_rules = []
        self._gameboard = None
        self._timer = None
        self._time_left = 30
        self.__dice_rolled = False
        self.__roll_count = 0

        self.observe("roll", lambda _: self.roll_action())
        self.observe("purchase", lambda _: self.buy_square())
        self.observe("mortgage", lambda _: self.mortgage())
        self.observe("unmortgage", lambda _: self.unmortgage())
        self.observe("end_turn", lambda _: self.end_player_turn())
        self.observe("save", lambda _: self.save_game())
        self.observe("load", lambda _: self.load_game())
        self.observe("use_jail_card", lambda _: self.use_jail_card())

        self.chance_cards = self._load_cards("resources/data/chance.json")
        self.chest_cards = self._load_cards("resources/data/chest.json")

    def initialize_game(self, player_configs, house_rules=None):
        """
        Initialize game with given player configurations and house rules.
        player_configs is a list of dicts with keys: name, token, type ("human" or "computer")
        """
        self.player_configs = player_configs
        self.house_rules = house_rules if house_rules else []
        players = self._create_players(player_configs)

        csv_path = os.path.join("resources", "data", "board.csv")
        self._gameboard = gameboard.GameBoard(csv_path, players)

        # Announce the first player's turn
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_stats", self._gameboard.get_current_player())
        self._set_expected_val()

    def _create_players(self, config_list):
        players = []
        for config in config_list:
            if config.get("type", "human").lower() == "computer":
                player = ComputerPlayer(config['name'], 1500)
            else:
                player = plr.Player(config['name'], 1500)
            player.has_jail_card = False
            player.token = config['token']
            players.append(player)
        return players

    def _load_cards(self, filepath):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            observer.Event("update_state", f"Card file not found: {filepath}")
            return []

    def _draw_card(self, deck_type, player):
        card = random.choice(self.chance_cards if deck_type == "chance" else self.chest_cards)
        observer.Event("update_state", f"{deck_type.title()} card: {card['text']}")

        if card["action"] == "money":
            player.money += card["amount"]
            observer.Event("update_state", f"Money updated: ${player.money}")
        elif card["action"] == "move":
            player.move((card["position"] - player.position) % 40)
            observer.Event("update_card", player.position)
        elif card["action"] == "jail":
            player.go_to_jail()
            observer.Event("update_card", player.position)
        elif card["action"] == "jail_card":
            player.has_jail_card = True
            observer.Event("update_state", f"{player.name} received a Get Out of Jail Free card!")

        observer.Event("update_stats", player)

    def _handle_jail_turn(self, player, dice1, dice2):
        observer.Event("update_state", f"{player.name} is in jail (turn {player.jail_turns + 1}/3)")
        observer.Event("update_state", f"Dice rolled in jail: {dice1} + {dice2}")

        if player.has_jail_card:
            observer.Event("update_state", f"{player.name} has a Get Out of Jail Free card available.")

        if dice1 == dice2:
            player.in_jail = False
            player.jail_turns = 0
            observer.Event("update_state", f"{player.name} rolled doubles and got out of jail!")
            player.move(dice1 + dice2)
            observer.Event("update_card", player.position)
            observer.Event("update_stats", player)
            return True
        else:
            player.jail_turns += 1
            if player.jail_turns >= 3:
                if player.money >= 50:
                    player.money -= 50
                    player.in_jail = False
                    player.jail_turns = 0
                    observer.Event("update_state", f"{player.name} paid $50 and got out of jail.")
                    player.move(dice1 + dice2)
                    observer.Event("update_card", player.position)
                    observer.Event("update_stats", player)
                    return True
                else:
                    observer.Event("update_state", f"{player.name} cannot afford to pay $50 to get out of jail.")
                    return True
            else:
                observer.Event("update_state", f"{player.name} did not roll doubles and remains in jail.")
                return True

    def use_jail_card(self):
        player = self._gameboard.get_current_player()
        if player.in_jail and player.has_jail_card:
            player.has_jail_card = False
            player.in_jail = False
            player.jail_turns = 0
            observer.Event("update_state", f"{player.name} used a Get Out of Jail Free card!")
            observer.Event("update_stats", player)
        else:
            observer.Event("update_state", "No Get Out of Jail Free card available or you are not in jail.")

    def roll_action(self):
        player = self._gameboard.get_current_player()
        if not self._handle_roll_dice():
            return
        square = self._gameboard.get_square(player.position)
        observer.Event("update_state", f"{player.name} landed on {square}.")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
        observer.Event("update_stats", player)

    def _handle_roll_dice(self):
        if self.__dice_rolled:
            observer.Event("update_state", "Already rolled.")
            return False

        dice1, dice2, total = self._roll_dice()
        player = self._gameboard.get_current_player()

        if player.in_jail:
            return self._handle_jail_turn(player, dice1, dice2)

        if dice1 == dice2:
            self.__roll_count += 1
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2}")
            if self.__roll_count == 3:
                player.go_to_jail()
                observer.Event("update_card", player.position)
                observer.Event("update_stats", player)
                return True
            self.__dice_rolled = False
        else:
            self.__roll_count = 0
            self.__dice_rolled = True

        player.move(total)
        square = self._gameboard.get_square(player.position)

        if square.space == "GotoJail":
            player.go_to_jail()
            observer.Event("update_card", player.position)
            observer.Event("update_stats", player)
            return True

        if square.space == "Jail" and not player.in_jail:
            observer.Event("update_state", f"{player.name} is just visiting Jail.")

        if square.space == "Chance":
            self._draw_card("chance", player)
        elif square.space == "Chest":
            self._draw_card("chest", player)

        observer.Event("update_stats", player)
        self._start_turn_timer()
        return True

    def _roll_dice(self):
        d1 = random.randint(1, 6)
        d2 = random.randint(1, 6)
        return d1, d2, d1 + d2

    def end_player_turn(self):
        self._stop_turn_timer()
        if not self.__dice_rolled:
            observer.Event("update_state", "You must roll first.")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        name = self._gameboard.next_turn()
        observer.Event("update_state", f"{name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        observer.Event("update_stats", self._gameboard.get_current_player())
        self._set_expected_val()

    def buy_square(self):
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)

        if not square.can_be_purchased() or square.owner is not None:
            observer.Event("update_state", f"{square.name} cannot be purchased.")
            return

        if player.money < square.price:
            observer.Event("update_state", f"{player.name} can't afford {square.name}. Starting auction...")
            self.start_auction(square)
            return

        if player.buy_property(square):
            observer.Event("update_state", f"{player.name} bought {square.name} for ${square.price}")
        else:
            observer.Event("update_state", f"{player.name} failed to purchase {square.name}")

        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_stats", player)

    def start_auction(self, square):
        all_players = self._gameboard.get_all_players()
        bids = {}
        for p in all_players:
            bids[p.name] = random.randint(0, p.money)
        highest_bidder = max(bids, key=bids.get)
        highest_bid = bids[highest_bidder]
        if highest_bid <= 0:
            observer.Event("update_state", "No valid bids placed. Auction failed.")
        else:
            winner = next(p for p in all_players if p.name == highest_bidder)
            winner.money -= highest_bid
            square.owner = winner
            winner.properties.append(square)
            observer.Event("update_state", f"{winner.name} won the auction for {square.name} at ${highest_bid}.")

    def mortgage(self):
        player = self._gameboard.get_current_player()
        deeds = [p.name for p in player.properties if not p.is_mortgaged]
        observer.Event("choice", deeds)

    def mortgage_specific(self, name):
        player = self._gameboard.get_current_player()
        success = player.mortgage_property(name)
        msg = f"{name} mortgaged" if success else f"{name} mortgage failed"
        observer.Event("update_state", msg)

    def unmortgage(self):
        player = self._gameboard.get_current_player()
        name = player.unmortgage_property()
        if name:
            observer.Event("update_state", f"Unmortgaged {name}")

    def build_house(self):
        player = self._gameboard.get_current_player()
        color_groups = {}
        for prop in player.properties:
            if not hasattr(prop, "houses"):
                prop.houses = 0
            color_groups.setdefault(prop.color, []).append(prop)
        for color, group_props in color_groups.items():
            all_props_in_group = [sq for sq in self._gameboard.get_all_squares() if sq.color == color and sq.can_be_purchased()]
            if len(group_props) != len(all_props_in_group):
                continue
            min_houses = min(p.houses for p in group_props)
            for p in group_props:
                if p.houses == min_houses and p.houses < 5:
                    cost = 50
                    if player.money >= cost:
                        p.houses += 1
                        player.money -= cost
                        observer.Event("update_state", f"Built on {p.name}: {p.houses} house(s)")
                        break
        observer.Event("update_stats", player)

    def sell_house(self):
        player = self._gameboard.get_current_player()
        color_groups = {}
        for prop in player.properties:
            if hasattr(prop, "houses") and prop.houses > 0:
                color_groups.setdefault(prop.color, []).append(prop)
        for color, group_props in color_groups.items():
            all_props_in_group = [sq for sq in self._gameboard.get_all_squares() if sq.color == color and sq.can_be_purchased()]
            if len(group_props) != len(all_props_in_group):
                continue
            max_houses = max(p.houses for p in group_props)
            for p in group_props:
                if p.houses == max_houses and p.houses > 0:
                    p.houses -= 1
                    player.money += 25  # selling at half-price
                    building = "hotel" if p.houses == 5 else f"{p.houses} house(s)"
                    observer.Event("update_state", f"Sold house from {p.name}: now {building}")
                    observer.Event("update_stats", player)
                    return
        observer.Event("update_state", "No houses to sell or no valid group to sell from.")

    def trade_assets(self, data):
        """
        data dict includes:
          - "from": offering player name
          - "to": receiving player name
          - "give_properties": list of property names the offering player gives
          - "receive_properties": list of property names the offering player receives
          - "money_from": money from the offering player
          - "money_to": money from the receiving player
        """
        from_name = data.get("from")
        to_name = data.get("to")
        all_players = self._gameboard.get_all_players()
        from_p = next(p for p in all_players if p.name == from_name)
        to_p = next(p for p in all_players if p.name == to_name)

        give_props = data.get("give_properties", [])
        receive_props = data.get("receive_properties", [])
        for prop_name in give_props:
            prop = next((p for p in from_p.properties if p.name == prop_name), None)
            if prop:
                from_p.properties.remove(prop)
                to_p.properties.append(prop)
                prop.owner = to_p
        for prop_name in receive_props:
            prop = next((p for p in to_p.properties if p.name == prop_name), None)
            if prop:
                to_p.properties.remove(prop)
                from_p.properties.append(prop)
                prop.owner = from_p

        money_from = data.get("money_from", 0)
        money_to = data.get("money_to", 0)
        if from_p.money < money_from:
            observer.Event("update_state", f"Trade failed: {from_p.name} doesn't have enough money.")
            return
        if to_p.money < money_to:
            observer.Event("update_state", f"Trade failed: {to_p.name} doesn't have enough money.")
            return

        from_p.money = from_p.money - money_from + money_to
        to_p.money = to_p.money - money_to + money_from

        observer.Event("update_state", f"Trade complete between {from_name} and {to_name}.")

    def save_game(self):
        all_players = self._gameboard.get_all_players()
        state = {
            "players": [],
            "turn_index": self._gameboard._GameBoard__total_turns,
        }
        for p in all_players:
            state["players"].append({
                "money": p.money,
                "position": p.position,
                "in_jail": p.in_jail,
                "jail_turns": p.jail_turns,
                "has_jail_card": getattr(p, "has_jail_card", False),
                "properties": [prop.name for prop in p.properties]
            })
        with open("savegame.json", "w") as f:
            json.dump(state, f)
        observer.Event("update_state", "Game saved!")

    def load_game(self):
        try:
            with open("savegame.json", "r") as f:
                state = json.load(f)
            self._gameboard.reset_players()
            all_players = self._gameboard.get_all_players()
            for i, pdata in enumerate(state["players"]):
                p = all_players[i]
                p.money = pdata["money"]
                p.__dict__['_Player__board_position'] = pdata["position"]
                p.in_jail = pdata["in_jail"]
                p.jail_turns = pdata["jail_turns"]
                p.has_jail_card = pdata.get("has_jail_card", False)
                p.properties.clear()
                for sq in self._gameboard._GameBoard__properties:
                    if sq.name in pdata["properties"]:
                        sq.owner = p
                        p.properties.append(sq)
            self._gameboard._GameBoard__total_turns = state["turn_index"]
            observer.Event("update_state", "Game loaded.")
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", self._gameboard.get_current_player().position)
            observer.Event("update_stats", self._gameboard.get_current_player())
        except FileNotFoundError:
            observer.Event("update_state", "No savegame found.")

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")
        self._gameboard.get_current_player().luck += ev

    def suggest_move(self):
        current_square = self._gameboard.get_square(self._gameboard.get_current_player().position)
        suggestion = "Always buy Baltic" if "Baltic" in current_square.name else "Consider passing on this property."
        observer.Event("update_state", f"Suggestion: {suggestion}")

    def chat_message(self, message):
        observer.Event("update_state", f"Chat: {message}")

    def computer_take_turn(self):
        player = self._gameboard.get_current_player()
        if hasattr(player, "take_turn"):
            player.take_turn(self._gameboard)
        else:
            self.roll_action()

    def _start_turn_timer(self):
        observer.Event("start_timer", 30)  # you can adjust seconds as needed

    def _stop_turn_timer(self):
        observer.Event("stop_timer", None)

