import tkinter as tk
import os
from tkinter import ttk
import controller
import observer
import random
import json

def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

        #self.setup_game()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)


    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)

        #create buttons
        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll") )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        self.auction_button = ttk.Button(button_frame, text="Auction Property", command=self.start_auction)
        self.auction_button.pack(side='top', anchor='center', pady=(10, 10))
        self.auction_button.state(['active'])
        self.mid_buttons.append(self.auction_button)



        return middle_frame

    def start_auction(self):
        """Start the auction for a property"""
        print("Auction started for the property.")
        # Placeholder for auction logic
        self._update_text("Auction has started. Players can now place bids.")

        # Simulate auction process: We can show a popup or message where players can place bids
        self._auction_process()

    def _auction_process(self):
        """Simulate the bidding process for the auction"""
        # In a real game, you'd need to interact with players' input for bids
        # For this example, we'll use random bids for demonstration purposes
        bids = {f"Player {i + 1}": random.randint(100, 500) for i in range(4)}  # Simulate 4 players
        print(f"Bids: {bids}")

        # Find the player with the highest bid
        highest_bidder = max(bids, key=bids.get)
        highest_bid = bids[highest_bidder]

        self._update_text(f"Highest bid: {highest_bid} by {highest_bidder}.")
        print(f"{highest_bidder} wins the auction with a bid of {highest_bid}!")

        # Notify the controller or perform necessary updates when the auction ends
        observer.Event("auction_end", {"winner": highest_bidder, "bid": highest_bid})

    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))

        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,100))

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action):

        if action == "roll":
            #tell the controller roll was clicked
            print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)

        if action == "end_turn":
            #self.text_box.delete(1.0, tk.END)
            observer.Event("end_turn", self._clear_text)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        #good idea disable all buttons

        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                        command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)



    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def _draw_card(self, card_type):
        """Draw a Chance or Community Chest card"""
        cards = {
            "chance": ["Advance to Go", "Go to Jail", "Bank pays you $50", "Pay school fees of $150"],
            "community_chest": ["Doctor's fees - Pay $50", "Bank error in your favor - Collect $200", "Get Out of Jail Free", "Go to Jail"]
        }
        card = random.choice(cards[card_type])
        print(f"{card_type.capitalize()} Card: {card}")
        return card

def update_player_position(self, dice_roll):
    """Updates the player's position based on the dice roll and checks for daily bonus."""
    self.current_player.position += dice_roll

    if self.current_player.position >= 40:  # If they pass or land on Go
        self.current_player.position -= 40  # Loop back to start
        self.check_daily_bonus()  # Trigger daily bonus when passing Go

    # Display the updated position (for example purposes)
    print(f"Player's new position: {self.current_player.position}")

def check_daily_bonus(self):
    """Check if the player gets a daily bonus when they pass Go."""
    if random.randint(1, 100) <= 10:  # 10% chance to get a bonus
        bonus_amount = 200
        self._update_text(f"Congratulations! You received a Daily Bonus of ${bonus_amount}.")
        observer.Event("daily_bonus", bonus_amount)  # Notify the event handler

def _update_text(self, message):
    """Update the game message box with a new message."""
    # For simplicity, we just print the message here
    print(message)

def add_player(self, player_name):
    if player_name not in self.leaderboard:
        self.leaderboard[player_name] = {'wins': 0, 'losses': 0, 'games': 0}

def update_player_stats(self, player_name, win=True):
    if player_name not in self.leaderboard:
        self.add_player(player_name)

    self.leaderboard[player_name]['games'] += 1
    if win:
        self.leaderboard[player_name]['wins'] += 1
    else:
        self.leaderboard[player_name]['losses'] += 1

def display_leaderboard(self):
    print("\nLeaderboard:")
    for player, stats in self.leaderboard.items():
        print(f"{player}: Wins={stats['wins']} | Losses={stats['losses']} | Games={stats['games']}")



def _save_game(self):
    game_state = {
            'players': [player.get_state() for player in self.controller.players],
            'properties': self.controller.board.get_state(),
            'turn': self.controller.turn,
            'bankrupt_players': [player.name for player in self.controller.players if player.is_bankrupt()],
        }
    with open("saved_game.json", "w") as f:
        json.dump(game_state, f)
    self._update_text("Game saved successfully!")

    def _load_game(self):
        """Load the game state from a file"""
        try:
            with open("saved_game.json", "r") as f:
                game_state = json.load(f)

            # Load players
            for player_data in game_state['players']:
                player = self.controller.get_player_by_name(player_data['name'])
                player.set_state(player_data)

            # Load board state
            self.controller.board.set_state(game_state['properties'])

            # Restore turn
            self.controller.turn = game_state['turn']
            self._update_text("Game loaded successfully!")

        except FileNotFoundError:
            self._update_text("No saved game found.")
        except json.JSONDecodeError:
            self._update_text("Error loading the saved game.")

    def _create_save_load_buttons(self, middle_frame):
        """Create the save/load buttons for the GUI"""
        button_frame = ttk.Frame(middle_frame, padding=10)

        save_button = ttk.Button(button_frame, text="Save Game", command=self._save_game)
        save_button.pack(side='top', anchor='center', pady=(10, 10))

        load_button = ttk.Button(button_frame, text="Load Game", command=self._load_game)
        load_button.pack(side='top', anchor='center', pady=(10, 10))

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)







'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()

