# gameboard.py
import player
import gamesquare
import csv
import os # Import os for path joining

# --- GET BASE DIRECTORY ---
# Redundant if controller passes full path, but good practice here too
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# --- END GET BASE DIRECTORY ---


class GameBoard:

    # Adjusted based on user's CSV header/length debug output
    # Indices 0-11 seem present and used. Index 12 ('Number'?) exists but isn't used by loading code.
    # Indices 13-15 ('owner','houses','groupmembers') were missing in user's CSV.
    __boardCSV = {
        "name": 0, "space": 1, "color": 2, "position": 3, "price": 4,
        "build": 5, # Assuming index 5 is build cost despite header 'PriceBuild'
        "rent": 6, "rent1": 7, "rent2": 8, "rent3": 9, "rent4": 10,"rent5": 11
        # Max index needed by current load logic is 11
    }

    def __init__(self, properties_path, players ):
        # Ensure the path passed from Controller is used
        self.__properties = self._load_game_board(properties_path)
        self.__players = players # List of player objects waiting turn
        self.__total_turns = 0
        self.__current_player = self.__players.pop(0) if self.__players else None # Set first player
        if self.__properties: # Only link if loading was successful
             self._link_property_groups() # Link properties after loading

    def _link_property_groups(self):
        """Links squares within the same color group based on color."""
        groups = {}
        for square in self.__properties:
            if hasattr(square, 'color') and square.color and square.color != "None" and square.space == "Property":
                groups.setdefault(square.color, []).append(square)
        for group_list in groups.values():
            for square in group_list:
                 if hasattr(square, 'set_group_members'):
                     square.set_group_members(group_list)

    def next_turn(self):
        """Advances turn to the next non-bankrupt player."""
        if not self.__current_player and not self.__players: return None # No players left
        if not self.__current_player and self.__players: # Edge case if current was None but others exist
            self.__current_player = self.__players.pop(0)
            if self.__current_player.bankrupt_declared: return self.next_turn() # Skip if bankrupt
            self.__total_turns +=1
            return self.__current_player.name

        # Put current player back if not bankrupt
        if not self.__current_player.bankrupt_declared:
            self.__players.append(self.__current_player)

        # Find next non-bankrupt player
        original_length = len(self.__players)
        for _ in range(original_length):
             next_p = self.__players.pop(0)
             if not next_p.bankrupt_declared:
                  self.__current_player = next_p
                  self.__total_turns += 1
                  return self.__current_player.name
             else:
                  self.__players.append(next_p) # Put bankrupt back

        # If loop completes, check if anyone remains
        active_players = [p for p in self.__players if not p.bankrupt_declared]
        if len(active_players) == 1:
            self.__current_player = active_players[0]
            return self.__current_player.name
        else: # No active players left or only current was active
            # If current wasn't bankrupt, they are the last one
            if not self.__current_player.bankrupt_declared and len(active_players)==0:
                 return self.__current_player.name # They already took their last turn? Re-select them?
            else: # No one left
                 self.__current_player = None
                 return None


    def calculate_expected_value(self, pos, doubles_count):
        """Calculates expected value (non-standard feature)."""
        if not self.__properties: return 0 # Cannot calculate if board empty
        expected_value = 0
        for i in range(1,7):
            for j in range(1,7):
                new_pos = (pos + i + j) % 40
                if doubles_count == 2 and i == j: continue # Go to jail
                try:
                     square = self.get_square(new_pos)
                     if square: # Check if square exists
                          rent_or_tax = square.calculate_rent_or_tax(i+j, self)
                          expected_value += (rent_or_tax / 36)
                          if i == j: # Doubles
                              recursive_ev = self.calculate_expected_value(new_pos, doubles_count+1)
                              expected_value += (recursive_ev / 36)
                     else: continue # Skip if square is None (shouldn't happen if board loaded)
                except RecursionError: print("EV Calc Error: Recursion depth"); return expected_value
                except Exception as e: print(f"EV Calc Error: {e}"); continue
        return expected_value

    def get_current_player(self): return self.__current_player
    def get_all_squares(self): return self.__properties
    def get_square(self, index):
         if 0 <= index < len(self.__properties): return self.__properties[index]
         else: print(f"Error: Invalid square index {index}"); return None

    def get_board_square(self, index): return self.get_square(index) # Alias

    def get_all_players_incl_current(self):
        """Returns list of all non-bankrupt players, current first."""
        all_players_in_order = []
        if self.__current_player and not self.__current_player.bankrupt_declared:
             all_players_in_order.append(self.__current_player)
        for p in self.__players:
            if not p.bankrupt_declared: all_players_in_order.append(p)
        return all_players_in_order

    def _load_game_board(self, csv_path):
        """Loads board data from CSV, expecting >=12 columns based on needed data."""
        properties = []
        print(f"DEBUG: Loading board from {csv_path}") # Confirm path again
        if not os.path.exists(csv_path):
             print(f"ERROR: Board CSV file not found at resolved path: {csv_path}")
             return [] # Return empty if file doesn't exist

        try:
            with open(csv_path, "r", encoding='utf-8') as f:
                reader = csv.reader(f)
                try: header = next(reader); print(f"DEBUG: CSV Header: {header}")
                except StopIteration: print("ERROR: CSV file empty."); return []

                line_num = 1
                for line in reader:
                    line_num += 1
                    # print(f"DEBUG: Reading Line {line_num}: {line}") # Optional: print every line raw
                    line = [field.strip() for field in line]

                    # --- MODIFY Length Check ---
                    # Check for at least 12 columns (index 0-11 for RentBuild5)
                    expected_cols = 12
                    if len(line) < expected_cols:
                        print(f"DEBUG: Skipping line {line_num} - too short ({len(line)} < {expected_cols})")
                        continue
                    # --- END MODIFY ---

                    try:
                        # Use indices directly based on __boardCSV, max needed is 11
                        name = line[0]; space = line[1]; color = line[2]
                        price = int(line[4]); build_cost = int(line[5])
                        rents = [int(line[i]) for i in range(6, 12)] # Indices 6 to 11 for rent, rent1..rent5

                        print(f"DEBUG: Parsed Line {line_num}: Name={name}, Price={price}, Build={build_cost}, Rents={rents}")

                        util = space == "Utility"; rr = space == "Railroad"
                        sq = gamesquare.GameSquare(name, price, rents, space, color, util, rr, build_cost)
                        properties.append(sq)

                    except (ValueError, IndexError) as parse_err:
                         print(f"ERROR parsing line {line_num}: {parse_err}. Data: {line}")
                         continue
                    except Exception as unexpected_err:
                         print(f"UNEXPECTED ERROR line {line_num}: {unexpected_err}")
                         continue # Skip to next line on error

        except Exception as e: print(f"Error loading board: {e}"); return []

        if len(properties) != 40: print(f"Warning: Loaded {len(properties)} squares, expected 40.")
        else: print(f"DEBUG: Successfully loaded {len(properties)} squares.")
        return properties

    def __str__(self):
        """String representation of the game state."""
        board_str = "Player Status:\n--------------------\n"
        current_p = self.get_current_player()
        all_p = self.get_all_players_incl_current()

        # Safety check if board didn't load
        if not self.__properties:
             board_str += "ERROR: Board not loaded!\n"
             if current_p: board_str += f"-> {current_p}\n"
             for player in all_p:
                  if player is not current_p: board_str += f"   {player}\n"
             return board_str

        if current_p:
             square = self.get_square(current_p.position)
             square_name = square.name if square else f"Pos {current_p.position}"
             board_str += f"-> {current_p} @ {square_name}\n"

        for player in all_p:
             if player is not current_p:
                  if player.bankrupt_declared: board_str += f"   {player.name} (Bankrupt)\n"
                  else:
                       square = self.get_square(player.position)
                       square_name = square.name if square else f"Pos {player.position}"
                       board_str += f"   {player} @ {square_name}\n"
        board_str += "--------------------"
        return board_str