# player.py
import gamesquare
import observer
# --- NEW: Import for type checking ---
import typing
if typing.TYPE_CHECKING:
    import gameboard
# --- END NEW ---


class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0  # Consecutive doubles rolled this turn
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__luck = 0 # Custom attribute
        self.__mortgaging_order = [] # FIFO queue for unmortgaging

        # Jail Attributes
        self.__is_in_jail = False
        self.__turns_in_jail = 0
        self.__get_out_of_jail_cards = 0

    def __str__(self):
        """String representation of the player"""
        jail_status = " (In Jail)" if self.is_in_jail else ""
        return f"{self.__name}{jail_status} - ${self.money} - NW:${self.net_worth()} - luck:{self.__luck:.1f}"

    def buy_property(self, board_property: gamesquare.GameSquare):
        """Attempts to buy a property if affordable and possible."""
        if not board_property.can_be_purchased() or board_property.owner is not None:
            return False
        if self.money < board_property.price:
            return False # Cannot afford

        self.money -= board_property.price
        board_property.owner = self # Set owner on the square
        self.add_property(board_property) # Add to player's list and update counts
        return True

    def add_property(self, board_property: gamesquare.GameSquare):
        """Adds property to list and updates relevant counts."""
        if board_property not in self.__properties:
            self.__properties.append(board_property)
            if board_property.is_utility: self.__utility_count += 1
            if board_property.is_railroad: self.__railroad_count += 1

    def remove_property(self, board_property: gamesquare.GameSquare):
        """Removes property from list and updates relevant counts."""
        if board_property in self.__properties:
            self.__properties.remove(board_property)
            if board_property.is_utility: self.__utility_count -= 1
            if board_property.is_railroad: self.__railroad_count -= 1

    def pay_rent(self, square: gamesquare.GameSquare, dice_sum: int, game_board: 'GameBoard'):
        """Calculates rent, deducts from self, pays owner. Returns rent amount."""
        if square.owner is self or square.owner is None: return 0 # Pay no rent on own/unowned props (Tax handled separately)

        rent = square.calculate_rent_or_tax(dice_sum, game_board)
        if rent > 0:
            self.money -= rent
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name: str):
        """Finds property by name and attempts to mortgage it."""
        prop_to_mortgage = None
        for p in self.__properties:
            if p.name.lower() == deed_name.lower():
                prop_to_mortgage = p
                break
        if prop_to_mortgage:
            if prop_to_mortgage.mortgage(): # mortgage() method returns True/False
                 self.__mortgaging_order.append(prop_to_mortgage) # Add to end of queue
                 return True
        return False

    def unmortgage_property(self):
        """Unmortgages the first property in the FIFO queue if possible."""
        if not self.__mortgaging_order: return "" # No properties in queue

        prop_to_unmortgage = self.__mortgaging_order[0] # Look at first property
        cost_to_unmortgage = (prop_to_unmortgage.price // 2) + (prop_to_unmortgage.price // 20) # Price + 10% interest

        if self.money >= cost_to_unmortgage:
             if prop_to_unmortgage.unmortgage(): # unmortgage() checks status and deducts cost via owner.money
                  self.__mortgaging_order.pop(0) # Remove from queue only on success
                  return prop_to_unmortgage.name
        else:
             observer.Event("update_state", f"Need ${cost_to_unmortgage} to unmortgage {prop_to_unmortgage.name}.")

        return "" # Failed

    def net_worth(self):
        """Calculates net worth: cash + property value + building value."""
        property_value = sum(p.price for p in self.__properties if not p.is_mortgaged)
        building_value = sum((p.house_count + p.hotel_count * 5) * (p.build_cost // 2) for p in self.__properties if p.build_cost > 0) # Value buildings at sale price
        return self.money + property_value + building_value

    def collect(self, amount):
        """Collects money."""
        if amount > 0: self.__money += amount

    def move(self, spaces):
        """Moves the player, handles passing Go."""
        prior_position = self.__board_position
        new_position = (self.__board_position + spaces) % 40
        passed_go = False
        # Check for passing Go (only if moving forward and crossing the 0 index)
        # Don't collect if sent directly TO jail (pos 10) by external logic
        if new_position < prior_position and self.__board_position != 10:
            passed_go = True

        self.__board_position = new_position

        if passed_go:
            observer.Event("update_state", f"{self.name} passed Go, collects $200")
            self.collect(200)

    def send_to_jail(self, jail_position=10):
        """Moves the player directly to jail."""
        self.__board_position = jail_position
        self.__is_in_jail = True
        self.__turns_in_jail = 0
        self.__doubles_count = 0 # Reset doubles count
        observer.Event("update_state", f"{self.name} sent to Jail!")
        observer.Event("update_card", self.position)

    def get_properties_in_group(self, game_board: 'GameBoard', color_group: str):
        """Helper find all properties of a color group on board."""
        if not color_group or color_group == "None": return []
        return [prop for prop in game_board.get_all_squares() if prop.color == color_group and prop.space == "Property"]

    def has_monopoly(self, color_group: str, game_board: 'GameBoard') -> bool:
        """Checks if the player owns all properties of a given color group."""
        group_properties = self.get_properties_in_group(game_board, color_group)
        if not group_properties: return False # No such group exists
        return all(prop.owner is self for prop in group_properties)

    def _get_group_building_levels(self, color_group: str, game_board: 'GameBoard'):
        """Gets building levels (0-4 house, 5 hotel) for owned props in a monopoly."""
        levels = []
        group_props_on_board = self.get_properties_in_group(game_board, color_group)
        if not group_props_on_board: return None # Group doesn't exist
        owned_group_props = [prop for prop in group_props_on_board if prop.owner is self]
        if len(owned_group_props) != len(group_props_on_board): return None # Doesn't own monopoly
        for prop in owned_group_props: levels.append(5 if prop.hotel_count == 1 else prop.house_count)
        return levels

    def can_manage_buildings(self, color_group: str, game_board: 'GameBoard'):
        """Checks if player has a monopoly to allow building/selling."""
        return self.has_monopoly(color_group, game_board)

    def build_house(self, square: gamesquare.GameSquare, game_board: 'GameBoard'):
        """Attempts to build one house/hotel, checking rules."""
        if square.owner is not self or square.space != "Property" or square.build_cost <= 0: observer.Event("update_state", "Cannot build."); return False
        if not self.has_monopoly(square.color, game_board): observer.Event("update_state", "Need monopoly."); return False
        if self.money < square.build_cost: observer.Event("update_state", "Not enough funds."); return False
        if square.hotel_count == 1: observer.Event("update_state", "Already max buildings."); return False

        # Even Building Rule
        group_levels = self._get_group_building_levels(square.color, game_board)
        current_level = square.house_count
        if group_levels:
            min_level = min(group_levels)
            if current_level > min_level: observer.Event("update_state", "Build evenly."); return False

        # Perform Build
        if square.add_building():
            self.money -= square.build_cost
            b_type = "hotel" if square.hotel_count else "house"; b_count = square.hotel_count or square.house_count
            observer.Event("update_state", f"Built {b_type} #{b_count} on {square.name}.")
            observer.Event("update_state_box", str(game_board))
            return True
        else: observer.Event("update_state", "Build failed."); return False

    def sell_house(self, square: gamesquare.GameSquare, game_board: 'GameBoard'):
        """Attempts to sell one house/hotel, checking rules."""
        if square.owner is not self or square.space != "Property": observer.Event("update_state", "Cannot sell."); return False
        if square.house_count == 0 and square.hotel_count == 0: observer.Event("update_state", "No buildings."); return False

        # Even Selling Rule
        group_levels = self._get_group_building_levels(square.color, game_board)
        current_level = 5 if square.hotel_count == 1 else square.house_count
        if group_levels:
             max_level = max(group_levels)
             if current_level < max_level: observer.Event("update_state", "Sell evenly."); return False

        # Perform Sell
        sell_price = square.build_cost // 2
        if square.remove_building():
            self.money += sell_price
            observer.Event("update_state", f"Sold building from {square.name} for ${sell_price}.")
            observer.Event("update_state_box", str(game_board))
            return True
        else: observer.Event("update_state", "Sell failed."); return False

    def calculate_repair_cost(self, house_rate, hotel_rate):
        """Calculates cost for 'repairs' card."""
        total_cost = 0
        for prop in self.properties:
            if prop.space == "Property":
                total_cost += prop.house_count * house_rate
                total_cost += prop.hotel_count * hotel_rate
        return total_cost
    
    # --- NEW HELPER METHODS FOR BUILDING ELIGIBILITY ---

    def can_build_on_any_property(self, game_board: 'GameBoard') -> bool:
        """Checks if the player owns any monopolies where building is possible."""
        checked_colors = set()
        for prop in self.properties:
            color = prop.color
            # Check if it's a buildable property and we haven't checked this color group yet
            if prop.space == "Property" and color and color != "None" and color not in checked_colors:
                checked_colors.add(color)
                # Do they have the monopoly?
                if self.has_monopoly(color, game_board):
                    # Are any properties in the group NOT fully developed (i.e., no hotel)?
                    group_props = self.get_properties_in_group(game_board, color)
                    if any(p.hotel_count == 0 for p in group_props if p.owner is self):
                        # Found a buildable group
                        return True
        return False # No buildable monopolies found

    def can_sell_any_building(self) -> bool:
        """Checks if the player owns any houses or hotels on any property."""
        for prop in self.properties:
            if prop.house_count > 0 or prop.hotel_count > 0:
                return True
        return False

    # --- END NEW HELPER METHODS ---

    # --- Properties ---
    @property
    def money(self): return self.__money
    @money.setter
    def money(self, value): self.__money = value

    @property
    def name(self): return self.__name

    @property
    def position(self): return self.__board_position
    @position.setter # Allow direct setting for cards/jail
    def position(self, value): self.__board_position = value % 40 # Ensure wrap around

    @property
    def properties(self): return self.__properties # Return list copy? No, allow direct modification for now

    @property
    def deed_names(self): return [p.name for p in self.__properties]

    @property
    def railroad_count(self): return self.__railroad_count
    @railroad_count.setter
    def railroad_count(self, value): self.__railroad_count = max(0, value)

    @property
    def utility_count(self): return self.__utility_count
    @utility_count.setter
    def utility_count(self, value): self.__utility_count = max(0, value)

    @property
    def luck(self): return self.__luck
    @luck.setter
    def luck(self, value): self.__luck = value

    @property
    def doubles_count(self): return self.__doubles_count
    @doubles_count.setter
    def doubles_count(self, value): self.__doubles_count = value

    @property
    def is_in_jail(self): return self.__is_in_jail
    @is_in_jail.setter
    def is_in_jail(self, value: bool): self.__is_in_jail = value

    @property
    def turns_in_jail(self): return self.__turns_in_jail
    @turns_in_jail.setter
    def turns_in_jail(self, value: int): self.__turns_in_jail = value

    @property
    def get_out_of_jail_cards(self): return self.__get_out_of_jail_cards
    @get_out_of_jail_cards.setter
    def get_out_of_jail_cards(self, value: int): self.__get_out_of_jail_cards = max(0, value)

    @property
    def bankrupt_declared(self): return self.__bankrupt_declared
    def declare_bankrupt(self): self.__bankrupt_declared = True # Setter logic