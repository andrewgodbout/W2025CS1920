# cards.py
import random

# Define standard card actions and their parameters
# (Note: Some values like property indices or amounts might vary slightly between Monopoly versions)

CHANCE_CARDS = [
    # Movement Cards
    {"text": "Advance to Go (Collect $200)", "action": "moveto", "destination": 0},
    {"text": "Advance to Illinois Ave.", "action": "moveto", "destination": 24}, # Assuming standard US board index
    {"text": "Advance to St. Charles Place", "action": "moveto", "destination": 11}, # Assuming standard US board index
    {"text": "Advance token to nearest Utility. If unowned, you may buy it from the Bank. If owned, throw dice and pay owner a total ten times amount thrown.", "action": "moveto_nearest", "type": "Utility", "pay_multiplier": 10},
    {"text": "Advance token to the nearest Railroad and pay owner twice the rental to which he/she is otherwise entitled. If Railroad is unowned, you may buy it from the Bank.", "action": "moveto_nearest", "type": "Railroad", "pay_multiplier": 2},
    {"text": "Advance token to the nearest Railroad and pay owner twice the rental to which he/she is otherwise entitled. If Railroad is unowned, you may buy it from the Bank.", "action": "moveto_nearest", "type": "Railroad", "pay_multiplier": 2}, # There are two of these
    {"text": "Go Back 3 Spaces", "action": "move", "amount": -3},

    # Money Cards
    {"text": "Bank pays you dividend of $50", "action": "collect", "amount": 50},
    {"text": "Make general repairs on all your property – for each house pay $25 – for each hotel $100", "action": "repairs", "house_cost": 25, "hotel_cost": 100}, # Needs houses/hotels implemented
    {"text": "Pay poor tax of $15", "action": "pay", "amount": 15},
    {"text": "You have been elected Chairman of the Board – pay each player $50", "action": "payeachplayer", "amount": 50},
    {"text": "Your building loan matures – collect $150", "action": "collect", "amount": 150},

    # Jail Cards
    {"text": "Get Out of Jail Free – This card may be kept until needed, or traded/sold.", "action": "getoutofjailfree"},
    {"text": "Go to Jail – Go directly to Jail – Do not pass Go, do not collect $200", "action": "gotojail"},

    # Specific Property Movement
    {"text": "Take a trip to Reading Railroad – if you pass Go collect $200", "action": "moveto", "destination": 5}, # Assuming standard US board index
    {"text": "Take a walk on the Boardwalk – Advance token to Boardwalk", "action": "moveto", "destination": 39}, # Assuming standard US board index
]

COMMUNITY_CHEST_CARDS = [
    {"text": "Advance to Go (Collect $200)", "action": "moveto", "destination": 0},
    {"text": "Bank error in your favor – collect $200", "action": "collect", "amount": 200},
    {"text": "Doctor's fees – Pay $50", "action": "pay", "amount": 50},
    {"text": "From sale of stock you get $50", "action": "collect", "amount": 50}, # Often $45 or $50
    {"text": "Get Out of Jail Free – This card may be kept until needed, or traded/sold.", "action": "getoutofjailfree"},
    {"text": "Go to Jail – Go directly to Jail – Do not pass Go, do not collect $200", "action": "gotojail"},
    {"text": "Grand Opera Night – collect $50 from every player for opening night seats", "action": "collecteachplayer", "amount": 50},
    {"text": "Holiday Fund matures - Receive $100", "action": "collect", "amount": 100}, # Sometimes "Xmas Fund"
    {"text": "Income tax refund – collect $20", "action": "collect", "amount": 20},
    {"text": "It is your birthday - Collect $10 from each player", "action": "collecteachplayer", "amount": 10}, # Sometimes "Life Insurance Matures" $100
    {"text": "Life insurance matures – collect $100", "action": "collect", "amount": 100},
    {"text": "Pay hospital fees of $100", "action": "pay", "amount": 100}, # Sometimes "Pay Hospital $100"
    {"text": "Pay school fees of $150", "action": "pay", "amount": 150}, # Sometimes "Pay School Tax $150"
    {"text": "Receive $25 consultancy fee", "action": "collect", "amount": 25},
    {"text": "You are assessed for street repairs – $40 per house – $115 per hotel", "action": "repairs", "house_cost": 40, "hotel_cost": 115}, # Needs houses/hotels implemented
    {"text": "You have won second prize in a beauty contest – collect $10", "action": "collect", "amount": 10},
    {"text": "You inherit $100", "action": "collect", "amount": 100},
]


class Deck:
    """Represents a deck of Chance or Community Chest cards."""
    def __init__(self, card_type, card_definitions):
        self.card_type = card_type # "Chance" or "Chest"
        # Make a copy of the definitions to not modify the original list
        self._cards = list(card_definitions)
        self._discard_pile = [] # To hold used cards before reshuffling GOOJFC back in
        self.shuffle()

    def shuffle(self):
        """Shuffles the deck."""
        # Add cards from discard pile back into the main deck before shuffling
        self._cards.extend(self._discard_pile)
        self._discard_pile = []
        random.shuffle(self._cards)
        print(f"{self.card_type} deck shuffled.")

    def draw_card(self):
        """Draws a card from the deck."""
        if not self._cards:
            print(f"{self.card_type} deck empty, reshuffling discards...")
            self.shuffle()
            # Avoid infinite loop if somehow all cards are GOOJFC held by players
            if not self._cards:
                 print(f"CRITICAL ERROR: No cards available to draw in {self.card_type} deck!")
                 # Return a dummy 'do nothing' card or handle error appropriately
                 return {"text": "Deck Error - No Cards Available", "action": "error"}

        card = self._cards.pop(0) # Draw from the top

        # Handle GOOJFC differently - it's not immediately discarded
        if card.get("action") == "getoutofjailfree":
             # The card is given to the player, it doesn't go to discard yet.
             # We need a mechanism to track which deck it came from if returned later.
             # Add type info to the card itself when drawn.
             card['deck_type'] = self.card_type
             print(f"Drew Get Out of Jail Free Card from {self.card_type}")
        else:
            # For regular cards, add them to the discard pile
            self._discard_pile.append(card)
            print(f"Drew {self.card_type} card: {card['text']}")

        return card

    def return_card(self, card):
        """Returns a card (like a used GOOJFC) to the bottom (discard pile)."""
        # Ensure we only add valid cards back
        if isinstance(card, dict) and 'text' in card:
            print(f"Returning card to {self.card_type} discard: {card['text']}")
            self._discard_pile.append(card)
        else:
            print(f"Error: Tried to return invalid card to {self.card_type} deck.")