# view.py (Reverted to NO SetupWindow, uses set_controller_ref, WITH Path Fix)
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox # Keep for other errors maybe
import os # Keep os import
import controller # IMPORT controller needed for main block
import observer
# from tkinter import simpledialog # Not currently used

# --- GET BASE DIRECTORY ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# --- END GET BASE DIRECTORY ---


# --- get_board_square_images (With Path Fix) ---
def get_board_square_images():
    square_images = []; img_dir = os.path.join(BASE_DIR, "resources", "images", "properties")
    placeholder = os.path.join(BASE_DIR, "resources", "images", "placeholder.png"); found_placeholder = os.path.exists(placeholder)
    for i in range(40):
        path = os.path.join(img_dir, f"{i}.png")
        if os.path.exists(path): square_images.append(path)
        else: print(f"Warn: Img not found {path}"); square_images.append(placeholder if found_placeholder else "")
    return square_images


# --- REMOVED SetupWindow Class ---


class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280; height = 720

    # --- Reverted __init__ signature ---
    def __init__(self, root): # No controller passed here
        super().__init__()
        self.images = []; self.root = root; root.title("Monopoly 1920")
        # self.controller_ref = controller # No controller ref stored here initially

        root.geometry(f'{self.width}x{self.height}'); root.resizable(False, False)
        self.main_frame = ttk.Frame(root, padding=10, relief='groove')
        logo_frame = self._create_logo_frame() # Uses BASE_DIR
        middle_frame = self._create_middle_frame() # Uses BASE_DIR
        msg_frame = self._create_msg_frame()
        logo_frame.pack(fill=tk.BOTH, expand=True); middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True); self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()
        # Initial button state set by controller via event

    def _add_listeners(self):
        """Add listeners for events from the Controller."""
        listeners = {
            "update_state_box": self.update_state_box, "update_card": self.update_card,
            "update_state": self._update_text, "property_choice": self._handle_property_choice,
            "show_card_text": self._show_card_popup, "show_jail_options": self._show_jail_ui,
            "hide_jail_options": self._hide_jail_ui, "show_buy_auction_choice": self._show_buy_auction_choice,
            "show_build_sell_choice": self._show_build_sell_choice,
            "show_auction_prompt": self._show_auction_prompt, "hide_auction_ui": self._hide_auction_ui,
            "show_bailout_options": self._show_bailout_options, "hide_bailout_options": self._hide_bailout_options,
            "game_over": self._handle_game_over
        }
        for event_name, callback in listeners.items(): self.observe(event_name, callback)

    # --- ADD set_controller_ref method ---
    def set_controller_ref(self, controller):
        """Stores a reference to the controller for callbacks (needed for auction bid/pass)."""
        print("DEBUG: Setting controller reference in View.")
        self.controller_ref = controller

    # --- _create_middle_frame, _create_msg_frame, _create_logo_frame use BASE_DIR ---
    def _create_middle_frame(self):
        """Create the middle frame (Board, Card, Buttons)."""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        try: # Board Image
            board_image_path = os.path.join(BASE_DIR, "resources", "images", "monopoly.png")
            board_image = tk.PhotoImage(file=board_image_path)
            board = ttk.Label(middle_frame, image=board_image); board.pack(side='left', anchor='n', padx=75); board.image = board_image
        except tk.TclError as e: print(f"Err loading board img: {e}"); board = ttk.Label(middle_frame, text="Board Err"); board.pack(side='left', anchor='n', padx=75)
        self._preload_images()
        card_image = self.images[0] if self.images else None
        self.card = ttk.Label(middle_frame, image=card_image);
        if not card_image: self.card.config(text="Card Err");
        self.card.image = card_image
        button_frame = ttk.Frame(middle_frame, padding=10)
        self.action_buttons = {}; button_pady = (5, 5)
        # Create ALL buttons
        self.action_buttons["roll"] = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll"))
        self.action_buttons["manage_buildings"] = ttk.Button(button_frame, text="Manage Buildings", command=lambda: self._action_taken("manage_buildings"))
        self.action_buttons["mortgage"] = ttk.Button(button_frame, text="Mortgage Property", command=lambda: self._action_taken("mortgage"))
        self.action_buttons["unmortgage"] = ttk.Button(button_frame, text="Unmortgage Property", command=lambda: self._action_taken("unmortgage"))
        self.action_buttons["end_turn"] = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.action_buttons["buy_property_choice"] = ttk.Button(button_frame, text="Buy", command=lambda: self._buy_prop_choice_made())
        self.action_buttons["auction_property_choice"] = ttk.Button(button_frame, text="Auction", command=lambda: self._auction_prop_choice_made())
        self.action_buttons["pay_jail_fine"] = ttk.Button(button_frame, text="Pay $50 Fine", command=lambda: self._action_taken("pay_jail_fine"))
        self.action_buttons["roll_for_doubles"] = ttk.Button(button_frame, text="Roll for Doubles", command=lambda: self._action_taken("roll_for_doubles"))
        self.action_buttons["use_jail_card"] = ttk.Button(button_frame, text="Use Card", command=lambda: self._action_taken("use_jail_card"))
        self.action_buttons["show_build_options"] = ttk.Button(button_frame, text="Build", command=lambda: self._action_taken("show_build_options"))
        self.action_buttons["show_sell_options"] = ttk.Button(button_frame, text="Sell", command=lambda: self._action_taken("show_sell_options"))
        self.action_buttons["cancel_build_sell"] = ttk.Button(button_frame, text="Cancel", command=self._cancel_build_sell)
        self.action_buttons["declare_bankruptcy"] = ttk.Button(button_frame, text="Declare Bankruptcy", command=lambda: self._action_taken("declare_bankruptcy"))
        # Auction Input Frame & Widgets
        self.auction_frame = ttk.Frame(button_frame); self.auction_bid_label = ttk.Label(self.auction_frame, text="Min Bid:")
        self.auction_bid_entry = ttk.Entry(self.auction_frame, width=10)
        self.action_buttons["submit_bid"] = ttk.Button(self.auction_frame, text="Submit Bid", command=self._submit_auction_bid)
        self.action_buttons["pass_bid"] = ttk.Button(self.auction_frame, text="Pass", command=self._pass_auction_bid)
        self._current_choice_property_name = None
        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)
        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        return middle_frame

    def _create_msg_frame(self):
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)
        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white', wrap=tk.WORD)
        self.state_box.pack(side='left', padx=(50,15), fill=tk.BOTH, expand=True)
        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white', wrap=tk.WORD)
        self.text_box.pack(side='left', padx=(15,50), fill=tk.BOTH, expand=True)
        return msg_frame

    def _create_logo_frame(self):
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        try:
            logo_image_path = os.path.join(BASE_DIR, "resources", "images", "monopoly_logo.png")
            logo_image = tk.PhotoImage(file=logo_image_path)
            logo = ttk.Label(logo_frame, image=logo_image); logo.pack(side='top', anchor='n'); logo.image = logo_image
        except tk.TclError as e: print(f"Error loading logo: {e}"); logo = ttk.Label(logo_frame, text="Monopoly"); logo.pack(side='top', anchor='n')
        return logo_frame

    # --- _action_taken, update_card, text methods, preload_images - unchanged ---
    def _action_taken(self, action):
        print(f"{action} action taken")
        event_map = {
            "roll": "roll", "mortgage": "mortgage", "unmortgage": "unmortgage", "end_turn": "end_turn",
            "pay_jail_fine": "pay_jail_fine", "roll_for_doubles": "roll_for_doubles", "use_jail_card": "use_jail_card",
            "manage_buildings": "manage_buildings", "show_build_options": "show_build_options",
            "show_sell_options": "show_sell_options", "declare_bankruptcy": "declare_bankruptcy",
        }
        event_name = event_map.get(action)
        if event_name:
            event_data = self._clear_text if action == "end_turn" else None
            observer.Event(event_name, event_data)
        else:
             handled_elsewhere = ["buy_property_choice", "auction_property_choice", "submit_bid", "pass_bid", "cancel_build_sell"]
             if action not in handled_elsewhere: print(f"Warning: Unmapped action: '{action}'")

    def update_card(self, index):
        if not (0 <= index < len(self.images)): print(f"Warn: Invalid idx for update_card: {index}"); return
        card_image = self.images[index]
        if card_image:
            try: self.card['image'] = card_image; self.card.image = card_image
            except tk.TclError as e: print(f"Error updating card image: {e}")
        else: self.card.config(image=None, text="No Card Img")

    def _clear_text(self):
        print("clearing text box")
        try: self.text_box.delete(1.0, tk.END)
        except tk.TclError: pass

    def _update_text(self, text=""):
        try: self.text_box.insert(tk.END, text+"\n"); self.text_box.see(tk.END)
        except tk.TclError: pass

    def update_state_box(self, text=""):
        try: self.state_box.delete(1.0, tk.END); self.state_box.insert(tk.END, text)
        except tk.TclError: pass

    def _preload_images(self):
        self.images = []
        square_image_paths = get_board_square_images() # Uses fixed path function
        for path in square_image_paths:
            if path and os.path.exists(path):
                 try: self.images.append(tk.PhotoImage(file=path))
                 except tk.TclError as e: print(f"Err loading img {path}: {e}"); self.images.append(None)
            else: self.images.append(None)

    # --- UI State Management Methods (Keep simplified versions) ---
    def _hide_dynamic_action_buttons(self):
        dynamic_buttons = [ "buy_property_choice", "auction_property_choice", "pay_jail_fine",
                            "roll_for_doubles", "use_jail_card", "show_build_options",
                            "show_sell_options", "cancel_build_sell", "declare_bankruptcy" ]
        for name in dynamic_buttons:
             if name in self.action_buttons: self.action_buttons[name].pack_forget()
        self.auction_frame.pack_forget()

    def _show_normal_buttons(self, enable_roll=True):
        print(f"DEBUG: _show_normal_buttons called, enable_roll={enable_roll}")
        self._hide_dynamic_action_buttons()
        button_pady = (5, 5)
        for name in ["roll", "manage_buildings", "mortgage", "unmortgage", "end_turn"]:
             if name in self.action_buttons: self.action_buttons[name].pack_forget()
        if enable_roll: print("DEBUG: Packing Roll"); self.action_buttons["roll"].pack(side='top', anchor='center', pady=button_pady); self.action_buttons["roll"].state(['!disabled'])
        else: print("DEBUG: Hiding Roll")
        print("DEBUG: Packing Manage"); self.action_buttons["manage_buildings"].pack(side='top', anchor='center', pady=button_pady)
        print("DEBUG: Packing Mortgage"); self.action_buttons["mortgage"].pack(side='top', anchor='center', pady=button_pady)
        print("DEBUG: Packing Unmortgage"); self.action_buttons["unmortgage"].pack(side='top', anchor='center', pady=button_pady)
        print("DEBUG: Packing End Turn"); self.action_buttons["end_turn"].pack(side='top', anchor='center', pady=button_pady)
        for name in ["manage_buildings", "mortgage", "unmortgage", "end_turn"]:
             if name in self.action_buttons: self.action_buttons[name].state(['!disabled'])
        print("DEBUG: _show_normal_buttons finished")

    def _show_jail_ui(self, data=None):
        print("DEBUG: _show_jail_ui called")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        button_pady = (5, 5)
        self.action_buttons["pay_jail_fine"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["roll_for_doubles"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["use_jail_card"].pack(side='top', anchor='center', pady=button_pady)

    def _hide_jail_ui(self, data=None):
        print("DEBUG: _hide_jail_ui called")
        disable_roll = data.get("disable_roll", False) if isinstance(data, dict) else False
        self._show_normal_buttons(enable_roll=not disable_roll)

    def _show_buy_auction_choice(self, data):
        print("DEBUG: _show_buy_auction_choice called")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        self._current_choice_property_name = data["property_name"]; price = data["price"]
        self.action_buttons["buy_property_choice"].config(text=f"Buy for ${price}")
        # TODO: Check affordability and set state
        self.action_buttons["buy_property_choice"].pack(side='top', anchor='center', pady=(5, 5))
        self.action_buttons["auction_property_choice"].pack(side='top', anchor='center', pady=(5, 5))
        print("DEBUG: Packed Buy/Auction Buttons")
        try: self.root.update_idletasks(); print("DEBUG: Called update_idletasks")
        except tk.TclError as e: print(f"DEBUG: Error update_idletasks: {e}")

    def _buy_prop_choice_made(self):
        print("DEBUG: _buy_prop_choice_made called")
        self.action_buttons["buy_property_choice"].pack_forget(); self.action_buttons["auction_property_choice"].pack_forget()
        if self._current_choice_property_name: observer.Event("buy_property_choice", self._current_choice_property_name)
        # Controller restores UI

    def _auction_prop_choice_made(self):
        print("DEBUG: _auction_prop_choice_made called")
        self.action_buttons["buy_property_choice"].pack_forget(); self.action_buttons["auction_property_choice"].pack_forget()
        if self._current_choice_property_name: observer.Event("auction_property_choice", self._current_choice_property_name)
        # Controller starts auction

    def _show_build_sell_choice(self, data=None):
        print("DEBUG: _show_build_sell_choice called")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        button_pady = (5, 5)
        self.action_buttons["show_build_options"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["show_sell_options"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["cancel_build_sell"].pack(side='top', anchor='center', pady=button_pady)

    def _cancel_build_sell(self):
        print("DEBUG: Cancelling Build/Sell choice")
        self.action_buttons["show_build_options"].pack_forget(); self.action_buttons["show_sell_options"].pack_forget(); self.action_buttons["cancel_build_sell"].pack_forget()
        self._show_normal_buttons(enable_roll=False)

    def _handle_property_choice(self, data):
        print(f"DEBUG: _handle_property_choice: {data.get('action')}")
        action_type = data.get("action", "mortgage"); choices = data.get("choices", [])
        self.action_buttons["show_build_options"].pack_forget(); self.action_buttons["show_sell_options"].pack_forget(); self.action_buttons["cancel_build_sell"].pack_forget()
        if not choices:
            self._update_text(f"No properties for {action_type}.")
            try: # Restore buttons if choice failed (and not in bailout)
                 if not self.controller_ref._bailout_in_progress: self._show_normal_buttons(enable_roll=False)
            except AttributeError: self._show_normal_buttons(enable_roll=False) # Fallback if ref missing
            return
        popup = tk.Menu(self.root, tearoff=0)
        event_map = {"build": "build_house_selected", "sell": "sell_house_selected", "mortgage": "mortgage_specific"}
        event_name = event_map.get(action_type)
        if not event_name: popup.destroy(); self._show_normal_buttons(enable_roll=False); return
        def on_cancel(): # Popup cancel action
            print("DEBUG: Property choice cancelled");
            try:
                 if not self.controller_ref._bailout_in_progress: self._show_normal_buttons(enable_roll=False)
            except AttributeError: self._show_normal_buttons(enable_roll=False)
        create_callback = lambda ev, ch: lambda: observer.Event(ev, ch)
        for choice in choices: popup.add_command(label=choice, command=create_callback(event_name, choice))
        popup.add_separator(); popup.add_command(label="Cancel", command=on_cancel)
        try: popup.tk_popup(self.root.winfo_x() + 400, self.root.winfo_y() + 300)
        finally: pass

    def _show_auction_prompt(self, data):
        print("DEBUG: _show_auction_prompt called")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        player_name=data['player_name']; prop_name=data['property_name']; current_bid=data['current_bid']; min_bid=current_bid+1
        self._update_text(f"--- AUCTION: {prop_name} ---"); self._update_text(f"Bid: ${current_bid} (Min: ${min_bid})"); self._update_text(f"Prompting: {player_name}")
        self.auction_bid_label.config(text=f"Min Bid: ${min_bid}")
        self.auction_bid_entry.delete(0, tk.END); self.auction_bid_entry.insert(0, str(min_bid))
        self.auction_bid_label.pack(side=tk.LEFT, padx=2); self.auction_bid_entry.pack(side=tk.LEFT, padx=2)
        self.action_buttons["submit_bid"].pack(side=tk.LEFT, padx=2); self.action_buttons["pass_bid"].pack(side=tk.LEFT, padx=2)
        self.auction_frame.pack(side='top', anchor='center', pady=(10, 10))

    def _submit_auction_bid(self):
        bid_amount_str = self.auction_bid_entry.get()
        try:
            bid_amount = int(bid_amount_str)
            if hasattr(self, 'controller_ref') and self.controller_ref._auction_current_bidder:
                 player_name = self.controller_ref._auction_current_bidder.name
                 observer.Event("submit_bid", {'player_name': player_name, 'amount': bid_amount})
            else: print("ERROR: Controller ref/bidder missing.")
        except ValueError: self._update_text("Invalid bid.")
        except AttributeError: print("ERROR: controller_ref missing.")

    def _pass_auction_bid(self):
        try:
            if hasattr(self, 'controller_ref') and self.controller_ref._auction_current_bidder:
                 player_name = self.controller_ref._auction_current_bidder.name
                 observer.Event("pass_bid", player_name)
            else: print("ERROR: Controller ref/bidder missing.")
        except AttributeError: print("ERROR: controller_ref missing.")

    def _hide_auction_ui(self, data=None):
        print("DEBUG: _hide_auction_ui called")
        self.auction_frame.pack_forget()

    def _show_bailout_options(self, data):
        print("DEBUG: _show_bailout_options called")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        debt=data['debt']; cash=data['current_cash']; needed=debt-cash
        self._update_text(f"--- MUST RAISE ${needed} ---"); self._update_text(f"(Debt: ${debt} | Cash: ${cash})")
        button_pady = (5, 5)
        self.action_buttons["manage_buildings"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["mortgage"].pack(side='top', anchor='center', pady=button_pady)
        self.action_buttons["declare_bankruptcy"].pack(side='top', anchor='center', pady=button_pady)

    def _hide_bailout_options(self, data=None):
        print("DEBUG: _hide_bailout_options called")
        self.action_buttons["declare_bankruptcy"].pack_forget()

    def _handle_game_over(self, winner_name):
        print(f"DEBUG: _handle_game_over winner: {winner_name}")
        for name, button in self.action_buttons.items(): button.pack_forget(); self.auction_frame.pack_forget()
        winner_text = f"Winner: {winner_name}" if winner_name else "No Winner"
        self._update_text(f"\n================\n  GAME OVER!\n {winner_text}\n================")
        for widget in self.main_frame.winfo_children():
             if isinstance(widget, ttk.Frame):
                 for sub_widget in widget.winfo_children():
                      if isinstance(sub_widget, (ttk.Button, ttk.Entry, ttk.Frame)):
                           try: sub_widget.config(state=tk.DISABLED)
                           except tk.TclError: pass

    def _show_card_popup(self, card_text):
        print(f"DEBUG: _show_card_popup: {card_text[:30]}...")
        try:
             popup = tk.Toplevel(self.root); popup.title("Card Drawn"); popup.geometry("300x150+500+300")
             msg = tk.Message(popup, text=card_text, width=280, padx=10, pady=10, anchor=tk.CENTER)
             msg.pack(pady=10, expand=True, fill=tk.BOTH); ttk.Button(popup, text="OK", command=popup.destroy).pack(pady=10)
             popup.transient(self.root); popup.grab_set(); self.root.wait_window(popup)
        except Exception as e: print(f"Error showing popup: {e}"); self._update_text(f"CARD: {card_text}")

    # --- Keep set_controller_ref for Option A ---
    def set_controller_ref(self, controller):
        """Stores a reference to the controller for callbacks (needed for auction bid/pass)."""
        print("DEBUG: Setting controller reference in View.")
        self.controller_ref = controller


# --- Main execution block (Reverted to NO SetupWindow, uses set_controller_ref) ---
if __name__ == '__main__':
    print("DEBUG: Script started.")
    root = tk.Tk()
    print("DEBUG: Main root window created.")

    print("DEBUG: Creating Controller...")
    try:
        controller = controller.Controller(root) # Uses default __init__(root)
        print("DEBUG: Controller initialized successfully.")
    except Exception as e:
        print(f"FATAL ERROR during Controller init: {e}")
        import traceback; traceback.print_exc(); messagebox.showerror("Init Error", f"Failed to init controller:\n{e}")
        try: root.destroy()
        except: pass
        exit()

    # --- Set controller reference using original method ---
    if hasattr(controller, '_view') and isinstance(controller._view, View):
        print("DEBUG: Setting controller reference in View.")
        controller._view.set_controller_ref(controller) # Call the View's method
    else:
        print("Warning: Could not set controller reference in View via controller._view.")

    print("Controller and View initialized.")
    print("DEBUG: Starting mainloop...")
    root.mainloop()
    print("DEBUG: mainloop finished.")