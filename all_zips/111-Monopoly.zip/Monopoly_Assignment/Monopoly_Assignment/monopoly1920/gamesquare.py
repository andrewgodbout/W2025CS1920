# gamesquare.py
import player
import observer # Import needed for mortgage event
# Import for type checking only
import typing
if typing.TYPE_CHECKING:
    import gameboard


class GameSquare:
    def __init__(self, name, price, rents, space, color, is_utility, is_railroad, build_cost):
        """Constructor for the GameSquare class"""
        self.__name = name
        self.__price = price
        self.__rents = rents # List: [base, r1, r2, r3, r4, r5(hotel)]
        self.__color = color if color else "None" # Ensure color is not empty string
        self.__space = space
        self.__is_utility = is_utility
        self.__is_railroad = is_railroad
        self.__owner = None
        self.__is_mortgaged = False
        self.__build_cost = build_cost if space == "Property" else 0
        self.__house_count = 0
        self.__hotel_count = 0
        self.__group_members = [] # List of other GameSquare objects in the same group

    # --- ACCESSOR METHODS ---
    @property
    def owner(self): return self.__owner
    @owner.setter
    def owner(self, owner): self.__owner = owner

    @property
    def name(self): return self.__name
    @property
    def price(self): return self.__price
    @property
    def color(self): return self.__color
    @property
    def space(self): return self.__space
    @property
    def is_utility(self): return self.__is_utility
    @property
    def is_railroad(self): return self.__is_railroad
    @property
    def is_mortgaged(self): return self.__is_mortgaged
    @property
    def build_cost(self): return self.__build_cost
    @property
    def house_count(self): return self.__house_count
    @property
    def hotel_count(self): return self.__hotel_count
    @property
    def rent(self): return self.__rents[0] if self.__rents else 0 # Base rent
    @property
    def rents(self): return self.__rents # Full list
    @property
    def group_members(self): return self.__group_members

    # --- SETTER for group linking ---
    def set_group_members(self, group_list):
        self.__group_members = [prop for prop in group_list if prop is not self]

    # --- METHODS ---
    def mortgage(self):
        """Mortgages property. Returns True if successful."""
        if self.house_count > 0 or self.hotel_count > 0:
            observer.Event("update_state", f"Sell buildings first: {self.name}.")
            return False
        if self.owner is None: return False # Cannot mortgage unowned
        if self.__is_mortgaged: return False # Already mortgaged

        amt = self.price // 2
        self.__is_mortgaged = True
        self.owner.money += amt
        # observer.Event("update_state", f"Mortgaged {self.name} for ${amt}.") # Controller handles msg
        return True

    def unmortgage(self):
        """Unmortgages property if owner has funds. Returns True if successful."""
        if not self.__is_mortgaged or self.owner is None: return False

        cost_to_unmortgage = (self.price // 2) + (self.price // 20) # Cost + 10% interest

        if self.owner.money >= cost_to_unmortgage:
            self.__is_mortgaged = False
            self.owner.money -= cost_to_unmortgage
            # observer.Event("update_state", f"Unmortgaged {self.name} for ${cost_to_unmortgage}.") # Controller handles msg
            return True
        else:
            observer.Event("update_state", f"Need ${cost_to_unmortgage} for {self.name}.")
            return False

    def can_be_purchased(self):
        """Checks if square type is purchasable."""
        non_purchasable_types = ["Tax", "Chance", "Chest", "GotoJail", "Jail", "Parking", "Go"]
        if self.space in non_purchasable_types: return False
        if self.price <= 0: return False # Price must be positive
        return True

    def calculate_rent_or_tax(self, dice_sum: int, game_board: 'GameBoard'):
        """Calculates rent/tax based on ownership, buildings, monopolies."""
        if (self.owner is None and self.space != "Tax") or self.__is_mortgaged: return 0

        if self.is_utility:
            if not self.owner: return 0
            count = self.owner.utility_count
            if count == 1: return 4 * dice_sum
            elif count >= 2: return 10 * dice_sum
            else: return 0
        if self.is_railroad:
            if not self.owner: return 0
            count = self.owner.railroad_count
            return 25 * (2 ** (count - 1)) if count > 0 else 0
        if self.space == "Tax":
            return self.rents[0] # Use base rent value

        if self.space == "Property":
            if not self.owner: return 0
            if self.hotel_count == 1: return self.rents[5] if len(self.rents) > 5 else 0
            if self.house_count > 0: return self.rents[self.house_count] if len(self.rents) > self.house_count else 0
            # No buildings: Check Monopoly
            if self.owner.has_monopoly(self.color, game_board): return self.rents[0] * 2
            else: return self.rents[0] # Base rent
        else: return 0 # Other squares

    def add_building(self):
        """Adds house or converts to hotel."""
        if self.hotel_count == 1: return False
        if self.house_count < 4: self.house_count += 1; return True
        elif self.house_count == 4: self.house_count = 0; self.hotel_count = 1; return True
        return False

    def remove_building(self):
        """Removes hotel (to 4 houses) or house."""
        if self.hotel_count == 1: self.hotel_count = 0; self.house_count = 4; return True
        elif self.house_count > 0: self.house_count -= 1; return True
        return False

    # Internal setters for building counts
    @house_count.setter
    def house_count(self, value):
        if 0 <= value <= 4: self.__house_count = value
    @hotel_count.setter
    def hotel_count(self, value):
        if 0 <= value <= 1: self.__hotel_count = value

    def __str__(self):
        """String representation for debugging or simple display."""
        owner_name = self.owner.name if self.owner else "None"
        mort_status = " (M)" if self.is_mortgaged else ""
        build_status = ""
        if self.hotel_count == 1: build_status = " (H)"
        elif self.house_count > 0: build_status = f" ({self.house_count}h)"
        base_rent = self.rents[0] if self.rents else 0
        return f"{self.name} (${self.price}) Rent:${base_rent}{build_status} Owner:{owner_name}{mort_status}"