# controller.py (Reverted to NO AI/Setup, WITH Path Fix)
import os
import view # Keep import
import random
import gameboard
import player as plr
import gamesquare
import observer
import cards

# --- GET BASE DIRECTORY ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# --- END GET BASE DIRECTORY ---

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()

        # --- Controller setup ---
        # --- APPLY PATH FIX ---
        csv_path = os.path.join(BASE_DIR, "resources", "data", "board.csv")
        print(f"DEBUG: Attempting to load board from: {csv_path}") # Add debug print
        # --- END PATH FIX ---

        players = self._create_players(3) # Fixed number of players
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._chance_deck = cards.Deck("Chance", cards.CHANCE_CARDS)
        self._community_chest_deck = cards.Deck("Community Chest", cards.COMMUNITY_CHEST_CARDS)

        # --- Create View (Standard way for reverted version) ---
        self._view = view.View(root) # Does not pass controller

        # --- Initialize state variables ---
        self.__dice_rolled = False
        self.__roll_count = 0
        self._auction_in_progress = False; self._auction_property = None # etc...
        self._bailout_in_progress = False; self._player_in_bailout = None # etc...
        self._choice_pending = False

        # --- Initial state updates ---
        self._add_listeners() # Call listeners AFTER view created
        current_player = self._gameboard.get_current_player()
        # Check if board loaded successfully before accessing player/squares
        if self._gameboard.get_all_squares() and current_player:
            observer.Event("update_state", f"{current_player.name}'s turn.")
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", current_player.position)
            # --- Set initial UI state directly ---
            if current_player.is_in_jail:
                observer.Event("update_state", f"{current_player.name} is in Jail.")
                observer.Event("show_jail_options", None)
            else:
                observer.Event("hide_jail_options", None) # Show normal buttons
        else:
             observer.Event("update_state", "ERROR: Board did not load correctly!")

        # self._set_expected_val() # Optional
        print("DEBUG: Controller __init__ finished.")


    def _add_listeners(self):
        """Add listeners from the view"""
        print("DEBUG: Inside _add_listeners")
        # Add listener registrations here (should include all needed actions)
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("buy_property_choice", self._buy_property_action)
        self.observe("auction_property_choice", self._auction_property_action)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("manage_buildings", self._manage_buildings_action)
        self.observe("show_build_options", self._show_build_options)
        self.observe("show_sell_options", self._show_sell_options)
        self.observe("build_house_selected", self._build_house_on_selected)
        self.observe("sell_house_selected", self._sell_house_on_selected)
        self.observe("pay_jail_fine", self._pay_jail_fine_action)
        self.observe("roll_for_doubles", self._roll_for_doubles_action)
        self.observe("use_jail_card", self._use_jail_card_action)
        self.observe("submit_bid", self._handle_bid)
        self.observe("pass_bid", self._handle_pass)
        self.observe("declare_bankruptcy", self._declare_bankruptcy_action)


    # --- Use original _create_players ---
    def _create_players(self, num_players):
        """Creates the specified number of human players."""
        players = []
        if not (2 <= num_players <= 6): num_players = 3 # Default/Safety
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500) # Only creates human Player
            players.append(player)
        print(f"Created {len(players)} human players.")
        return players

    # --- NO _start_player_turn method in this version ---

    def _set_expected_val(self):
        """Calculates and displays non-standard expected value."""
        try:
            current_player = self._gameboard.get_current_player();
            if not current_player or not self._gameboard.get_all_squares(): return
            ev = self._gameboard.calculate_expected_value(current_player.position, 0)
            ev = round(ev, 2); observer.Event("update_state", f"Expected value: {ev}")
            current_player.luck += ev
        except RecursionError: observer.Event("update_state", "EV calc too deep.")
        except Exception as e: print(f"EV calc Error: {e}"); observer.Event("update_state", "Error calculating EV.")

    def _roll_dice(self):
        """Simulate rolling two dice, return sum and if doubles were rolled."""
        dice1=random.randint(1,6); dice2=random.randint(1,6); dice_sum=dice1+dice2; is_doubles=(dice1==dice2)
        roll_msg = f"Doubles: {dice1}+{dice2}={dice_sum}" if is_doubles else f"Rolled: {dice1}+{dice2}={dice_sum}"
        observer.Event("update_state", roll_msg); return dice_sum, is_doubles

    def _send_to_jail(self, player):
        """Sends a player to jail and updates state."""
        player.send_to_jail(); self.__dice_rolled = True; self.__roll_count = 1
        observer.Event("update_state_box", str(self._gameboard)); observer.Event("update_card", player.position)

    def _handle_landing(self, player, dice_sum):
        """Handles actions immediately after a player lands on a square."""
        position = player.position
        if not (0 <= position < 40): position = 0; player.position = 0
        square = self._gameboard.get_square(position);
        if not square: print(f"ERROR: Invalid square at {position}"); return False
        observer.Event("update_card", player.position); observer.Event("update_state", f"{player.name} landed on {square.name}")

        GO_TO_JAIL_POSITION = 30
        if position == GO_TO_JAIL_POSITION: observer.Event("update_state", "-> Go To Jail!"); self._send_to_jail(player); return False
        elif square.space == "Chance" or square.space == "Chest":
            deck = self._chance_deck if square.space == "Chance" else self._community_chest_deck
            drawn_card = deck.draw_card(); observer.Event("show_card_text", drawn_card.get('text', 'Card Error'))
            self._execute_card_action(player, drawn_card)
            if player.is_in_jail or player.bankrupt_declared: return False
        elif square.owner is not None or square.space == "Tax": # Rent or Tax
            rent_or_tax = square.calculate_rent_or_tax(dice_sum, self._gameboard)
            if rent_or_tax > 0:
                creditor = "Bank" if square.space == "Tax" else square.owner
                creditor_name = creditor.name if isinstance(creditor, plr.Player) else 'Bank'
                observer.Event("update_state", f"Owes ${rent_or_tax} to {creditor_name}")
                if player.money < rent_or_tax:
                    observer.Event("update_state", f"Insufficient funds!"); debt_info = {"debt": rent_or_tax, "creditor": creditor}
                    self._check_funds_and_initiate_bailout(player, debt_info); return True
                else: player.pay_rent(square, dice_sum, self._gameboard); msg = f"Paid Tax: ${rent_or_tax}" if square.space=="Tax" else f"Rent paid: ${rent_or_tax}"; observer.Event("update_state", msg)
        elif square.can_be_purchased() and square.owner is None: # Unowned property
            print(f"DEBUG: Checking Buy/Auction for {square.name}. Price: {square.price}, Player Money: {player.money}")
            observer.Event("update_state", f"{square.name} unowned (${square.price}).")
            if player.money >= square.price:
                print("DEBUG: Sending show_buy_auction_choice event."); observer.Event("update_state", "Choose Buy or Auction.")
                self._choice_pending = True; observer.Event("show_buy_auction_choice", {"property_name": square.name, "price": square.price})
            else: print("DEBUG: Cannot afford. Starting auction."); observer.Event("update_state", f"Cannot afford. Auction starts."); self._start_auction(square)
        else: observer.Event("update_state", f"Landed on {square.name}.") # Other squares
        if player.money < 0 and not player.bankrupt_declared and not self._bailout_in_progress: self._check_funds_and_initiate_bailout(player, {"debt": 1, "creditor": "Bank"})
        return True

    def _handle_roll_dice(self):
        """Handles non-jail dice roll, move, landing. Returns True if turn continues."""
        player = self._gameboard.get_current_player()
        if self.__dice_rolled and self.__roll_count > 0: observer.Event("update_state", "Already rolled."); return True
        dice_sum, is_doubles = self._roll_dice(); self.__dice_rolled = True; self.__roll_count += 1
        if is_doubles:
            player.doubles_count += 1
            if player.doubles_count == 3: observer.Event("update_state", "3rd double!"); self._send_to_jail(player); return False
            else: self.__dice_rolled = False # Allow roll again
        else: player.doubles_count = 0
        if not player.is_in_jail: # Move if not just jailed
            player.move(dice_sum)
            if not self._handle_landing(player, dice_sum): return False # Landing ended turn
        return True

    # --- Modify _end_player_turn to set UI state directly ---
    def _end_player_turn(self, callback):
        """Ends turn, advances player, sets UI for next turn."""
        current_player = self._gameboard.get_current_player()
        print("\nDEBUG: === ENTERING _end_player_turn ===") # Keep debug prints
        print(f"DEBUG: Player: {current_player.name}")
        print(f"DEBUG: State BEFORE checks:")
        print(f"DEBUG:   _auction_in_progress = {self._auction_in_progress}")
        print(f"DEBUG:   _bailout_in_progress = {self._bailout_in_progress}")
        print(f"DEBUG:   __roll_count = {self.__roll_count}")
        print(f"DEBUG:   __dice_rolled = {self.__dice_rolled}")
        print(f"DEBUG:   player.is_in_jail = {current_player.is_in_jail}")
        print(f"DEBUG:   player.doubles_count = {current_player.doubles_count}")
        print("DEBUG: ===============================")

        if self._auction_in_progress: print("DEBUG: END TURN BLOCKED: Auction"); observer.Event("update_state", "Cannot end turn during auction."); return
        if self._bailout_in_progress and self._player_in_bailout == current_player: print("DEBUG: END TURN BLOCKED: Bailout"); observer.Event("update_state", "Must resolve debt/bankruptcy."); return
        if self.__roll_count == 0 and not current_player.is_in_jail: print("DEBUG: END TURN BLOCKED: Roll count 0"); observer.Event("update_state", "Roll first."); return
        if not self.__dice_rolled and current_player.doubles_count > 0 and not current_player.is_in_jail: print("DEBUG: END TURN BLOCKED: Doubles pending"); observer.Event("update_state", "Rolled doubles, must roll again."); return

        print("DEBUG: End turn checks passed. Proceeding...")
        current_player.doubles_count = 0; self.__dice_rolled = False; self.__roll_count = 0
        player_name_who_finished = current_player.name
        next_player_name = self._gameboard.next_turn() # Advance player
        new_player = self._gameboard.get_current_player()
        if new_player is None: return # Game likely over

        observer.Event("update_state_box", str(self._gameboard)); observer.Event("update_card", new_player.position)
        if callback: callback(); observer.Event("update_state", f"{player_name_who_finished}'s turn ended.")
        observer.Event("update_state", f"{new_player.name}'s turn.")

        # --- ADD BACK UI setup for new player ---
        if new_player.is_in_jail:
            observer.Event("update_state", f"{new_player.name} is in Jail.")
            observer.Event("show_jail_options", None)
        else:
            observer.Event("hide_jail_options", None) # Show normal buttons, enable roll
        # --- END ADD BACK ---

        # self._set_expected_val() # Optional

    # --- ADD HELPER METHOD ---
    def _restore_normal_ui_mid_turn(self):
        """Sends event to View to show normal buttons, enabling Roll based on doubles status."""
        enable_roll = not self.__dice_rolled # Roll enabled ONLY if last roll was doubles (__dice_rolled == False)
        print(f"DEBUG: Restoring normal UI mid-turn, enable_roll={enable_roll}")
        observer.Event("hide_jail_options", {"disable_roll": not enable_roll})

    def _buy_property_action(self, property_name):
        """Player chose to buy the property."""
        self._choice_pending = False
        if self._auction_in_progress or self._bailout_in_progress: return
        player = self._gameboard.get_current_player(); square = self._find_property_by_name(property_name)
        if not square or square.owner is not None or not square.can_be_purchased():
            observer.Event("update_state", f"Cannot buy now.")
            self._restore_normal_ui_mid_turn() # Call helper on failure
            return
        if player.money >= square.price:
            if player.buy_property(square):
                observer.Event("update_state", f"Bought {square.name}.")
                observer.Event("update_state_box", str(self._gameboard))
            else: observer.Event("update_state", f"Purchase failed.")
        else: observer.Event("update_state", f"Cannot afford {square.name}.")
        self._restore_normal_ui_mid_turn() # Call helper after action attempt

    def _auction_property_action(self, property_name):
        """Player chose to auction the property."""
        self._choice_pending = False
        if self._auction_in_progress or self._bailout_in_progress: return
        square = self._find_property_by_name(property_name)
        if square and square.owner is None and square.can_be_purchased(): observer.Event("update_state", f"Auctioning {square.name}."); self._start_auction(square)
        else: observer.Event("update_state", f"Cannot auction now."); self._restore_normal_ui_mid_turn()

    # --- Auction Methods ---
    def _start_auction(self, square: gamesquare.GameSquare):
        print("DEBUG: _start_auction called"); # Keep debugs
        if self._auction_in_progress: return
        self._auction_in_progress = True; self._auction_property = square; self._auction_current_bid = 0; self._auction_high_bidder = None
        self._auction_participants = [p for p in self._gameboard.get_all_players_incl_current() if not p.bankrupt_declared]
        current_player_turn = self._gameboard.get_current_player()
        try: idx=self._auction_participants.index(current_player_turn); n=len(self._auction_participants); offset=(idx+1)%n; self._auction_participants=[self._auction_participants[(offset+i)%n] for i in range(n)]
        except ValueError: pass; 
        except Exception as e: print(f"Auction order err: {e}")
        self._auction_player_iterator = iter(self._auction_participants); observer.Event("update_state", f"--- Auction: {square.name} ---"); self._next_auction_bidder()

    def _next_auction_bidder(self):
        """Advances to the next player in the auction or ends the auction."""
        print("DEBUG: _next_auction_bidder called")
        if not self._auction_participants: # Check if list empty before starting loop
             observer.Event("update_state", "Auction ended: No bidders left.")
             self._end_auction()
             return
        try:
            # This loop finds the next player who is still participating
            while True:  # Start of loop
                next_p = next(self._auction_player_iterator) # Get next from iterator
                # Check if this player is still in the list of active participants
                if next_p in self._auction_participants:
                    self._auction_current_bidder = next_p # Found the next bidder
                    break # <--- EXIT the 'while True' loop HERE (This is inside the loop)
            # <-- Execution continues here AFTER the loop is exited via 'break' -->

            # This block runs only if a valid bidder was found above
            print(f"DEBUG: Next bidder is {self._auction_current_bidder.name}")
            bidder_name = self._auction_high_bidder.name if self._auction_high_bidder else 'None'
            observer.Event("update_state", f"Bid: ${self._auction_current_bid} (High: {bidder_name})")
            observer.Event("update_state", f"{self._auction_current_bidder.name}: Bid/Pass?")
            print("DEBUG: Sending show_auction_prompt event")
            observer.Event("show_auction_prompt", {
                "player_name": self._auction_current_bidder.name,
                "property_name": self._auction_property.name,
                "current_bid": self._auction_current_bid
            })

        except StopIteration: # This runs if the iterator runs out *during* the while loop
            # This means a full rotation happened since the last bid or since the start
            print("DEBUG: StopIteration in _next_auction_bidder - ending auction?")
            if len(self._auction_participants) == 1:
                 # If only one participant was left *before* this rotation ended, they win
                 self._auction_high_bidder = self._auction_participants[0]
                 observer.Event("update_state", f"{self._auction_high_bidder.name} wins (last bidder).")
            elif self._auction_high_bidder: # If there was a high bidder from previous rounds
                 observer.Event("update_state", "Bidding rotation complete.")
            else: # No bids were placed at all
                 observer.Event("update_state", "All passed.")
            self._end_auction() # End the auction in all StopIteration cases

        except Exception as e: # Catch any other errors
            print(f"ERROR in _next_auction_bidder: {e}")
            self._end_auction() # Try to end gracefully

    def _handle_bid(self, bid_data):
        print(f"DEBUG: _handle_bid: {bid_data}")
        if not self._auction_in_progress or not isinstance(bid_data, dict): return
        p_name=bid_data.get('player_name'); bid=bid_data.get('amount')
        if not self._auction_current_bidder or self._auction_current_bidder.name != p_name: observer.Event("update_state", f"Wait turn."); return
        player = self._auction_current_bidder
        try: bid = int(bid)
        except (ValueError, TypeError): observer.Event("update_state", "Invalid bid."); self._next_auction_bidder(); return
        if bid <= self._auction_current_bid: observer.Event("update_state", f"Bid > ${self._auction_current_bid}."); self._next_auction_bidder(); return
        if bid > player.money: observer.Event("update_state", f"Need ${bid}."); self._next_auction_bidder(); return
        self._auction_current_bid = bid; self._auction_high_bidder = player; observer.Event("update_state", f"{player.name} bids ${bid}!")
        try: idx=self._auction_participants.index(player); n=len(self._auction_participants); offset=(idx+1)%n; rot=[self._auction_participants[(offset+i)%n] for i in range(n)]; self._auction_player_iterator=iter(rot)
        except ValueError: self._auction_player_iterator = iter(self._auction_participants)
        self._next_auction_bidder()

    def _handle_pass(self, player_name):
        print(f"DEBUG: _handle_pass: {player_name}")
        if not self._auction_in_progress: return
        if not self._auction_current_bidder or self._auction_current_bidder.name != player_name: observer.Event("update_state", f"Wait turn."); return
        player = self._auction_current_bidder; observer.Event("update_state", f"{player.name} passes.")
        try: self._auction_participants.remove(player)
        except ValueError: pass
        if len(self._auction_participants) <= 1:
             if len(self._auction_participants)==1: self._auction_high_bidder = self._auction_participants[0]
             observer.Event("update_state","Last bidder." if len(self._auction_participants)==1 else "No bidders."); self._end_auction(); return
        self._next_auction_bidder()

    def _end_auction(self):
        print("DEBUG: _end_auction called")
        if not self._auction_in_progress: return
        prop = self._auction_property; winner = self._auction_high_bidder; price = self._auction_current_bid
        observer.Event("update_state", f"--- Auction End: {prop.name} ---")
        if winner and price > 0:
            observer.Event("update_state", f"{winner.name} wins for ${price}!")
            winner.money -= price; prop.owner = winner; winner.add_property(prop)
            if winner.money < 0: self._check_funds_and_initiate_bailout(winner, {"debt": abs(winner.money), "creditor": "Bank"})
        else: observer.Event("update_state", f"{prop.name} not sold."); prop.owner = None
        self._auction_in_progress=False; self._auction_property=None; self._auction_current_bid=0; self._auction_high_bidder=None; self._auction_participants=[]; self._auction_player_iterator=None; self._auction_current_bidder=None
        observer.Event("hide_auction_ui", None); observer.Event("update_state_box", str(self._gameboard))
        self._restore_normal_ui_mid_turn() # Restore UI
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn continues.")

    # --- Asset Management ---
    def _mortgage(self, data):
        player=self._gameboard.get_current_player()
        if self._auction_in_progress or (self._bailout_in_progress and self._player_in_bailout != player): observer.Event("update_state", "Cannot mortgage now."); return
        deeds = [d for d in player.properties if not d.is_mortgaged and d.house_count == 0 and d.hotel_count == 0]
        observer.Event("property_choice", {"action": "mortgage", "choices": [d.name for d in deeds]})

    def _mortgage_specific(self, deed_name):
        player=self._gameboard.get_current_player()
        if self._auction_in_progress or (self._bailout_in_progress and self._player_in_bailout != player): return
        prop = self._find_property_by_name(deed_name)
        if prop and prop.owner is player:
            if player.mortgage_property(deed_name):
                observer.Event("update_state", f"{deed_name} mortgaged")
                if self._bailout_in_progress:
                    if player.money >= self._bailout_debt_amount: self._resolve_bailout(player)
                    else: observer.Event("update_state", f"Need ${self._bailout_debt_amount - player.money}.")
            else: observer.Event("update_state", f"Mortgage failed: {deed_name}")
        else: observer.Event("update_state", f"Cannot mortgage {deed_name}.")
        observer.Event("update_state_box", str(self._gameboard))

    def _unmortgage(self, data):
        player=self._gameboard.get_current_player()
        if self._auction_in_progress or self._bailout_in_progress: observer.Event("update_state", "Cannot unmortgage now."); return
        deed_name = player.unmortgage_property()
        if deed_name: observer.Event("update_state", f"Unmortgaged: {deed_name}"); observer.Event("update_state_box", str(self._gameboard))
        else: observer.Event("update_state", "Failed to unmortgage.")

    # --- Bailout / Bankruptcy ---
    def _resolve_bailout(self, player):
        debt=self._bailout_debt_amount; creditor=self._bailout_creditor; c_name=creditor.name if isinstance(creditor, plr.Player) else str(creditor)
        observer.Event("update_state", f"Paying ${debt} to {c_name}."); player.money -= debt
        if isinstance(creditor, plr.Player): creditor.money += debt
        self._bailout_in_progress=False; self._player_in_bailout=None; self._bailout_debt_amount=0; self._bailout_creditor=None
        observer.Event("hide_bailout_options", None); observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_state", f"{player.name}'s turn continues."); self._restore_normal_ui_mid_turn()

    def _declare_bankruptcy_action(self, data=None):
        if self._bailout_in_progress and self._player_in_bailout == self._gameboard.get_current_player():
            player=self._player_in_bailout; creditor=self._bailout_creditor
            observer.Event("update_state", f"{player.name} declares bankruptcy!"); self._process_bankruptcy(player, creditor)
        else: observer.Event("update_state", "Cannot declare bankruptcy now.")

    def _process_bankruptcy(self, bankrupt_player, creditor):
        c_name = creditor.name if isinstance(creditor, plr.Player) else str(creditor)
        observer.Event("update_state", f"--- Processing Bankruptcy: {bankrupt_player.name} -> {c_name} ---")
        liquid_cash = sum((p.house_count + p.hotel_count*5)*(p.build_cost//2) for p in bankrupt_player.properties if p.build_cost>0)
        if liquid_cash > 0: # Sell buildings
             for prop in list(bankrupt_player.properties):
                  while prop.hotel_count > 0 or prop.house_count > 0:
                       if not prop.remove_building(): break
             bankrupt_player.money += liquid_cash; observer.Event("update_state", f"Liquidated buildings: ${liquid_cash}.")
        # Transfer Assets
        if isinstance(creditor, plr.Player): # To Player
            observer.Event("update_state", f"Transferring assets to {creditor.name}.")
            creditor.money += bankrupt_player.money; bankrupt_player.money = 0
            creditor.get_out_of_jail_cards += bankrupt_player.get_out_of_jail_cards
            if bankrupt_player.get_out_of_jail_cards > 0: observer.Event("update_state", f"Transferred GOOJFC(s).")
            bankrupt_player.get_out_of_jail_cards = 0
            for prop in list(bankrupt_player.properties):
                prop.owner = creditor; creditor.add_property(prop); bankrupt_player.remove_property(prop)
                if prop.is_mortgaged: interest=prop.price//20; observer.Event("update_state", f"{creditor.name} pays ${interest} interest."); creditor.money -= interest
                if creditor.money < 0: observer.Event("update_state", f"Warning: {creditor.name} has negative balance!") # Remove recursive check
        elif creditor == "Bank" or creditor == "Players": # To Bank
            observer.Event("update_state", "Returning assets to Bank."); bankrupt_player.money = 0
            if bankrupt_player.get_out_of_jail_cards > 0: observer.Event("update_state", f"Returned GOOJFC(s).") # TODO: Return cards
            bankrupt_player.get_out_of_jail_cards = 0
            for prop in list(bankrupt_player.properties): prop.owner=None; prop.house_count=0; prop.hotel_count=0; prop.is_mortgaged=False; bankrupt_player.remove_property(prop) # TODO: Auction?
        # Finalize
        bankrupt_player.declare_bankrupt(); observer.Event("update_state", f"--- {bankrupt_player.name} Bankrupt & Eliminated! ---")
        self._bailout_in_progress=False; self._player_in_bailout=None; observer.Event("hide_bailout_options", None); observer.Event("update_state_box", str(self._gameboard))
        # Check Game Over
        active_players = [p for p in self._gameboard.get_all_players_incl_current() if not p.bankrupt_declared]
        if len(active_players) == 1: observer.Event("update_state", f"--- GAME OVER! Winner: {active_players[0].name}! ---"); observer.Event("game_over", active_players[0].name)

    def _check_funds_and_initiate_bailout(self, player, debt_info):
        if self._bailout_in_progress and self._player_in_bailout is player: return
        debt=debt_info["debt"]; creditor=debt_info["creditor"]
        potential = player.money + sum((p.house_count + p.hotel_count*5)*(p.build_cost//2) for p in player.properties if p.build_cost>0) \
                  + sum((p.price//2) for p in player.properties if not p.is_mortgaged and p.house_count==0 and p.hotel_count==0)
        if potential < debt: observer.Event("update_state", f"Cannot raise ${debt}. Bankruptcy."); self._process_bankruptcy(player, creditor)
        else:
            self._bailout_in_progress=True; self._player_in_bailout=player; self._bailout_debt_amount=debt; self._bailout_creditor=creditor
            c_name = creditor.name if isinstance(creditor, plr.Player) else str(creditor)
            observer.Event("update_state", f"--- {player.name} must raise ${debt} for {c_name}! ---"); observer.Event("update_state", "Use Sell/Mortgage.")
            observer.Event("show_bailout_options", {"debt": debt, "current_cash": player.money})

    # --- Building Management Actions ---
    def _manage_buildings_action(self, data):
        player=self._gameboard.get_current_player()
        if self._auction_in_progress or (self._bailout_in_progress and self._player_in_bailout != player): observer.Event("update_state", "Cannot manage now."); return
        if self.__roll_count == 0 and not player.is_in_jail: observer.Event("update_state", "Roll first."); return
        if self._bailout_in_progress: self._show_sell_options(); return # Bailout only allows sell
        can_build = player.can_build_on_any_property(self._gameboard)
        can_sell = player.can_sell_any_building()
        if not can_build and not can_sell: observer.Event("update_state", "No buildings to manage."); self._restore_normal_ui_mid_turn(); return
        observer.Event("update_state", "Choose Build, Sell, or Cancel."); observer.Event("show_build_sell_choice", None)

    def _show_build_options(self, data=None):
        player=self._gameboard.get_current_player(); buildable_props=[]
        checked_colors = set()
        for prop in player.properties:
            color = prop.color
            if prop.space!="Property" or not color or color=="None" or color in checked_colors: continue
            checked_colors.add(color)
            if player.has_monopoly(color, self._gameboard):
                 levels=player._get_group_building_levels(color, self._gameboard);
                 if levels is None: continue
                 min_lvl=min(levels); group=player.get_properties_in_group(self._gameboard, color)
                 for gp in group:
                      if gp.owner is player:
                           lvl=5 if gp.hotel_count else gp.house_count
                           if gp.hotel_count==0 and lvl==min_lvl and player.money>=gp.build_cost: buildable_props.append(gp)
        names = sorted(list(set([p.name for p in buildable_props])))
        if names: observer.Event("property_choice", {"action": "build", "choices": names})
        else:
            observer.Event("update_state", "No properties eligible for building.")
            self._restore_normal_ui_mid_turn() # Restore UI

    def _show_sell_options(self, data=None):
        player=self._gameboard.get_current_player(); sellable_props=[]
        checked_colors = set()
        for prop in player.properties:
            color = prop.color
            if prop.space!="Property" or not color or color=="None" or color in checked_colors: continue
            checked_colors.add(color)
            if player.has_monopoly(color, self._gameboard):
                 levels=player._get_group_building_levels(color, self._gameboard);
                 if levels is None or all(lvl==0 for lvl in levels): continue
                 max_lvl=max(levels); group=player.get_properties_in_group(self._gameboard, color)
                 for gp in group:
                      if gp.owner is player:
                           lvl = 5 if gp.hotel_count else gp.house_count
                           if lvl > 0 and lvl == max_lvl: sellable_props.append(gp)
        names = sorted(list(set([p.name for p in sellable_props])))
        if names: observer.Event("property_choice", {"action": "sell", "choices": names})
        else:
            observer.Event("update_state", "No properties eligible for selling.")
            if not self._bailout_in_progress: self._restore_normal_ui_mid_turn() # Restore UI

    def _build_house_on_selected(self, prop_name):
        if self._bailout_in_progress: return
        player=self._gameboard.get_current_player(); square=self._find_property_by_name(prop_name)
        if square: player.build_house(square, self._gameboard) # player method sends updates
        else: observer.Event("update_state", f"Error finding {prop_name}.")
        self._restore_normal_ui_mid_turn() # Restore UI after attempt

    def _sell_house_on_selected(self, prop_name):
        player=self._gameboard.get_current_player()
        if self._bailout_in_progress and self._player_in_bailout != player: return
        square=self._find_property_by_name(prop_name)
        if square:
            sold_ok = player.sell_house(square, self._gameboard)
            if sold_ok:
                if not self._bailout_in_progress: self._restore_normal_ui_mid_turn() # Restore UI
                elif player.money >= self._bailout_debt_amount: self._resolve_bailout(player)
                else: observer.Event("update_state", f"Need ${self._bailout_debt_amount-player.money}."); observer.Event("show_bailout_options", {"debt":self._bailout_debt_amount, "current_cash":player.money})
            elif not self._bailout_in_progress: self._restore_normal_ui_mid_turn() # Restore UI on fail
        else:
            observer.Event("update_state", f"Error finding {prop_name}.")
            if not self._bailout_in_progress: self._restore_normal_ui_mid_turn()

    # --- Jail Actions ---
    def _pay_jail_fine_action(self, data):
        player=self._gameboard.get_current_player(); JAIL_FINE=50
        if not player.is_in_jail: observer.Event("update_state", "Not in jail."); return
        if player.money < JAIL_FINE: observer.Event("update_state", f"Need ${JAIL_FINE}."); return
        player.money-=JAIL_FINE; player.is_in_jail=False; player.turns_in_jail=0; observer.Event("update_state", f"Paid ${JAIL_FINE}, out."); observer.Event("update_state_box", str(self._gameboard))
        self.__dice_rolled=False; self.__roll_count=0; player.doubles_count=0; observer.Event("update_state", "Roll dice."); observer.Event("hide_jail_options", None)

    def _roll_for_doubles_action(self, data):
        player=self._gameboard.get_current_player(); JAIL_FINE=50
        if not player.is_in_jail: observer.Event("update_state", "Not in jail."); return
        player.turns_in_jail += 1; observer.Event("update_state", f"Roll attempt {player.turns_in_jail}...")
        dice_sum, is_doubles = self._roll_dice(); self.__roll_count=1; self.__dice_rolled=True
        if is_doubles:
            observer.Event("update_state", "Doubles! Out."); player.is_in_jail=False; player.turns_in_jail=0
            player.move(dice_sum); self._handle_landing(player, dice_sum); observer.Event("hide_jail_options", {"disable_roll": True})
        else: # Failed roll
            if player.turns_in_jail < 3: observer.Event("update_state", f"Failed. Stay in Jail. End turn.")
            else: # Third fail
                observer.Event("update_state", "Failed 3rd roll. Must pay.")
                if player.money < JAIL_FINE: observer.Event("update_state", f"Need ${JAIL_FINE}!"); self._check_funds_and_initiate_bailout(player, {"debt": JAIL_FINE, "creditor": "Bank"})
                else: 
                    player.money-=JAIL_FINE; observer.Event("update_state", f"Paid ${JAIL_FINE}."); player.is_in_jail=False; player.turns_in_jail=0
                    player.move(dice_sum); self._handle_landing(player, dice_sum); observer.Event("hide_jail_options", {"disable_roll": True})

    def _use_jail_card_action(self, data):
        player=self._gameboard.get_current_player()
        if not player.is_in_jail: observer.Event("update_state", "Not in jail."); return
        if player.get_out_of_jail_cards > 0:
            player.get_out_of_jail_cards-=1; player.is_in_jail=False; player.turns_in_jail=0 # TODO: Return card
            observer.Event("update_state", f"Used GOOJFC."); observer.Event("update_state_box", str(self._gameboard))
            self.__dice_rolled=False; self.__roll_count=0; player.doubles_count=0; observer.Event("update_state", "Roll dice."); observer.Event("hide_jail_options", None)
        else: observer.Event("update_state", "No GOOJFC.")

    # --- Card Execution ---
    def _execute_card_action(self, player, card):
        action = card.get("action"); text = card.get('text','?')
        observer.Event("update_state", f"Card: {text}")
        debt_info = None
        if action == "moveto":
            dest = card["destination"]; passed_go = False
            if dest != 10 and (dest == 0 or (dest < player.position and player.position != 10)): player.collect(200); passed_go = True
            player.position = dest; square = self._gameboard.get_square(dest)
            if not square: print(f"ERROR: Invalid dest {dest}"); return
            msg = "Moved to " + square.name + (" (Passed Go)" if passed_go else ""); observer.Event("update_state", msg); self._handle_landing(player, 0)
        elif action == "move":
            player.move(card["amount"]); observer.Event("update_state", f"Moved {card['amount']}."); self._handle_landing(player, 0)
        elif action == "moveto_nearest":
            target_type=card["type"]; nearest_pos=self._find_nearest_square(player.position, target_type)
            if nearest_pos is not None:
                passed_go=(nearest_pos < player.position);
                if passed_go: player.collect(200)
                player.position=nearest_pos; square=self._gameboard.get_square(nearest_pos)
                if not square: print(f"ERROR: Invalid nearest pos {nearest_pos}"); return
                msg=f"Moved to {square.name}"+(" (Passed Go)" if passed_go else ""); observer.Event("update_state", msg)
                if square.owner and square.owner != player:
                    multiplier=card.get("pay_multiplier", 1); rent=0
                    if target_type=="Utility": dice_sum=random.randint(2,12); rent=multiplier*dice_sum; observer.Event("update_state", f"Dice: {dice_sum}")
                    elif target_type=="Railroad": rent=square.calculate_rent_or_tax(0,self._gameboard)*multiplier
                    if rent>0: observer.Event("update_state", f"Pay {square.owner.name} ${rent}"); player.money-=rent; square.owner.money+=rent;
                    if player.money < 0: self._check_funds_and_initiate_bailout(player, {"debt": abs(player.money), "creditor": square.owner})
                elif not square.owner: self._handle_landing(player, 0)
                else: self._handle_landing(player, 0)
            else: observer.Event("update_state", f"No nearest {target_type}?")
        elif action == "collect": player.collect(card["amount"]); observer.Event("update_state", f"Collect ${card['amount']}")
        elif action == "pay":
            amount=card["amount"]; creditor="Bank"; observer.Event("update_state", f"Pay ${amount}.")
            if player.money < amount: debt_info = {"debt": amount, "creditor": creditor}
            else: player.money-=amount; observer.Event("update_state", f"Paid ${amount}.")
        elif action == "payeachplayer":
            amount=card["amount"]; others=[p for p in self._gameboard.get_all_players_incl_current() if p!=player]; total=amount*len(others); observer.Event("update_state", f"Pay ${amount} each (${total}).")
            if player.money < total: debt_info = {"debt": total, "creditor": "Players"}
            else: player.money-=total; [p.collect(amount) for p in others]; observer.Event("update_state", f"Paid ${total}.")
        elif action == "collecteachplayer":
            amount=card["amount"]; others=[p for p in self._gameboard.get_all_players_incl_current() if p!=player]; total_collected=0; observer.Event("update_state", f"Collect ${amount} each.")
            for p in others: payment=min(amount, p.money); p.money-=payment; total_collected+=payment
            player.collect(total_collected); observer.Event("update_state", f"Collected ${total_collected}.")
        elif action == "gotojail": self._send_to_jail(player)
        elif action == "getoutofjailfree": player.get_out_of_jail_cards+=1; observer.Event("update_state", "Received GOOJFC.")
        elif action == "repairs":
            cost=player.calculate_repair_cost(card["house_cost"], card["hotel_cost"]); creditor="Bank"; observer.Event("update_state", f"Pay ${cost} repairs.")
            if cost>0:
                if player.money < cost: debt_info = {"debt": cost, "creditor": creditor}
                else: player.money-=cost; observer.Event("update_state", f"Paid ${cost}.")
        elif action == "error": observer.Event("update_state", f"Card Error: {text}")
        # Final check
        if debt_info: self._check_funds_and_initiate_bailout(player, debt_info)
        observer.Event("update_state_box", str(self._gameboard))

    # --- _roll_action Definition ---
    def _roll_action(self, data):
        """Handles the 'Roll Dice' button click."""
        player = self._gameboard.get_current_player()
        if player.is_in_jail or self._auction_in_progress or self._bailout_in_progress:
             observer.Event("update_state", "Cannot roll now."); return
        turn_continues = self._handle_roll_dice()
        # Update UI only if no blocking state/choice is active
        if not (self._auction_in_progress or self._bailout_in_progress or self._choice_pending):
            if not turn_continues: # Jailed?
                 if player.is_in_jail: observer.Event("show_jail_options", None)
            elif self.__dice_rolled and player.doubles_count == 0: # Non-double done
                 self._restore_normal_ui_mid_turn() # Use helper
            elif player.doubles_count > 0: # Doubles, can roll again
                 self._restore_normal_ui_mid_turn() # Use helper
        observer.Event("update_state_box", str(self._gameboard))

    def _find_property_by_name(self, property_name):
        """Finds a GameSquare on the board by its name."""
        if not property_name: return None
        if not self._gameboard or not self._gameboard.get_all_squares(): return None
        for square in self._gameboard.get_all_squares():
            if square and square.name and square.name.lower() == property_name.lower(): return square
        return None