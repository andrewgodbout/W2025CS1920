# AI Assistance
Written by: Steven Ferguson

Since I have never written Javascript, I used ChatGPT to help me with the initial steps in handling button presses on the frontend. Most of what
I could find elsewhere showed calling routes inside forms, but my case didn't use a form.

The prompt I gave ChatGPT was "How can I handle a button press in flask that isn't attached to a form element." This yielded the following js snippet:  

```
// JavaScript to handle the button press
document.getElementById('myButton').addEventListener('click', function() {
    // Send a POST request using Fetch API
    fetch('/button-pressed', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: 'Button clicked!' })
    })
    .then(response => response.json())
    .then(data => {
        // Display response from the Flask server
        document.getElementById('responseMessage').textContent = data.message;
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
```

I was then able to use this as a starting point, with the documentation on [MDN Web Docs](https://developer.mozilla.org/en-US/), to build the solution I needed.

The rest of the code added to this project is my own.