# Walkthrough
Written by: Steven Ferguson

## Setup
<font color="red">**IMPORTANT**</font>

Before trying to run the game, you **must** install flask into your virtual environment or the game won't run. To do this, open the PyCharm Terminal and type the following: 

```
pip3 install flask
```  
If you get an error, try:
```
pip install flask
```

## Running the Game

Now that you have everything set up, go into view.py and run the ```if __name__ == __main__``` chunk to start the game. 
This should set up the local dev server at 127.0.0.1:5000 and automatically open your default web browser to that page where you can play the game.
If this doesn't happen, you can click, or type the following link into the address bar of your browser: http://127.0.0.1:5000

## Changes

### Replace tkinter Frontend With Flask
The biggest change I made was completely rewriting view.py to use Flask, a web application framework, instead of tkinter.

In order to create a flask application, you need to define url endpoints that will be called from the website in order to
interact with the game and send events to the controller. In the ```_add_routes()``` function, on line 57, I set up the
different routes that will be called. The function ```begin()``` on line 59 is the entry point for th app and is called
when you navigate to the link http://127.0.0.1:5000.

This step took a majority of the time spent on the assignment as there was a lot to learn while implementing the changes.

### HTML and CSS
Inside the templates directory, you can see the html files that define all the elements that appear on the page
like the buttons and images. Inside the static folder you can also see the css that styles the layout and look of the page.

### Javascript
Also inside the static folder, you will find script.js. This is where all the logic is that had to be handled in 
javascript since flask and python don't have the ability to directly access the front end of the webpage. This logic includes:
- Listening to click events on the buttons
- Sending GET and POST requests for buttons to flask that will affect the game state and return any changes that need to be made to the UI
- Parsing the JSON returned from flask into html elements such as tables and images.

### Disable Buttons
While working on the game, I realized that a player could click a button even if the action was not possible, so I decided to fix this.
You can see this change while playing this game as the buttons will appear gray and not respond to clicks if their actions aren't possible.

In order to implement this functionality, I needed a way to track what actions were possible and then send them up to the view
and then to the HTML so the change could be seen. 
1. utils.py: I implemented a State enum with values for each state.
2. controller.py: I added the ```determine_flags()``` function on line 217 which checks if the player can roll, can buy the current square, can mortgage or unmortgage a property, or if their turn is over.
   - This information is packaged up into the State enum and passed back to the view with an event.
   - The event is created any time other ui or state-changes are created. (e.g. roll, mortgage, ...)
4. view.py: the event is handled in the ```update_ui_state()``` function on line 208 by updating ```self.disabled_buttons```.
5. Finally, this is sent to the front end through the return statements in the routes mentioned earlier and the javascript uses it to disable the appropriate buttons.

### Added Owned Properties
When playing the game, you can now see the properties that you own across the bottom of the page. This allows you to quickly reference
your properties to decide if it makes sense to purchase another one.

This change can be found across a few files:
1. controller.py: ```get_owned_properties()``` function (line 245) makes a list of property positions to send to the view
   - Called and sent as event where other state changes are sent as events.
2. view.py: Event handled in ```update_properties()``` function (line 217)
3. Sent to front end through return of routes to be updated on front-end.

### Setup Screen
I added a setup screen to set the number of players and other game flags. Currently, only the number of players actually changes anything in the game.

This was mostly implemented in HTML in the setup.html file. When the form is completed and the "Start Game" button is clicked, the selected options are 
sent to the server via a POST request on the "/" route. The data is caught by lines 60-63 in view.py and the server redirects the browser to the started game.

### StateBox
Added styling to the state_box to make it more legible. Displayed in a table, with current player row highlighted and name in bold. This makes it more clear whose turn it is.

This styling is in the scrip.js file on lines 1-37, where the string representation of the information is turned into an html table, added to the DOM and then styled by the css in styles.css.
