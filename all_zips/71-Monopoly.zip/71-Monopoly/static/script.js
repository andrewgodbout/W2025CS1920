const strToTable = (s) => {
    // function to take a string and split it into table components.
    // The string given by the monopoly game is \n separated for rows and - separated for cells
    // returns an html table element that can be added as a child into DOM

    var lines = s.split("\n")

    const table = document.createElement("table")
    const table_head = document.createElement("thead")
    const table_body = document.createElement("tbody")

    for (var line_num in lines) {
        var line = lines[line_num].split(" - ");

        var row = document.createElement("tr")

        if (line_num == 0) {
            for (var elem of line) {
                var head_elem = document.createElement("th")
                head_elem.innerText = elem
                row.appendChild(head_elem)
            }
            table_head.appendChild(row)
        } else {
            for (var elem of line) {
                var cell = document.createElement("td")
                cell.innerText = elem
                row.appendChild(cell)
            }
            table_body.appendChild(row)
        }
    }
    table.appendChild(table_head)
    table.appendChild(table_body)

    return table
}

var buttonState = {};

const toggleModal = () => {
    // Show/hide the modal to ask which property to mortgage

    var modal = document.getElementById("modal");

    var controlButtons = document.getElementsByClassName("control-buttons")

    if (modal.style.display == 'none') {
        modal.style.display = "flex";

        for (var button of controlButtons) {
            buttonState[button.id] = button.disabled
            button.disabled = true;
        }
    } else {
        modal.style.display = 'none';

        applyButtonState(buttonState)
    }
}

const applyButtonState = (state) => {
    // Applies button state saved in state as key: value pairs
    // key = element id
    // value = true or false boolean value

    for (var id in state) {
        document.getElementById(id).disabled = state[id]
    }
}

const updateState = (data) => {
    // updates state based on key: value pairs passed by flask
    // should handle errors where an element doesn't exits, but this works for now

    html_table = strToTable(data.state_box_contents);

    var statebox = document.getElementById("statebox")
    statebox.innerHTML = "";
    statebox.appendChild(html_table)

    var tbox = document.getElementById("textbox")

    // Keep scrollbar scrolled to bottom if contents bigger than container.
    tbox.innerHTML = data.text_box_contents;
    tbox.scrollTop = tbox.scrollHeight;

    buttonState = data.disabled_buttons

    applyButtonState(data.disabled_buttons)

    var propDiv = document.getElementById('properties');
    propDiv.innerHTML = "";

    for (var imgFile of data.owned_properties) {
        console.log(imgFile)
        const newImg = document.createElement("img");
        newImg.classList = "owned-property-tiles";
        newImg.src = imgFile;

        propDiv.appendChild(newImg)
    }
}


window.addEventListener("load", () => {
    // When page loads, convert text from statebox to an html table, hide modal for mortgage selection

    var statebox = document.getElementById("statebox")
    var html = statebox.innerHTML;

    statebox.innerHTML = "";
    statebox.appendChild(strToTable(html));

    document.getElementById("modal").style.display = "none";

    applyButtonState(buttonState)
})


document.getElementById("roll").addEventListener("click", () => {
    fetch("/roll", {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById("current-space").src = data.img_file;

            updateState(data);

        })
        .catch(error => {
            console.error("Error:", error);
        });
});

document.getElementById("purchase").addEventListener("click", () => {
    fetch("/purchase", {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            updateState(data);
        })
});

document.getElementById("mortgage").addEventListener("click", () => {
    fetch("/mortgage", {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            const label = document.createElement("label");
            label.htmlFor = "mortgage-selector";
            label.innerText = "Select a property to mortgage:"

            const select = document.createElement("select");
            select.id = "mortgage-selector";

            for (var name of data) {
                const option = document.createElement("option");
                option.value = name;
                option.innerText = name;
                select.appendChild(option);
            }

            var selectorDiv = document.getElementById("selector")
            selectorDiv.innerHTML = "";
            selectorDiv.appendChild(label)
            selectorDiv.appendChild(select)

            toggleModal()
        })
});

document.getElementById("unmortgage").addEventListener("click", () => {
    fetch("/unmortgage", {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            updateState(data);
        })
        .catch(error => {
            console.error("Error:", error);
        })
});

document.getElementById("end_turn").addEventListener("click", () => {
    fetch("/end-turn", {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(response => response.json())
        .then(data => {
            document.getElementById("current-space").src = data.img_file;

            updateState(data);
        })
        .catch(error => {
            console.error("Error:", error);
        })
});

document.getElementById("confirm-mortgage-selection").addEventListener("click", () => {
    // If the confirm button is clicked, get the selected item in the modal and send it
    // back to flask in a POST request body.

    var select = document.getElementById("mortgage-selector")

    toggleModal()

    fetch("/mortgage_specific", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 'selection': select.options[select.selectedIndex].value })
    })
        .then(response => response.json())
        .then(data => {
            updateState(data);
        })
        .catch(error => {
            console.error("Error:", error);
        })
});

document.getElementById("cancel-mortgage-selection").addEventListener("click", () => {
    // Hide the modal if the cancel button is clicked... nothing to do

    toggleModal()
});
