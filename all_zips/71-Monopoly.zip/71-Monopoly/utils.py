from pathlib import Path

from enum import Flag, auto


class State(Flag):
    NONE = 0
    NEW_TURN = auto()
    ROLLED_DOUBLES = auto()
    CAN_PURCHASE = auto()
    CAN_MORTGAGE = auto()
    CAN_UNMORTGAGE = auto()
    END_OF_TURN = auto()


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = Path("images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images
