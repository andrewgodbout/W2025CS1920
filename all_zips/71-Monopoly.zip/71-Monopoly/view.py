# view.py
# Author: Steven Ferguson
# Defines the Flask app that handles the game view and user interaction.

# TODO: - Don't forget to write the text files

import sys
import webbrowser

# If user doesn't have flask, instruct them how to install it.
try:
    from flask import Flask, jsonify, render_template, redirect, request, url_for
except ImportError as e:
    print(f"Error: {e}")
    print(
        "Please ensure you have flask installed by running 'pip3 install flask' or 'pip install flask' in your terminal."
    )
    sys.exit(1)

import controller
import observer
from utils import State, get_board_square_images


class FlaskView(observer.Observer):
    def __init__(self):
        super().__init__()

        self._app = Flask(__name__)
        self._add_routes()

        self.images = get_board_square_images()

        self.current_image = self.images[0]
        self.curr_prop_imgs = []

        self.text_box_contents = ""
        self.state_box_contents = ""

        self.disabled_buttons = {
            "roll": False,
            "purchase": True,
            "mortgage": True,
            "unmortgage": True,
            "end_turn": True,
        }

        self.mortgage_choices = []
        self.mortgage_selection = ""

        self._add_listeners()

        print("Opening default web browser to http://127.0.0.1:5000....")

        webbrowser.open("http://127.0.0.1:5000")

        print(
            "If the browser does not open automatically type http://127.0.0.1:5000 into the address bar to access the game."
        )

    def _add_routes(self):
        @self._app.route("/", methods=["GET", "POST"])
        def begin():
            if request.method == "POST":
                # We do instantiate the controller inside the view, but we don't keep a
                # reference to it. Not the best for coupling.
                controller.Controller(int(request.form.get("n-players")))

                return redirect(url_for("game"))
            else:
                return render_template("setup.html")

        @self._app.route("/game")
        def game():
            return render_template(
                "monopoly.html",
                img_file=self.current_image,
                disabled_buttons=self.disabled_buttons,
                statebox_contents=self.state_box_contents,
                textbox_contents=self.text_box_contents,
                curr_prop_imgs=[
                    url_for("static", filename=curr_prop_img)
                    for curr_prop_img in self.curr_prop_imgs
                ],
            )

        @self._app.route("/roll")
        def roll():
            self._action_taken("roll")

            # By returning the image to the post call and updating the src in the img tag,
            # the image will update dynamically without reloading the page.
            return jsonify(
                {
                    "img_file": url_for("static", filename=self.current_image),
                    "owned_properties": [
                        url_for("static", filename=curr_prop_img)
                        for curr_prop_img in self.curr_prop_imgs
                    ],
                    "text_box_contents": self.text_box_contents,
                    "state_box_contents": self.state_box_contents,
                    "disabled_buttons": self.disabled_buttons,
                }
            )

        @self._app.route("/purchase")
        def purchase():
            self._action_taken("purchase")

            return jsonify(
                {
                    "owned_properties": [
                        url_for("static", filename=curr_prop_img)
                        for curr_prop_img in self.curr_prop_imgs
                    ],
                    "text_box_contents": self.text_box_contents,
                    "state_box_contents": self.state_box_contents,
                    "disabled_buttons": self.disabled_buttons,
                }
            )

        @self._app.route("/mortgage")
        def mortgage():
            self._action_taken("mortgage")

            return jsonify(self.mortgage_choices)

        @self._app.route("/unmortgage")
        def unmortgage():
            self._action_taken("unmortgage")

            return jsonify(
                {
                    "owned_properties": [
                        url_for("static", filename=curr_prop_img)
                        for curr_prop_img in self.curr_prop_imgs
                    ],
                    "text_box_contents": self.text_box_contents,
                    "state_box_contents": self.state_box_contents,
                    "disabled_buttons": self.disabled_buttons,
                }
            )

        @self._app.route("/mortgage_specific", methods=["POST"])
        def mortgage_specific():
            self.mortgage_selection = request.get_json()["selection"]

            self._action_taken("mortgage_specific")

            return jsonify(
                {
                    "owned_properties": [
                        url_for("static", filename=curr_prop_img)
                        for curr_prop_img in self.curr_prop_imgs
                    ],
                    "text_box_contents": self.text_box_contents,
                    "state_box_contents": self.state_box_contents,
                    "disabled_buttons": self.disabled_buttons,
                }
            )

        @self._app.route("/end-turn")
        def end_turn():
            self._action_taken("end_turn")

            return jsonify(
                {
                    "img_file": url_for("static", filename=self.current_image),
                    "owned_properties": [
                        url_for("static", filename=curr_prop_img)
                        for curr_prop_img in self.curr_prop_imgs
                    ],
                    "text_box_contents": self.text_box_contents,
                    "state_box_contents": self.state_box_contents,
                    "disabled_buttons": self.disabled_buttons,
                }
            )

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("update_ui_state", self.update_ui_state)
        self.observe("update_owned_properties", self.update_properties)
        self.observe("choice", self._choose)

    def _action_taken(self, action):
        if action == "roll":
            print("roll clicked")
            observer.Event("roll", None)

        elif action == "purchase":
            print("Purchase button clicked")
            observer.Event("purchase", None)

        elif action == "mortgage":
            observer.Event("mortgage", None)

        elif action == "unmortgage":
            observer.Event("unmortgage", None)

        elif action == "mortgage_specific":
            observer.Event("mortgage_specific", self.mortgage_selection)

        elif action == "end_turn":
            observer.Event("end_turn", self._clear_text)

    def update_card(self, index):
        print("UPDATING CARD")
        self.current_image = self.images[index]
        print(url_for("static", filename=self.current_image))

    def update_ui_state(self, state):
        self.disabled_buttons = {
            "roll": not bool(state & State.ROLLED_DOUBLES),
            "purchase": not bool(state & State.CAN_PURCHASE),
            "mortgage": not bool(state & State.CAN_MORTGAGE),
            "unmortgage": not bool(state & State.CAN_UNMORTGAGE),
            "end_turn": not bool(state & State.END_OF_TURN),
        }

    def update_properties(self, indices):
        self.curr_prop_imgs = [self.images[i] for i in sorted(indices)]
        print(self.curr_prop_imgs)
        self.curr_prop_imgs
        print(self.curr_prop_imgs)

    def _update_text(self, text=""):
        self.text_box_contents += text + "<br />"

    def _clear_text(self):
        self.text_box_contents = ""

    def update_state_box(self, text=""):
        self.state_box_contents = text

    def _choose(self, choices):
        # save mortgage choices to sent to javascript to be displayed.
        self.mortgage_choices = choices

    def run(self):
        # self._app.run(debug=True)
        self._app.run()


if __name__ == "__main__":
    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False

    app = FlaskView()

    # controller = controller.Controlr()

    app.run()
