import gamesquare
import player
import csv

class GameBoard:
    """GameBoard class to represent the game board"""

    def __init__(self, csv_path, players):
        """Constructor for the GameBoard class"""
        self.__players = players
        self.__turn = 0
        self.__boardCSV = {"name": 0, "price": 1, "rent": 2, "space": 3, "color": 4, "groupmembers": 5, "build": 6}
        self.__game_board = self._load_game_board(csv_path)

    def next_turn(self):
        """Function to move to the next player's turn"""
        self.__turn = (self.__turn + 1) % len(self.__players)
        return self.get_current_player().name

    def get_square(self, position):
        """Function to get the square at a given position"""
        return self.__game_board[position]

    def get_current_player(self):
        """Function to get the current player"""
        return self.__players[self.__turn]

    def calculate_expected_value(self, position, depth):
        """Calculate the expected value of a position"""
        if depth > 5:
            return 0
        square = self.get_square(position)
        if square.owner is not None and square.owner != self.get_current_player():
            return square.calculate_rent_or_tax(7) * -1 + self.calculate_expected_value(position + 7, depth + 1) / 36
        if square.can_be_purchased() and square.price < self.get_current_player().money:
            return square.price * -1 + self.calculate_expected_value(position + 7, depth + 1) / 36
        return self.calculate_expected_value(position + 7, depth + 1) / 36

    def get_property(self, name):
        """Function to get a property by name"""
        for square in self.__game_board:
            if square.name == name:
                return square
        return None

    def _load_game_board(self, csv_path):
        """load board from csv with build cost"""
        properties = []
        f = open(csv_path, "r")
        next(f)  # skip header
        for line in f:
            line = line.strip().split(",")
            utility = line[self.__boardCSV["space"]] == "Utility"
            railroad = line[self.__boardCSV["space"]] == "Railroad"
            build_cost = int(line[self.__boardCSV["build"]]) if line[self.__boardCSV["build"]] else 0
            sq = gamesquare.GameSquare(name=line[self.__boardCSV["name"]], price=int(line[self.__boardCSV["price"]]),
                                      rent=int(line[self.__boardCSV["rent"]]), color=line[self.__boardCSV["color"]],
                                      is_utility=utility, is_railroad=railroad, space=line[self.__boardCSV["space"]])
            sq.build_cost = build_cost  # add build cost to square
            properties.append(sq)
        f.close()
        return properties

    def __str__(self):
        """Function to return a string representation of the GameBoard object"""
        output = ""
        for i in range(len(self.__players)):
            output += str(self.__players[i])
            if i == self.__turn:
                output += " <- turn"
            output += "\n"
        return output