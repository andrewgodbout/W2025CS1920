import gameboard
import gamesquare
import observer

class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__luck = 0
        self.__mortgaging_order = []
        self.__speed_boost_used = False  # Added for Speed Boost

    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False
        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.set_owner(self)
        return True

    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, value):
        self.__doubles_count = value

    @property
    def railroad_count(self):
        return self.__railroad_count

    @railroad_count.setter
    def railroad_count(self, value):
        self.__railroad_count = value

    @property
    def utility_count(self):
        return self.__utility_count

    @utility_count.setter
    def utility_count(self, value):
        self.__utility_count = value

    @property
    def name(self):
        return self.__name

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, value):
        self.__money = value

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, value):
        self.__luck = value

    def pay_rent(self, square, dice_sum):
        """Function to pay rent if square is owned"""
        if square.owner is None or square.owner == self or square.is_mortgaged:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent
        square.owner.money += rent
        return rent

    def mortgage_property(self, index=-1):
        """Function to mortgage a property"""
        if index == -1:
            if len(self.__properties) == 0:
                return ""
            for prop in self.__properties:
                if prop.mortgage():
                    self.__money += prop.price / 2
                    self.__mortgaging_order.append(prop.name)
                    return prop.name
            return ""
        elif 0 <= index < len(self.__properties):
            prop = self.__properties[index]
            if prop.mortgage():
                self.__money += prop.price / 2
                self.__mortgaging_order.append(prop.name)
                return prop.name
        return ""

    def unmortgage_property(self):
        """Function to unmortgage a property"""
        if len(self.__mortgaging_order) == 0:
            return ""
        prop_name = self.__mortgaging_order.pop(0)
        for prop in self.__properties:
            if prop.name == prop_name and prop.unmortgage():
                self.__money -= prop.price * 0.55  # 10% interest
                return prop_name
        return ""

    def declare_bankrupt(self):
        """Function to declare bankruptcy"""
        self.__bankrupt_declared = True

    def has_monopoly(self, color):
        """check if player owns all properties of a color"""
        color_count = sum(1 for p in self.__properties if p.color == color)
        # this is a guess, might need to check board.csv for exact count
        if color == "brown" or color == "darkblue":
            return color_count == 2
        elif color in ["lightblue", "pink", "orange", "red", "yellow", "green"]:
            return color_count == 3
        elif color == "purple":
            return color_count == 4
        return False

    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        self.__speed_boost_used = False  # Reset for Speed Boost
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    @property
    def position(self):
        return self.__board_position