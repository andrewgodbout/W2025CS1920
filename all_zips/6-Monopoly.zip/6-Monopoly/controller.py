import os
import view
import random
import gameboard
import player as plr
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)
        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0
        self._set_expected_val()
        # Note: No _player_names or _card_deck since we abandoned those ideas

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("build_house", self._build_house)  # House/Hotel feature
        self.observe("build_hotel", self._build_hotel)  # House/Hotel feature
        self.observe("sell_house", self._sell_house)    # House/Hotel feature
        self.observe("speed_boost", self._speed_boost)  # Speed Boost feature

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")
        player = self._gameboard.get_current_player()
        player.luck += ev

    def _roll_dice(self):
        """Simulate rolling dice with optional speed boost"""
        player = self._gameboard.get_current_player()
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2
        if player._Player__speed_boost_used:  # Speed Boost feature
            dice3 = random.randint(1, 6)
            dice_sum += dice3
            observer.Event("update_state", f"Boosted roll: {dice1}+{dice2}+{dice3} = {dice_sum}")
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        self.__dice_rolled = True
        self.__roll_count += 1
        if dice1 == dice2:
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2}")
            self.__dice_rolled = False
        return dice_sum

    def _handle_roll_dice(self):
        """Handle the dice roll"""
        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False
        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)
        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")
        if player.money < 0:
            player.declare_bankrupt()
        return True

    def _roll_action(self, data):
        """Wrapper for roll dice"""
        self._handle_roll_dice()

    def _buy_square(self, data):
        """Player has indicated an interest in purchasing the square they are on"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        if square.can_be_purchased() and player.money >= square.price:
            buy = player.buy_property(square)
            if buy:
                observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
            they must mortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.mortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Mortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, index):
        """Player has indicated an interest in mortgaging a specific property"""
        player = self._gameboard.get_current_player()
        deed_name = player.mortgage_property(index)
        if deed_name != "":
            observer.Event("update_state", f"Mortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _build_house(self, data):
        """build a house on current square if monopoly"""
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)
        if square.space != "Property":
            observer.Event("update_state", "Not a property!")
            return
        if not player.has_monopoly(square.color):
            observer.Event("update_state", "Need monopoly to build!")
            return
        cost = square.build_cost
        if player.money < cost:
            observer.Event("update_state", "Not enough money!")
            return
        if square.add_house(cost):
            observer.Event("update_state", f"House built on {square.name}")
        else:
            observer.Event("update_state", "Can’t build more houses!")
        observer.Event("update_state_box", str(self._gameboard))

    def _build_hotel(self, data):
        """build a hotel if 4 houses"""
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)
        if square.space != "Property":
            observer.Event("update_state", "Not a property!")
            return
        if not player.has_monopoly(square.color):
            observer.Event("update_state", "Need monopoly to build!")
            return
        cost = square.build_cost
        if player.money < cost:
            observer.Event("update_state", "Not enough money!")
            return
        if square.add_hotel(cost):
            observer.Event("update_state", f"Hotel built on {square.name}")
        else:
            observer.Event("update_state", "Need 4 houses first!")
        observer.Event("update_state_box", str(self._gameboard))

    def _sell_house(self, data):
        """sell a house from current square"""
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)
        if square.space != "Property":
            observer.Event("update_state", "Not a property!")
            return
        cost = square.build_cost
        if square.sell_house(cost):
            observer.Event("update_state", f"House sold from {square.name}")
        else:
            observer.Event("update_state", "No houses to sell!")
        observer.Event("update_state_box", str(self._gameboard))

    def _speed_boost(self, data):
        """pay to use railroad speed boost"""
        player = self._gameboard.get_current_player()
        if self.__dice_rolled:
            observer.Event("update_state", "Can’t boost after rolling!")
            return
        if player.railroad_count == 0:
            observer.Event("update_state", "No railroads owned!")
            return
        cost = 25 * player.railroad_count
        if player.money < cost or player._Player__speed_boost_used:
            observer.Event("update_state", "Can’t afford or already used boost!")
            return
        player.money -= cost
        player._Player__speed_boost_used = True  # hacky private access
        observer.Event("update_state", f"Paid ${cost} for speed boost ({player.railroad_count} railroads)")

    def _end_player_turn(self, callback):
        """Player has indicated an intent to end their turn"""
        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state", f"{player_name}'s turn")
        self._set_expected_val()
        observer.Event("update_state_box", str(self._gameboard))
        callback()