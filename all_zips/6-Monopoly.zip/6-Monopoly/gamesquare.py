import player
import gameboard

class GameSquare:
    """GameSquare class to represent a square on the game board"""

    def __init__(self, name, price, rent, space, color, is_utility, is_railroad):
        """Constructor for the GameSquare class"""
        self.__name = name
        self.__price = price
        self.__rent = rent
        self.__color = color
        self.__space = space
        self.__is_utility = is_utility
        self.__is_railroad = is_railroad
        self.__owner = None
        self.__is_mortgaged = False
        self.__build_cost = 0  # Added for House/Hotel feature

    @property
    def build_cost(self):
        return self.__build_cost

    @build_cost.setter
    def build_cost(self, cost):
        self.__build_cost = cost

    @property
    def owner(self):
        return self.__owner

    @property
    def name(self):
        return self.__name

    @property
    def price(self):
        return self.__price

    @property
    def rent(self):
        return self.__rent

    @property
    def color(self):
        return self.__color

    @property
    def space(self):
        return self.__space

    @property
    def is_railroad(self):
        return self.__is_railroad

    @property
    def is_utility(self):
        return self.__is_utility

    @property
    def is_mortgaged(self):
        return self.__is_mortgaged

    def can_be_purchased(self):
        """Function to determine if a square can be_purchased"""
        if self.owner is None:
            if (self.space == "Tax" or self.space == "Chance" or self.space == "Chest"
                    or self.space == "Jail" or self.space == "Parking" or self.space == "Go"):
                return False
            else:
                return True
        return False

    def set_owner(self, owner):
        """Function to set the owner of the square"""
        self.__owner = owner
        if self.__is_railroad:
            self.__owner.railroad_count += 1
        if self.__is_utility:
            self.__owner.utility_count += 1

    def mortgage(self):
        """Function to mortgage the square"""
        if self.__owner is None or self.space != "Property" or self.__is_mortgaged:
            return False
        self.__is_mortgaged = True
        return True

    def unmortgage(self):
        """Function to unmortgage the square"""
        if self.__owner is None or self.space != "Property" or not self.__is_mortgaged:
            return False
        self.__is_mortgaged = False
        return True

    def add_house(self, cost):
        """add a house to the property if less than 4"""
        if self.__space != "Property" or self.__is_mortgaged or self.owner is None:
            return False
        if not hasattr(self, '__houses'):  # if houses not set yet
            self.__houses = 0
        if self.__houses < 4:
            self.__houses += 1
            self.owner.money -= cost  # take the build cost
            return True
        return False

    def add_hotel(self, cost):
        """add a hotel if 4 houses already"""
        if self.__space != "Property" or self.__is_mortgaged or self.owner is None:
            return False
        if not hasattr(self, '__houses'):
            self.__houses = 0
        if self.__houses == 4:
            self.__houses = 5  # 5 means hotel
            self.owner.money -= cost
            return True
        return False

    def sell_house(self, cost):
        """sell a house back for half price"""
        if not hasattr(self, '__houses') or self.__houses == 0 or self.__is_mortgaged:
            return False
        if self.__houses <= 4:  # only sell if not a hotel
            self.__houses -= 1
            self.owner.money += cost // 2  # half price back
            return True
        return False

    def calculate_rent_or_tax(self, dice_sum):
        """update rent based on houses or hotel, or double if monopoly with no buildings"""
        if self.owner is None or self.__is_mortgaged:
            return 0
        if self.is_utility:
            return 4 * dice_sum
        if self.is_railroad:
            return 25 * (2 ** (self.owner.railroad_count - 1))
        if hasattr(self, '__houses') and self.__houses > 0:
            if self.__houses == 1:
                return self.rent * 2  # just guessing rent increases
            elif self.__houses == 2:
                return self.rent * 4
            elif self.__houses == 3:
                return self.rent * 6
            elif self.__houses == 4:
                return self.rent * 8
            elif self.__houses == 5:  # hotel
                return self.rent * 10
        # Double rent for monopoly with no buildings
        elif self.__space == "Property" and self.owner.has_monopoly(self.color) and (not hasattr(self, '__houses') or self.__houses == 0):
            return self.rent * 2  # double rent for monopoly with no improvements
        return self.rent

    def __str__(self):
        """Function to return a string representation of the GameSquare object"""
        return f"{self.name} - {self.price} - {self.rent}"