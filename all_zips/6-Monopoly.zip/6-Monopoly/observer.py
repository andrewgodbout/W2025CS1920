class Observer:
    """Base class for observers to inherit from"""

    def __init__(self):
        self._observers = {}

    def observe(self, event_type, callback):
        """Register an observer for a specific event type"""
        if event_type not in self._observers:
            self._observers[event_type] = []
        self._observers[event_type].append(callback)


class Event:
    """Event class to represent an event"""

    def __init__(self, event_type, data):
        """Constructor for the Event class"""
        self.type = event_type
        self.data = data

        # Notify all observers of this event type
        if hasattr(Observer, '_observers') and event_type in Observer._observers:
            for callback in Observer._observers[event_type]:
                callback(self.data)