import gameboard
import gamesquare
import observer
import random


        


class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__in_jail = False
        self.__jail_turns = 0
        self.__get_out_of_jail_free_cards = False
        self.__luck = 0
        self.__mortgaging_order = []

    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True
    
    
    def get_state(self):
        return {
            'name': self.name,
            'money': self.money,
            'position': self.position,
            'in_jail': self.is_in_jail(),
            'jail_turns': self._Player__jail_turns,
            'bankrupt': self.bankrupt_declared,
            'properties': [p.name for p in self.properties]
        }
    
    def is_ai(self):
        """Check if player is AI-controlled"""
        return isinstance(self, AIPlayer)

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    def go_to_jail(self):
        """Function to send the player to jail"""
        self.__board_position = 10  # Jail square
        self.__in_jail = True
        self.__jail_turns = 0

    def is_in_jail(self):
        """Function to check if the player is in jail"""
        return self.__in_jail

    def attempt_jail_escape(self, dice_roll1=None, dice_roll2=None):
        """Function to attempt to get out of jail
        
        There are three ways to get out of jail:
        1. Roll doubles
        2. Pay a $50 fine
        3. Use a Get Out of Jail Free card
        
        :param dice_roll1: First dice roll (optional)
        :param dice_roll2: Second dice roll (optional)
        :return: True if player escapes jail, False otherwise
        """
        if not self.__in_jail:
            return True
        
        self.__jail_turns += 1
        
        # Option 1: Roll doubles
        if dice_roll1 is not None and dice_roll2 is not None:
            if dice_roll1 == dice_roll2:
                self.__in_jail = False
                self.__jail_turns = 0
                return True
        
        # Option 2: Try to pay jail fine after 3 turns
        if self.__jail_turns >= 3:
            return self.pay_jail_fine()
        
        return False

    def pay_jail_fine(self):
        """Pay $50 to get out of jail
        
        :return: True if fine is paid successfully, False otherwise
        """
        if self.__money >= 50:
            self.__money -= 50
            self.__in_jail = False
            self.__jail_turns = 0
            return True
        return False

    def use_get_out_of_jail_free_card(self):
        """Use a Get Out of Jail Free card to escape jail
        
        :return: True if card is used successfully, False otherwise
        """
        if self.__get_out_of_jail_free_cards > 0:
            self.__get_out_of_jail_free_cards -= 1
            self.__in_jail = False
            self.__jail_turns = 0
            return True
        return False

    def add_get_out_of_jail_free_card(self):
        """Add a Get Out of Jail Free card"""
        # Change to increment for multiple cards
        self.__get_out_of_jail_free_cards = True

    

    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @property
    def position(self):
        return self.__board_position
    
    @position.setter
    def position(self, new_position):
        """Setter for position"""
        self.__board_position = new_position % 40
        if new_position >= 40:
            self.collect(200)
            observer.Event("update_state", f"{self.name} passed Go! +$200")

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]
    

class AIPlayer(Player):
    def __init__(self, name, money, difficulty="medium"):
        super().__init__(name, money)
        self.difficulty = difficulty
    
    def take_turn(self, gameboard):
        """Automate AI player's turn"""
        if self.is_in_jail():
            if random.random() > 0.5:
                self.pay_jail_fine()
        
        dice_roll = random.randint(1,6) + random.randint(1,6)
        self.move(dice_roll)
        
        current_square = gameboard.get_square(self.position)
        if current_square.can_be_purchased():
            decision = self._make_property_decision(current_square)
            if decision == "buy":
                self.buy_property(current_square)
        
        return f"{self.name} completed turn"
    
    def _make_property_decision(self, property):
        if self.difficulty == "easy":
            return "buy" if random.random() > 0.5 else "pass"
        elif self.difficulty == "hard":
            return "buy" if self.money > property.price * 0.8 else "mortgage"
        else:  # medium
            return "buy" if self.money > property.price * 1.5 else "pass"