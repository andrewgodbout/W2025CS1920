from datetime import datetime

class GameLogger:
    def __init__(self):
        self.actions = []
        
    def log(self, action, player=None):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}]"
        if player:
            log_entry += f" {player}:"
        log_entry += f" {action}"
        self.actions.append(log_entry)
        
    def get_recent(self, n=10):
        return self.actions[-n:]
        
    def save_to_file(self, filename="game_log.txt"):
        with open(filename, 'w') as f:
            f.write("\n".join(self.actions))