from datetime import datetime

class ChatSystem:
    def __init__(self):
        self.messages = []
        self.max_messages = 100
        
    def add_message(self, sender, message):
        timestamp = datetime.now().strftime("%H:%M")
        self.messages.append(f"{timestamp} {sender}: {message}")
        if len(self.messages) > self.max_messages:
            self.messages.pop(0)
            
    def get_messages(self, count=10):
        return self.messages[-count:]