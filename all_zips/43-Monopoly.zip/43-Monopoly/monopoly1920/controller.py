import os
import threading
import time
import view
import random
import gameboard
import player as plr
import gamesquare
import observer
from tkinter import filedialog

from persistence.save_load import GameSaver
from persistence.leaderboard import Leaderboard
from utilities.logger import GameLogger
from utilities.chat import ChatSystem

class GameTimer:
    def __init__(self, time_limit=60, on_timeout_callback=None):
        self.time_limit = time_limit
        self.remaining_time = time_limit
        self.timer_running = False
        self.timer_thread = None
        self.on_timeout_callback = on_timeout_callback
        self._stop_event = threading.Event()

    def start_timer(self):
        """Start the timer for a player's turn"""
        self._stop_event.clear()
        self.remaining_time = self.time_limit
        self.timer_running = True
        self.timer_thread = threading.Thread(target=self._countdown)
        self.timer_thread.start()

    def _countdown(self):
        """Internal countdown method"""
        while self.remaining_time > 0 and not self._stop_event.is_set():
            time.sleep(1)
            self.remaining_time -= 1
            observer.Event("update_timer", self.remaining_time)

        if self.remaining_time <= 0 and self.timer_running:
            self.timer_running = False
            if self.on_timeout_callback:
                self.on_timeout_callback()

    def stop_timer(self):
        """Stop the timer"""
        self.timer_running = False
        self._stop_event.set()  # Signal the thread to stop
        if self.timer_thread and self.timer_thread.is_alive() and threading.current_thread() != self.timer_thread:
            self.timer_thread.join(timeout=0.1)  # Add timeout to prevent hanging

    def reset_timer(self):
        """Reset the timer to full time"""
        self.stop_timer()
        self.remaining_time = self.time_limit



class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self.game_saver = GameSaver()
        self.leaderboard = Leaderboard()
        self.logger = GameLogger()
        self.chat_system = ChatSystem()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()
        self._add_new_listeners()

        self.__dice_rolled = False
        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()
        
        self.game_timer = GameTimer(time_limit=60, on_timeout_callback=self._handle_turn_timeout)

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _add_new_listeners(self):
        """Add listeners for new features"""
        self.observe("save_game", self._handle_save_game)
        self.observe("send_chat", self._handle_chat_message)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        if player.is_in_jail():
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            
            if not player.attempt_jail_escape(dice1, dice2):
                observer.Event("update_state", f"{player.name} is still in jail")
                return False

        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        if square.name == "Go to Jail":
            player.go_to_jail()
            observer.Event("update_state", f"{player.name} goes to Jail!")
            return False

        # Pay rent
        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        return True
    
    def _end_player_turn(self, callback):
        """End the current player's turn and handle transitions"""
        if not self.__dice_rolled and not self._gameboard.get_current_player().is_ai():
            observer.Event("update_state", "Roll the dice first")
            return

        self.__dice_rolled = False
        self.__roll_count = 0
        
        # Log turn end
        current_player = self._gameboard.get_current_player()
        self.logger.log(f"{current_player.name} ended their turn")
        
        # Move to next player
        player_name = self._gameboard.next_turn()
        next_player = self._gameboard.get_current_player()
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", next_player.position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        
        # Timer handling
        self.game_timer.stop_timer()
        self.game_timer.reset_timer()
        
        # Check for game over
        active_players = [p for p in self._gameboard.get_all_players() 
                         if not p.bankrupt_declared]
        if len(active_players) == 1:
            winner = active_players[0]
            observer.Event("update_state", f"Game Over! Winner: {winner.name}")
            self.leaderboard.update(winner.name, won=True)
            self.logger.log(f"Game over! Winner: {winner.name}")
            self.game_timer.stop_timer()
            return
        
        # Start timer for human players only
        if not next_player.is_ai():
            self.game_timer.start_timer()
        else:
            # Process AI turn
            self._process_ai_turn(next_player)
        
        self._set_expected_val()

    def _process_ai_turn(self, ai_player):
        """Handle an AI player's turn automatically"""
        def ai_turn():
            # Roll dice
            dice_roll = random.randint(1,6) + random.randint(1,6)
            observer.Event("update_state", f"{ai_player.name} rolls: {dice_roll}")

            ai_player.move(dice_roll)
            current_square = self._gameboard.get_square(ai_player.position)
            observer.Event("update_card", ai_player.position)
            
            # Property decisions
            if current_square.can_be_purchased():
                decision = ai_player._make_property_decision(current_square)
                if decision == "buy":
                    bought = ai_player.buy_property(current_square)
                    if bought:
                        observer.Event("update_state", 
                                     f"{ai_player.name} bought {current_square.name}")
            
            # Pay rent if needed
            rent = ai_player.pay_rent(current_square, dice_roll)
            if rent > 0:
                observer.Event("update_state",
                             f"{ai_player.name} paid ${rent} rent")
            
            # End turn
            self._end_player_turn(lambda: None)

        self.root.after(1500, ai_turn)

    def _determine_winner(self):
        """Determine the winning player"""
        active_players = [p for p in self._gameboard.get_all_players() 
                         if not p.bankrupt_declared]
        if len(active_players) == 1:
            return active_players[0]
        
        # If multiple players, return the one with highest net worth
        return max(self._gameboard.get_all_players(), 
                  key=lambda p: p.net_worth())


    def _handle_save_game(self, _=None):
        """Handle saving the game state"""
        try:
            game_state = {
                'game_board': {
                    'players': [p.get_state() for p in self._gameboard.players],
                    'current_player_index': self._gameboard.get_current_player_index(),
                    'properties': [prop.get_state() for prop in self._gameboard.get_all_squares()]
                },
                'timer': self.game_timer.remaining_time,
                'chat_messages': self.chat_system.get_messages()
            }
            
            if self.game_saver.save_game(game_state):
                observer.Event("update_state", f"Game saved")
            else:
                raise Exception("Failed to write save file")
                    
        except Exception as e:
            self.logger.log(f"Save failed: {str(e)}")
            observer.Event("update_state", f"Save failed: {str(e)}")

    def _handle_chat_message(self, message):
        player = self._gameboard.get_current_player()
        self.chat_system.add_message(player.name, message)
        observer.Event("update_chat", self.chat_system.get_messages())

    

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
        
        # Start the timer when the player rolls
        if not self.game_timer.timer_running:
            self.game_timer.start_timer()

    def _handle_turn_timeout(self):
        """Handle what happens when a player's turn times out"""
        current_player = self._gameboard.get_current_player()
        observer.Event("update_state", f"{current_player.name}'s turn timed out!")
        self._end_player_turn(self._view._clear_text)




