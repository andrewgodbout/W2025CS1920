import tkinter as tk
import os
from tkinter import ttk, filedialog
import observer
import controller

def get_board_square_images():
    """Return a list of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View(observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        self.images = []
        self.chat_messages = []
        self.chat_visible = False  # Track chat visibility state
        self.root = root
        root.title("Monopoly 1920")
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        # Create all frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        # Pack frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Initialize features
        self._preload_images()
        # Removed _create_new_ui_elements() call here
        self._create_chat_ui()  # Create chat UI but don't show it yet
        self._add_listeners()
        self._add_new_listeners()

    def _create_logo_frame(self):
        """Create the frame at the top with logo and timer"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        
        # Logo
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.image = logo_image
        
        # Timer label
        self.timer_label = ttk.Label(
            logo_frame, 
            text="Time: 60", 
            font=("Arial", 12, "bold"),
            foreground='green'
        )
        
        # Layout
        logo_frame.grid_columnconfigure(0, weight=1)
        logo_frame.grid_columnconfigure(1, weight=1)
        logo.grid(row=0, column=0, sticky='w')
        self.timer_label.grid(row=0, column=1, sticky='e', padx=20)
        
        return logo_frame

    def _create_middle_frame(self):
        """Create the middle game board frame"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        
        # Game board image
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # Property card display
        card_image = self.images[0] if self.images else tk.PhotoImage()
        self.card = ttk.Label(middle_frame, image=card_image)
        self.card.image = card_image

        # Game control buttons frame
        button_frame = ttk.Frame(middle_frame, padding=10)
        
        # Chat toggle button (placed above Roll Dice)
        self.chat_toggle_btn = ttk.Button(
            button_frame, 
            text="💬 Chat",
            command=self._toggle_chat,
            width=10
        )
        self.chat_toggle_btn.pack(side='top', anchor='center', pady=(0, 5))
        
        # Game action buttons
        buttons = [
            ("Roll Dice", "roll"),
            ("Purchase", "purchase"),
            ("Mortgage", "mortgage"),
            ("Unmortgage", "unmortgage"),
            ("Bankrupt", "bankrupt"),
            ("End Turn", "end_turn"),
            ("Save Game", "save_game"),
        ]
        
        self.mid_buttons = []
        for text, action in buttons:
            btn = ttk.Button(
                button_frame, 
                text=text,
                command=lambda a=action: self._action_taken(a)
            )
            btn.pack(side='top', anchor='center', pady=(5, 5))
            btn.state(['active'])
            self.mid_buttons.append(btn)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)
        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        
        return middle_frame

    def _create_msg_frame(self):
        """Create the message display frame"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        self.state_box = tk.Text(
            msg_frame, 
            width=60, 
            height=10, 
            background='black', 
            foreground='white'
        )
        self.state_box.pack(side='left', padx=(100,30))

        self.text_box = tk.Text(
            msg_frame, 
            width=60, 
            height=10, 
            background='black', 
            foreground='white'
        )
        self.text_box.pack(side='left', padx=(30,100))

        return msg_frame

    def _create_new_ui_elements(self):
        """Add new UI components for features"""
        # We've removed this content since we're moving the buttons
        pass

    def _create_chat_ui(self):
        """Create a chat window that appears when toggled"""
        # Create chat window (initially hidden)
        self.chat_window = tk.Toplevel(self.root)
        self.chat_window.title("Monopoly Chat")
        self.chat_window.geometry("400x300")
        self.chat_window.protocol("WM_DELETE_WINDOW", self._hide_chat_window)
        self.chat_window.withdraw()  # Start hidden
        
        # Chat container frame
        chat_frame = ttk.Frame(self.chat_window, padding=10)
        chat_frame.pack(fill=tk.BOTH, expand=True)
        
        # Chat log with scrollbar
        self.chat_log = tk.Text(
            chat_frame,
            height=15,
            state='disabled',
            wrap=tk.WORD,
            background='#222222',
            foreground='white',
            font=('Arial', 10))
        scrollbar = ttk.Scrollbar(chat_frame, command=self.chat_log.yview)
        self.chat_log['yscrollcommand'] = scrollbar.set
        
        # Input area
        input_frame = ttk.Frame(chat_frame)
        
        # Chat input field
        self.chat_input = ttk.Entry(
            input_frame,
            font=('Arial', 10))
        self.chat_input.insert(0, "Type your message here...")
        self.chat_input.bind("<FocusIn>", lambda e: self.chat_input.delete(0, tk.END))
        self.chat_input.bind("<Return>", lambda e: self._send_chat_message())
        
        # Send button
        chat_send = ttk.Button(
            input_frame,
            text="Send",
            command=self._send_chat_message)
        
        # Layout using grid
        self.chat_log.grid(row=0, column=0, sticky='nsew', padx=5, pady=5)
        scrollbar.grid(row=0, column=1, sticky='ns', pady=5)
        input_frame.grid(row=1, column=0, columnspan=2, sticky='ew', padx=5, pady=(0,5))
        
        self.chat_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0,5))
        chat_send.pack(side=tk.RIGHT)
        
        # Make chat area expandable
        chat_frame.columnconfigure(0, weight=1)
        chat_frame.rowconfigure(0, weight=1)

    def _toggle_chat(self):
        """Toggle chat window visibility"""
        if self.chat_window.winfo_viewable():
            self._hide_chat_window()
        else:
            self._show_chat_window()

    def _show_chat_window(self):
        """Show the chat window"""
        self.chat_window.deiconify()
        self.chat_toggle_btn.config(text="▼ Hide Chat")
        self.chat_input.focus_set()

    def _hide_chat_window(self):
        """Hide the chat window"""
        self.chat_window.withdraw()
        self.chat_toggle_btn.config(text="💬 Chat")

    def _add_listeners(self):
        """Add core game listeners"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        self.observe("update_timer", self._update_timer)

    def _add_new_listeners(self):
        """Add listeners for new features"""
        self.observe("update_chat", self._update_chat_display)

    def _action_taken(self, action):
        """Handle button actions"""
        if action in ["roll", "purchase", "mortgage", "unmortgage", "end_turn", "save_game"]:
            observer.Event(action, None)
        elif action == "mortgage_specific":
            observer.Event(action, 0)


    def _send_chat_message(self):
        """Handle sending chat messages"""
        message = self.chat_input.get()
        if message and message.strip():
            observer.Event("send_chat", message.strip())
            self.chat_input.delete(0, 'end')

    def _update_chat_display(self, messages):
        """Update chat display with new messages"""
        self.chat_messages = messages[-50:]  # Keep last 50 messages
        self.chat_log.config(state='normal')
        self.chat_log.delete(1.0, tk.END)
        for msg in self.chat_messages:
            self.chat_log.insert(tk.END, msg + '\n')
        self.chat_log.config(state='disabled')
        self.chat_log.see(tk.END)

    def _update_timer(self, remaining_time):
        """Update the timer display"""
        try:
            self.timer_label.config(text=f"Time: {remaining_time}")
            if remaining_time <= 10:
                self.timer_label.config(foreground='red')
            elif remaining_time <= 20:
                self.timer_label.config(foreground='orange')
            else:
                self.timer_label.config(foreground='green')
        except tk.TclError:
            pass

    def update_card(self, index):
        """Update property card display"""
        if 0 <= index < len(self.images):
            self.card.config(image=self.images[index])

    def _update_text(self, text=""):
        """Update message box"""
        self.text_box.insert(tk.END, text + "\n")
        self.text_box.see(tk.END)

    def update_state_box(self, text=""):
        """Update game state box"""
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)
        self.state_box.see(tk.END)

    def _choose(self, choices):
        """Show choice popup menu"""
        popup = tk.Menu(self.root, tearoff=0)
        for choice in choices:
            popup.add_command(
                label=choice,
                command=lambda c=choice: observer.Event("choice_selected", c)
            )
        popup.add_separator()
        popup.add_command(label="Cancel", command=popup.grab_release)
        
        try:
            popup.tk_popup(self.root.winfo_pointerx(), self.root.winfo_pointery())
        finally:
            popup.grab_release()

    def _preload_images(self):
        """Preload property card images"""
        square_images = get_board_square_images()
        for image in square_images:
            try:
                img = tk.PhotoImage(file=image)
                self.images.append(img)
            except:
                print(f"Failed to load image: {image}")
                self.images.append(tk.PhotoImage())

    def _clear_text(self):
        """Clear the text box content"""
        self.text_box.delete(1.0, tk.END)

if __name__ == '__main__':
    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()
    
    # Create controller instance first
    game_controller = controller.Controller(root)
    
    root.mainloop()