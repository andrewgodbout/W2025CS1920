import pickle
import json
from datetime import datetime
import os

class GameSaver:
    SAVE_DIR = "saves"
    
    @classmethod
    def save_game(cls, game_state):
        os.makedirs(cls.SAVE_DIR, exist_ok=True)
        filename = f"{cls.SAVE_DIR}/save_{datetime.now().strftime('%Y%m%d_%H%M%S')}.monopoly"
        with open(filename, 'wb') as f:
            pickle.dump(game_state, f)
        return filename

    @classmethod
    def load_game(cls, filename):
        with open(filename, 'rb') as f:
            return pickle.load(f)

    @classmethod
    def list_saves(cls):
        os.makedirs(cls.SAVE_DIR, exist_ok=True)
        return [f for f in os.listdir(cls.SAVE_DIR) if f.endswith('.monopoly')]