import json
import os
from collections import defaultdict

class Leaderboard:
    FILE_PATH = "leaderboard.json"
    
    def __init__(self):
        self.scores = defaultdict(lambda: {'wins': 0, 'games': 0})
        self._load()
        
    def _load(self):
        if os.path.exists(self.FILE_PATH):
            with open(self.FILE_PATH, 'r') as f:
                self.scores.update(json.load(f))
                
    def _save(self):
        with open(self.FILE_PATH, 'w') as f:
            json.dump(dict(self.scores), f)
            
    def update(self, player_name, won=False):
        self.scores[player_name]['games'] += 1
        if won:
            self.scores[player_name]['wins'] += 1
        self._save()
        
    def get_top_players(self, n=5):
        return sorted(self.scores.items(), 
                    key=lambda x: x[1]['wins'], 
                    reverse=True)[:n]