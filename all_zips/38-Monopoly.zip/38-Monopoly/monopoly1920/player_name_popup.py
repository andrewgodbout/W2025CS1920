from tkinter import Toplevel, Label, Entry, Button, StringVar

class PlayerNamePopup:
    def __init__(self, num_players, root, size):
        self.num_players = num_players
        self.name_vars = []
        self.root = root
        self.size = size
    
    def open(self):
        # opens the popup
        popup = Toplevel()
        popup.geometry(self.size) # taken from view.py
        popup.resizable(False, False) # taken from view.py
        popup.title("Player Names")

        for i in range(self.num_players):
            # create label and input entry for each player
            Label(popup, text=f"Enter player {i+1}'s name:").pack(pady=5)
            name_var = StringVar()
            entry = Entry(popup, textvariable=name_var)
            entry.pack(pady=5)
            self.name_vars.append(name_var)
    
        Button(popup, text="Start Game", command=popup.destroy).pack()

        # Make the popup modal (from deepseek)
        popup.transient(self.root)
        popup.grab_set()
        popup.wait_window()
    
    @property
    def names(self):
        # property to get strings
        return [var.get() for var in self.name_vars]
