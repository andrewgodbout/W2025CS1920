from tkinter import Toplevel, Label, Entry, Button, IntVar

class GameSettings:
    def __init__(self, num_players, starting_money, seconds_per_turn):
        self.num_players = num_players
        self.starting_money = starting_money
        self.seconds_per_turn = seconds_per_turn

class GameSettingsPopup:
    def __init__(self,  root, size):
        self.root = root
        self.size = size
        self.number_of_players_var = IntVar()
        self.money_var = IntVar()
        self.seconds_var = IntVar()
    
    def open(self):
        popup = Toplevel()
        popup.geometry(self.size) # taken from view.py
        popup.resizable(False, False) # taken from view.py
        popup.title("Game Settings")

        Label(popup, text="Enter number of players (default is 3)").pack(pady=5)
        entry_1 = Entry(popup, textvariable=self.number_of_players_var)
        entry_1.pack(pady=5)
        
        Label(popup, text="Enter starting money (default is 1500)").pack(pady=5)
        entry_2 = Entry(popup, textvariable=self.money_var)
        entry_2.pack(pady=5)

        Label(popup, text="Enter number of seconds per turn (default is 60)").pack(pady=5)
        entry_3 = Entry(popup, textvariable=self.seconds_var)
        entry_3.pack(pady=5)

        Button(popup, text="Continue", command=popup.destroy).pack()

        # Make the popup modal
        popup.transient(self.root)
        popup.grab_set()
        popup.wait_window()
    
    @property
    def settings(self):
        # get outputs from entries on the popup
        num_players = self.number_of_players_var.get()
        if num_players < 2:
            num_players = 3
        
        money = self.money_var.get()
        if money < 100:
            money = 1500

        seconds = self.seconds_var.get()
        if seconds < 10:
            seconds = 60
        
        return GameSettings(num_players, money, seconds)