class TurnClock:
    def __init__(self, label, seconds, on_finished):
        self.label = label
        self.start_seconds = seconds
        self.seconds = seconds
        self.on_finished = on_finished
        self.running = False
        self.update_id = None
    
    def reset(self):
        self.seconds = self.start_seconds
        if self.update_id:
            self.label.after_cancel(self.update_id) # from deepseek to stop the timer callbacks
    
    def tick_recursive(self):
        self.seconds -= 1
        if self.seconds < 0:
            self.seconds = 0
        
        minutes = self.seconds // 60
        seconds = self.seconds % 60

        if seconds < 10:
            seconds = '0' + str(seconds) # format
        
        text = str(minutes) + ':' + str(seconds)
        self.label.config(text=text)

        if self.seconds > 0:
            # need to tick more
            self.update_id = self.label.after(1000, self.tick_recursive)
        else:
            if self.on_finished:
                # callback
                self.on_finished()
    
    def run_until_done(self):
        minutes = self.seconds // 60
        seconds = self.seconds % 60

        if seconds < 10:
            seconds = '0' + str(seconds)
        
        text = str(minutes) + ':' + str(seconds)
        self.label.config(text=text)

        self.update_id = self.label.after(1000, self.tick_recursive)
