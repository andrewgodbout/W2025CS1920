import observer
import datetime

class GameLogger(observer.Observer):
    """Logs game events (primarily from 'update_state') to the console."""

    def __init__(self, log_to_file=False, filename="monopoly_log.txt"):
        super().__init__() #Initialize the Observer base class
        self.log_to_file = log_to_file
        self.filename = filename
        if self.log_to_file:
            #Clear or create the log file at the start
            try:
                with open(self.filename, "w") as f:
                    f.write(f"--- Game Log Started: {self._get_timestamp()} ---\n")
            except IOError as e:
                print(f"Error creating log file '{self.filename}': {e}")
                self.log_to_file = False #Disable file logging if creation failed

        #Subscribe to the 'update_state' event as it carries most messages
        self.observe("update_state", self._log_event)
        #Subscribe to 'update_state_box' for board state snapshots
        self.observe("update_state_box", self._log_state_box)

        #Log initialization itself
        self._log("GameLogger initialized and observing events.")


    def _get_timestamp(self):
        """Returns current timestamp as a string."""
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] #Added milliseconds

    def _log(self, message):
        """Helper function to print and optionally write to file."""
        timestamp = self._get_timestamp()
        log_entry = f"[{timestamp}] {message}"
        print(log_entry) #Always print to console
        if self.log_to_file:
            try:
                with open(self.filename, "a") as f:
                    f.write(log_entry + "\n")
            except IOError as e:
                print(f"Error writing to log file '{self.filename}': {e}")

    def _log_event(self, data):
        """Logs data from the 'update_state' event."""
        if isinstance(data, str):
            self._log(f"STATE: {data}")
        else:
            self._log(f"STATE_EVENT (non-str): {type(data)} - {str(data)[:100]}") #Log type and snippet

    def _log_state_box(self, data):
        """Logs data from the 'update_state_box' event (board state)."""
        if isinstance(data, str):
            self._log(f"BOARD_UPDATE:\n---\n{data}\n---")
        else:
             self._log(f"BOARD_UPDATE (non-str): {type(data)}")