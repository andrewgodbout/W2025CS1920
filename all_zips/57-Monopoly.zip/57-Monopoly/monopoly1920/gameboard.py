import player
import gamesquare
import random
import observer


class GameBoard:
    __boardCSV = {
        "name": 0,
        "space": 1,
        "color": 2,
        "position": 3,
        "price": 4,
        "build": 5,
        "rent": 6,
        "rent1": 7,
        "rent2": 8,
        "rent3": 9,
        "rent4": 10,
        "rent5": 11,
        "hotelcost": 12,
        "owner": 13,
        "houses": 14,
        "groupmembers": 15
    }

    def __init__(self, properties_path, players):
        self.__properties = self._load_game_board(properties_path)
        self.__players = players
        self.__total_turns = 0

        # set the current player
        self.__current_player = self.__players.pop(0)

    def next_turn(self):
        # add the prior player to the end of the queue
        if not self.__current_player.bankrupt_declared:
            self.__players.append(self.__current_player)

        self.__total_turns += 1

        # set the current player to the next player in the queue
        self.__current_player = self.__players.pop(0)

        return self.__current_player.name

    def calculate_expected_value(self, pos, doubles_count):
        """calculate the expected outcome of the next turn"""
        expected_value = 0
        for i in range(1, 7):
            for j in range(1, 7):
                new_pos = (pos + i + j) % 40
                # base case calculate the outcome of landing on the square
                if doubles_count == 2 and i == j:
                    continue  # go to jail

                expected_value += (self.get_board_square(new_pos).calculate_rent_or_tax(i + j) / 36)
                if i == j:
                    # recursive case roll again don't forget this must be multiplied by
                    # the probability of rolling a double (1/36)
                    expected_value += (self.calculate_expected_value(new_pos, doubles_count + 1) / 36)
        return expected_value

    def get_current_player(self):
        """return the current player"""
        return self.__current_player

    def get_all_squares(self):
        return self.__properties

    def get_square(self, index):
        return self.__properties[index]

    def get_all_players(self):
        """Return all players including the current player

        Returns:
            list: A list of all Player objects
        """
        all_players = [self.__current_player] + self.__players
        return all_players

    def get_board_square(self, index):
        """Function to return the board square at the given index
            @:param game_board: an ordered list of Properties
            @:param index: the index of the space on the board
            @:return square: the square at the given index
        """
        square = self.__properties[index]
        return square

    def draw_chance_card(self):
        """Draw a card from the Chance deck and handle its effect

        Returns:
            bool: True if the player's turn should end after handling the card, False otherwise
        """
        card_action, card_description = self._get_chance_card()
        observer.Event("update_state", f"Chance Card: {card_description}")
        return self._handle_card_action(card_action, self.__current_player)

    def draw_community_chest_card(self):
        """Draw a card from the Community Chest deck and handle its effect

        Returns:
            bool: True if the player's turn should end after handling the card, False otherwise
        """
        card_action, card_description = self._get_community_chest_card()
        observer.Event("update_state", f"Community Chest Card: {card_description}")
        return self._handle_card_action(card_action, self.__current_player)

    def _get_chance_card(self):
        """Get a random Chance card

        Returns:
            tuple: (action, description)
        """
        cards = [
            ("move_to_go", "Advance to Go. Collect $200."),
            ("move_to_illinois", "Advance to Illinois Avenue. If you pass Go, collect $200."),
            ("move_to_st_charles", "Advance to St. Charles Place. If you pass Go, collect $200."),
            ("move_to_nearest_railroad",
             "Advance to the nearest Railroad. If unowned, you may buy it from the Bank. If owned, pay owner twice the rental."),
            ("move_to_nearest_utility",
             "Advance to the nearest Utility. If unowned, you may buy it from the Bank. If owned, throw dice and pay owner 10 times the amount thrown."),
            ("collect_50", "Bank pays you dividend of $50."),
            ("get_out_of_jail", "Get Out of Jail Free. This card may be kept until needed or sold."),
            ("go_back_3", "Go Back 3 Spaces."),
            ("go_to_jail", "Go to Jail. Go directly to Jail. Do not pass Go. Do not collect $200."),
            ("repairs", "Make general repairs on all your property. For each house pay $25. For each hotel pay $100."),
            ("pay_15", "Pay poor tax of $15."),
            ("move_to_reading", "Take a trip to Reading Railroad. If you pass Go, collect $200."),
            ("move_to_boardwalk", "Take a walk on the Boardwalk. Advance to Boardwalk."),
            ("collect_150", "Your building loan matures. Collect $150."),
            ("collect_100", "You have won a crossword competition. Collect $100.")
        ]
        return random.choice(cards)

    def _get_community_chest_card(self):
        """Get a random Community Chest card

        Returns:
            tuple: (action, description)
        """
        cards = [
            ("move_to_go", "Advance to Go. Collect $200."),
            ("collect_200", "Bank error in your favor. Collect $200."),
            ("pay_50", "Doctor's fee. Pay $50."),
            ("collect_50_stock", "From sale of stock you get $50."),
            ("get_out_of_jail", "Get Out of Jail Free. This card may be kept until needed or sold."),
            ("go_to_jail", "Go to Jail. Go directly to Jail. Do not pass Go. Do not collect $200."),
            ("collect_from_players", "It is your birthday. Collect $10 from every player."),
            ("collect_100", "Holiday fund matures. Receive $100."),
            ("collect_20", "Income tax refund. Collect $20."),
            ("collect_100_life", "Life insurance matures. Collect $100."),
            ("pay_100", "Pay hospital fees of $100."),
            ("pay_50_school", "Pay school fees of $50."),
            ("collect_25", "Receive $25 consultancy fee."),
            ("repairs", "You are assessed for street repairs. $40 per house. $115 per hotel."),
            ("collect_10", "You have won second prize in a beauty contest. Collect $10."),
            ("collect_100_inherit", "You inherit $100.")
        ]
        return random.choice(cards)

    def _handle_card_action(self, action, player):
        """Handle the effect of a card

        Args:
            action (str): The action to perform
            player: The Player object

        Returns:
            bool: True if the player's turn should end after handling the card, False otherwise
        """
        # Handle different card actions
        if action == "move_to_go":
            player.position = 0
            player.collect(200)
            observer.Event("update_state", "Moved to Go. Collected $200.")
            observer.Event("update_card", 0)

        elif action == "move_to_illinois":
            current_pos = player.position
            player.position = 24  # Illinois Avenue
            if current_pos > 24:  # Passed Go
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")
            observer.Event("update_state", "Moved to Illinois Avenue.")
            observer.Event("update_card", 24)

        elif action == "move_to_st_charles":
            current_pos = player.position
            player.position = 11  # St. Charles Place
            if current_pos > 11:  # Passed Go
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")
            observer.Event("update_state", "Moved to St. Charles Place.")
            observer.Event("update_card", 11)

        elif action == "move_to_nearest_railroad":
            current_pos = player.position
            # Find nearest railroad (positions 5, 15, 25, 35)
            railroad_positions = [5, 15, 25, 35]
            nearest = min(railroad_positions, key=lambda x: (x - current_pos) % 40)

            # Check if passing Go
            if nearest < current_pos:
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")

            player.position = nearest
            observer.Event("update_state", f"Moved to {self.get_square(nearest).name}.")
            observer.Event("update_card", nearest)

            # Pay double rent if owned
            square = self.get_square(nearest)
            if square.owner is not None and square.owner is not player and not square.is_mortgaged:
                rent = square.calculate_rent_or_tax(0) * 2
                player.money -= rent
                square.owner.money += rent
                observer.Event("update_state", f"Paid ${rent} (double rent) to {square.owner.name}")

        elif action == "move_to_nearest_utility":
            current_pos = player.position
            # Find nearest utility (positions 12, 28)
            utility_positions = [12, 28]
            nearest = min(utility_positions, key=lambda x: (x - current_pos) % 40)

            # Check if passing Go
            if nearest < current_pos:
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")

            player.position = nearest
            observer.Event("update_state", f"Moved to {self.get_square(nearest).name}.")
            observer.Event("update_card", nearest)

            # Pay 10x dice roll if owned
            square = self.get_square(nearest)
            if square.owner is not None and square.owner is not player and not square.is_mortgaged:
                # Use average dice roll of 7
                dice_sum = 7
                rent = 10 * dice_sum
                player.money -= rent
                square.owner.money += rent
                observer.Event("update_state", f"Paid ${rent} (10 × dice roll) to {square.owner.name}")

        elif action == "collect_50" or action == "collect_50_stock":
            player.collect(50)
            observer.Event("update_state", "Collected $50.")

        elif action == "get_out_of_jail":
            player.add_get_out_of_jail_card()
            observer.Event("update_state", "Got a Get Out of Jail Free card.")

        elif action == "go_back_3":
            player.position = (player.position - 3) % 40
            observer.Event("update_state", f"Moved back 3 spaces to {self.get_square(player.position).name}.")
            observer.Event("update_card", player.position)

        elif action == "go_to_jail":
            player.position = 10  # Jail is at position 10
            player.in_jail = True
            observer.Event("update_state", "Go to Jail! Do not pass Go. Do not collect $200.")
            observer.Event("update_card", 10)
            return True  # End turn

        elif action == "repairs":
            # In a real implementation, we would count houses and hotels
            # For now, assume no houses or hotels
            observer.Event("update_state", "No properties to repair.")

        elif action == "pay_15":
            player.money -= 15
            observer.Event("update_state", "Paid $15 poor tax.")

        elif action == "move_to_reading":
            current_pos = player.position
            player.position = 5  # Reading Railroad
            if current_pos > 5:  # Passed Go
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")
            observer.Event("update_state", "Moved to Reading Railroad.")
            observer.Event("update_card", 5)

        elif action == "move_to_boardwalk":
            current_pos = player.position
            player.position = 39  # Boardwalk
            if current_pos > 39:  # Passed Go
                player.collect(200)
                observer.Event("update_state", "Passed Go. Collected $200.")
            observer.Event("update_state", "Moved to Boardwalk.")
            observer.Event("update_card", 39)

        elif action == "collect_150":
            player.collect(150)
            observer.Event("update_state", "Collected $150 from building loan.")

        elif action == "collect_100" or action == "collect_100_life" or action == "collect_100_inherit":
            player.collect(100)
            observer.Event("update_state", "Collected $100.")

        elif action == "collect_200":
            player.collect(200)
            observer.Event("update_state", "Collected $200 from bank error.")

        elif action == "pay_50" or action == "pay_50_school":
            player.money -= 50
            observer.Event("update_state", "Paid $50.")

        elif action == "collect_from_players":
            total = 0
            for other_player in self.get_all_players():
                if other_player is not player and not other_player.bankrupt_declared:
                    other_player.money -= 10
                    total += 10
            player.collect(total)
            observer.Event("update_state", f"Collected ${total} from other players.")

        elif action == "collect_20":
            player.collect(20)
            observer.Event("update_state", "Collected $20 tax refund.")

        elif action == "pay_100":
            player.money -= 100
            observer.Event("update_state", "Paid $100 hospital fees.")

        elif action == "collect_25":
            player.collect(25)
            observer.Event("update_state", "Collected $25 consultancy fee.")

        elif action == "collect_10":
            player.collect(10)
            observer.Event("update_state", "Collected $10 beauty contest prize.")

        # Check if player is bankrupt after card effect
        if player.money < 0:
            observer.Event("update_state", f"{player.name} is bankrupt!")
            player.declare_bankrupt()
            return True  # End turn

        return False  # Continue turn

    def _load_game_board(self, csv_path):
        """Function to load and return the game board from a file
            :param csv_path: the path to the csv file containing the board data
            :return game_board: an ordered list of the game board spaces
                                 where the 0th index is "GO" and the indices
                                 proceed clockwise around the board
        """
        properties = []

        f = open(csv_path, "r")
        next(f)  # skip the header row of the file, we don't need it for this game
        for line in f:
            line = line.strip()
            line = line.split(",")

            # create a property object
            utility = line[self.__boardCSV["space"]] == "Utility"
            railroad = line[self.__boardCSV["space"]] == "Railroad"
            sq = gamesquare.GameSquare(name=line[self.__boardCSV["name"]], price=int(line[self.__boardCSV["price"]]),
                                       rent=int(line[self.__boardCSV["rent"]]), color=line[self.__boardCSV["color"]],
                                       is_utility=utility, is_railroad=railroad, space=line[self.__boardCSV["space"]])
            properties.append(sq)
        f.close()

        return properties

    def __str__(self):
        board_str = "player - cash - net worth - position\n"
        board_str += f"{self.__current_player} "
        board_str += f"{self.get_board_square(self.__current_player.position).name}\n"
        for player in self.__players:
            if player.bankrupt_declared:
                board_str += f"{player.name} declared bankruptcy\n"
                continue
            board_str += f"{player} "
            board_str += f"{self.get_board_square(player.position).name}\n"

        return board_str

