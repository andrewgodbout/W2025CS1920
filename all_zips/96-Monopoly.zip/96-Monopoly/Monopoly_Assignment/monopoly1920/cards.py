from collections import deque
import controller

class Card:
    def __init__(self, description, effect):
        self.description = description
        self.effect = effect

    def __str__(self):
        return self.description

chance_cards = [
    Card("Advance to Go", "advance_to_go"),
    Card("Go to Jail", "go_to_jail"),
    Card("Pay $60", "pay_60"),
    Card("Pay school tax","school_tax_150")
]

community_chest_cards = [
    Card("Get Out of Jail Free", "get_out_of_jail_free"),
    Card("You inherit $100", "inherit_100"),
    Card("Go three spaces forward","forward_3")
]

class CardDeck:
    def __init__(self, cards):
        self.deck = deque(cards)

    def draw_card(self):
        if not self.deck:
            print("No more cards in the deck. Shuffling...")
            self.shuffle_deck()
        return self.deck.popleft()

    def shuffle_deck(self):
        self.deck = deque(random.sample(self.deck, len(self.deck)))

    def handle_landing(self, player):
        """Handle the logic when a player lands on a square."""
        square = self.get_square(player.position)

        if square.is_chance:
            self.card_action("chance")
        elif square.is_community_chest:
            self.card_action("community_chest")
        else:
            pass

