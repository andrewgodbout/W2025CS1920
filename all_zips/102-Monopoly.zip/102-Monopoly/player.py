import gameboard
import gamesquare
import observer


class Player:
    def __init__(self, name, money):
        """Constructor to initialize the player's name, money, and owned properties."""
        self.name = name
        self.money = money
        self.properties = []

    def owns_full_color_group(self, color):
        """Checks if the player owns all properties of a specific color group."""
        color_groups = {
            "Brown": ["Mediterranean Avenue", "Baltic Avenue"],
            "Light Blue": ["Oriental Avenue", "Vermont Avenue", "Connecticut Avenue"],
            "Pink": ["St. Charles Place", "States Avenue", "Virginia Avenue"],
            "Orange": ["St. James Place", "Tennessee Avenue", "New York Avenue"],
            "Red": ["Kentucky Avenue", "Indiana Avenue", "Illinois Avenue"],
            "Yellow": ["Atlantic Avenue", "Ventnor Avenue", "Marvin Gardens"],
            "Green": ["Pacific Avenue", "North Carolina Avenue", "Pennsylvania Avenue"],
            "Dark Blue": ["Park Place", "Boardwalk"]
        }
        properties_of_color = color_groups.get(color, [])
        if properties_of_color:
            owned_properties = [prop.name for prop in self.properties]
            return all(prop in owned_properties for prop in properties_of_color)

        return False

    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def position(self):
        return self.__board_position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @properties.setter
    def properties(self, value):
        self.__properties = value

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]


