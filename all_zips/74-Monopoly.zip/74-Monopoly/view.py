import tkinter as tk
import os
from tkinter import ttk
import controller
import observer


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

        #self.setup_game()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)


    def _create_middle_frame(self):
        """Create the middle frame with buttons"""
        middle_frame = ttk.Frame(self.main_frame)
        middle_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        button_frame = ttk.Frame(middle_frame)
        button_frame.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)

        # Game control buttons
        self.__roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll"))
        self.__roll_button.pack(side=tk.LEFT, padx=2)

        self.__end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.__end_turn_button.pack(side=tk.LEFT, padx=2)

        # Property action buttons
        self.__purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.__purchase_button.pack(side=tk.LEFT, padx=2)

        self.__mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.__mortgage_button.pack(side=tk.LEFT, padx=2)

        self.__unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.__unmortgage_button.pack(side=tk.LEFT, padx=2)

        # Jail action buttons
        self.__pay_jail_fine_button = ttk.Button(button_frame, text="Pay $50 Jail Fine", command=lambda: self._action_taken("pay_jail_fine"))
        self.__pay_jail_fine_button.pack(side=tk.LEFT, padx=2)
        self.__pay_jail_fine_button.state(['disabled'])

        self.__use_jail_card_button = ttk.Button(button_frame, text="Use Jail Card", command=lambda: self._action_taken("use_jail_card"))
        self.__use_jail_card_button.pack(side=tk.LEFT, padx=2)
        self.__use_jail_card_button.state(['disabled'])

        # Trading and equity buttons
        self.__trade_button = ttk.Button(button_frame, text="Trade Property", command=lambda: self._action_taken("start_trade"))
        self.__trade_button.pack(side=tk.LEFT, padx=2)

        self.__equity_button = ttk.Button(button_frame, text="Buy Equity", command=lambda: self._action_taken("start_equity"))
        self.__equity_button.pack(side=tk.LEFT, padx=2)

        # Save and load game buttons
        self.__save_button = ttk.Button(button_frame, text="Save Game", command=lambda: self._action_taken("save_game"))
        self.__save_button.pack(side=tk.LEFT, padx=2)

        self.__load_button = ttk.Button(button_frame, text="Load Game", command=self._show_load_game_dialog)
        self.__load_button.pack(side=tk.LEFT, padx=2)

        # State box
        self.__state_box = tk.Text(middle_frame, height=10, width=40)
        self.__state_box.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=5, pady=5)

        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)
        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        return middle_frame

    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))

        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,100))

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action, data=None):
        """Handle button clicks"""
        if action == "roll":
            observer.Event("roll")
        elif action == "end_turn":
            observer.Event("end_turn")
        elif action == "purchase":
            observer.Event("purchase")
        elif action == "mortgage":
            observer.Event("mortgage")
        elif action == "unmortgage":
            observer.Event("unmortgage")
        elif action == "pay_jail_fine":
            observer.Event("pay_jail_fine")
        elif action == "use_jail_card":
            observer.Event("use_jail_card")
        elif action == "start_trade":
            observer.Event("start_trade")
        elif action == "start_equity":
            observer.Event("start_equity")
        elif action == "save_game":
            observer.Event("save_game")
        elif action == "load_game":
            observer.Event("load_game", data)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        """Update the state box and enable/disable buttons based on player state"""
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)
        
        # Check if current player is in jail
        if "in jail" in text.lower():
            self.__pay_jail_fine_button.state(['active'])
            self.__use_jail_card_button.state(['active'])
        else:
            self.__pay_jail_fine_button.state(['disabled'])
            self.__use_jail_card_button.state(['disabled'])

    def _choose(self, choices):
        """Handle property selection for trading"""
        self.popup_menu = tk.Menu(self.root, tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                      command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
            lbl = "No properties to trade (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                  command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        """Handle property selection"""
        observer.Event("propose_trade", s)

    def _create_input_dialog(self, title, message):
        """Create a dialog for input"""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("300x150")
        
        label = ttk.Label(dialog, text=message)
        label.pack(pady=10)
        
        entry = ttk.Entry(dialog)
        entry.pack(pady=10)
        
        def submit():
            value = entry.get()
            dialog.destroy()
            observer.Event("accept_trade", value)
            
        submit_button = ttk.Button(dialog, text="Submit", command=submit)
        submit_button.pack(pady=10)
        
        dialog.transient(self.root)
        dialog.grab_set()
        self.root.wait_window(dialog)

    def _create_equity_dialog(self, title, message):
        """Create a dialog for equity input"""
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("300x200")
        
        label = ttk.Label(dialog, text=message)
        label.pack(pady=10)
        
        amount_frame = ttk.Frame(dialog)
        amount_frame.pack(pady=5)
        ttk.Label(amount_frame, text="Amount: $").pack(side=tk.LEFT)
        amount_entry = ttk.Entry(amount_frame)
        amount_entry.pack(side=tk.LEFT)
        
        percentage_frame = ttk.Frame(dialog)
        percentage_frame.pack(pady=5)
        ttk.Label(percentage_frame, text="Percentage: ").pack(side=tk.LEFT)
        percentage_entry = ttk.Entry(percentage_frame)
        percentage_entry.pack(side=tk.LEFT)
        
        def submit():
            amount = amount_entry.get()
            percentage = percentage_entry.get()
            dialog.destroy()
            observer.Event("accept_equity", f"{amount} {percentage}")
            
        submit_button = ttk.Button(dialog, text="Submit", command=submit)
        submit_button.pack(pady=10)
        
        dialog.transient(self.root)
        dialog.grab_set()
        self.root.wait_window(dialog)

    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def _show_load_game_dialog(self):
        """Show dialog to select a saved game to load"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Load Game")
        dialog.geometry("300x400")

        # Get list of saved games
        saved_games = self._game_state.get_saved_games()

        # Create listbox with saved games
        listbox = tk.Listbox(dialog, width=40, height=15)
        listbox.pack(padx=10, pady=10)

        for game in saved_games:
            listbox.insert(tk.END, game)

        def load_selected():
            selection = listbox.curselection()
            if selection:
                filename = listbox.get(selection[0])
                self._action_taken("load_game", filename)
                dialog.destroy()

        # Load button
        load_button = ttk.Button(dialog, text="Load", command=load_selected)
        load_button.pack(pady=5)

        # Cancel button
        cancel_button = ttk.Button(dialog, text="Cancel", command=dialog.destroy)
        cancel_button.pack(pady=5)

'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()

