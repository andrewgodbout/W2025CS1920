import json
import os
from datetime import datetime

class GameState:
    """Class to handle saving and loading game states"""
    
    def __init__(self, gameboard, controller):
        self._gameboard = gameboard
        self._controller = controller
        self._save_dir = "saved_games"
        if not os.path.exists(self._save_dir):
            os.makedirs(self._save_dir)

    def save_game(self):
        """Save the current game state to a file"""
        game_state = {
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
            "players": self._serialize_players(),
            "properties": self._serialize_properties(),
            "current_player_index": self._get_current_player_index(),
            "dice_rolled": self._controller._Controller__dice_rolled,
            "roll_count": self._controller._Controller__roll_count,
            "trade_mode": self._controller._Controller__trade_mode,
            "equity_mode": self._controller._Controller__equity_mode
        }
        
        filename = f"monopoly_game_{game_state['timestamp']}.json"
        filepath = os.path.join(self._save_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(game_state, f, indent=4)
            
        return filename

    def load_game(self, filename):
        """Load a game state from a file"""
        filepath = os.path.join(self._save_dir, filename)
        if not os.path.exists(filepath):
            return False
            
        with open(filepath, 'r') as f:
            game_state = json.load(f)
            
        self._deserialize_players(game_state["players"])
        self._deserialize_properties(game_state["properties"])
        self._set_current_player(game_state["current_player_index"])
        self._controller._Controller__dice_rolled = game_state["dice_rolled"]
        self._controller._Controller__roll_count = game_state["roll_count"]
        self._controller._Controller__trade_mode = game_state["trade_mode"]
        self._controller._Controller__equity_mode = game_state["equity_mode"]
        
        return True

    def get_saved_games(self):
        """Get a list of saved game files"""
        if not os.path.exists(self._save_dir):
            return []
        return [f for f in os.listdir(self._save_dir) if f.endswith('.json')]

    def _serialize_players(self):
        """Serialize player data"""
        players_data = []
        for player in self._gameboard._GameBoard__players:
            player_data = {
                "name": player._Player__name,
                "money": player._Player__money,
                "position": player._Player__board_position,
                "doubles_count": player._Player__doubles_count,
                "bankrupt": player._Player__bankrupt_declared,
                "utility_count": player._Player__utility_count,
                "railroad_count": player._Player__railroad_count,
                "in_jail": player._Player__in_jail,
                "jail_turns": player._Player__jail_turns,
                "get_out_of_jail_free_cards": player._Player__get_out_of_jail_free_cards,
                "property_equity": player._Player__property_equity,
                "luck": player._Player__luck
            }
            players_data.append(player_data)
        return players_data

    def _serialize_properties(self):
        """Serialize property data"""
        properties_data = []
        for prop in self._gameboard._GameBoard__properties:
            prop_data = {
                "name": prop._GameSquare__name,
                "price": prop._GameSquare__price,
                "rent": prop._GameSquare__rent,
                "color": prop._GameSquare__color,
                "space": prop._GameSquare__space,
                "is_utility": prop._GameSquare__is_utility,
                "is_railroad": prop._GameSquare__is_railroad,
                "is_mortgaged": prop._GameSquare__is_mortgaged,
                "owner_index": self._get_player_index(prop._GameSquare__owner) if prop._GameSquare__owner else None
            }
            properties_data.append(prop_data)
        return properties_data

    def _deserialize_players(self, players_data):
        """Deserialize player data"""
        from player import Player
        self._gameboard._GameBoard__players = []
        for player_data in players_data:
            player = Player(player_data["name"], player_data["money"])
            player._Player__board_position = player_data["position"]
            player._Player__doubles_count = player_data["doubles_count"]
            player._Player__bankrupt_declared = player_data["bankrupt"]
            player._Player__utility_count = player_data["utility_count"]
            player._Player__railroad_count = player_data["railroad_count"]
            player._Player__in_jail = player_data["in_jail"]
            player._Player__jail_turns = player_data["jail_turns"]
            player._Player__get_out_of_jail_free_cards = player_data["get_out_of_jail_free_cards"]
            player._Player__property_equity = player_data["property_equity"]
            player._Player__luck = player_data["luck"]
            self._gameboard._GameBoard__players.append(player)

    def _deserialize_properties(self, properties_data):
        """Deserialize property data"""
        from gamesquare import GameSquare
        self._gameboard._GameBoard__properties = []
        for prop_data in properties_data:
            prop = GameSquare(
                name=prop_data["name"],
                price=prop_data["price"],
                rent=prop_data["rent"],
                space=prop_data["space"],
                color=prop_data["color"],
                is_utility=prop_data["is_utility"],
                is_railroad=prop_data["is_railroad"]
            )
            prop._GameSquare__is_mortgaged = prop_data["is_mortgaged"]
            if prop_data["owner_index"] is not None:
                prop._GameSquare__owner = self._gameboard._GameBoard__players[prop_data["owner_index"]]
            self._gameboard._GameBoard__properties.append(prop)

    def _get_current_player_index(self):
        """Get the index of the current player"""
        current_player = self._gameboard.get_current_player()
        return self._gameboard._GameBoard__players.index(current_player)

    def _set_current_player(self, index):
        """Set the current player by index"""
        self._gameboard._GameBoard__current_player = self._gameboard._GameBoard__players[index]

    def _get_player_index(self, player):
        """Get the index of a player"""
        if player is None:
            return None
        return self._gameboard._GameBoard__players.index(player) 