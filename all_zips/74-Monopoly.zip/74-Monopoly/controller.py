import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import game_state

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._game_state = game_state.GameState(self._gameboard, self)

        self._add_listeners()

        self.__dice_rolled = False
        self.__roll_count = 0
        self.__jail_square_index = 10  # jail on teh board is at poition 10 so setting this as a start point 
        self.__trade_mode = False
        self.__equity_mode = False
        self.__current_trade_property = None
        self.__current_equity_property = None
        self.__equity_negotiation_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("pay_jail_fine", self._pay_jail_fine)
        self.observe("use_jail_card", self._use_jail_card)
        self.observe("start_trade", self._start_trade)
        self.observe("start_equity", self._start_equity)
        self.observe("propose_trade", self._propose_trade)
        self.observe("propose_equity", self._propose_equity)
        self.observe("accept_trade", self._accept_trade)
        self.observe("accept_equity", self._accept_equity)
        self.observe("cancel_trade", self._cancel_trade)
        self.observe("cancel_equity", self._cancel_equity)
        self.observe("save_game", self._save_game)
        self.observe("load_game", self._load_game)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum, dice1 == dice2

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        player = self._gameboard.get_current_player()

        if self.__dice_rolled and not player.in_jail:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum, is_double = self._roll_dice()

        if player.in_jail:
            if is_double:
                player.get_out_of_jail()
                player.move(dice_sum)
            else:
                player.jail_turns += 1
                if player.jail_turns >= 3:
                    if player.pay_jail_fine():
                        player.move(dice_sum)
                    else:
                        observer.Event("update_state", "Not enough money to pay jail fine!")
                else:
                    observer.Event("update_state", f"Still in jail! Turn {player.jail_turns}/3")
            return True

        # Check for three doubles in a row
        if is_double:
            player.doubles_count += 1
            if player.doubles_count >= 3:
                player.go_to_jail()
                player.doubles_count = 0
                return True
        else:
            player.doubles_count = 0

        #move the player
        if player.move(dice_sum):
            position = player.position
            square = self._gameboard.get_square(position)

            # Check if landed on Go to Jail
            if square.space == "GotoJail":
                player.go_to_jail()
                return True

            #pay the rent
            rent = player.pay_rent(square, dice_sum)
            if rent != 0:
                print(f"rent paid: {rent}")
                player.luck -= rent
                observer.Event("update_state", f"Rent paid: {rent}")
                
                # Handle equity income
                if square.owner:
                    equity_income = player.get_equity_income(square.name, rent)
                    if equity_income > 0:
                        player.money += equity_income
                        square.owner.money -= equity_income
                        observer.Event("update_state", f"Received ${equity_income} from equity in {square.name}")

            #no money left?
            if player.money < 0:
                player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _pay_jail_fine(self, data):
        """Handle paying jail fine"""
        player = self._gameboard.get_current_player()
        if player.pay_jail_fine():
            observer.Event("update_state_box", str(self._gameboard))

    def _use_jail_card(self, data):
        """Handle using Get Out of Jail Free card"""
        player = self._gameboard.get_current_player()
        if player.use_get_out_of_jail_card():
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    def _start_trade(self, data):
        """Start the trading process"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return
            
        self.__trade_mode = True
        self.__equity_mode = False
        player = self._gameboard.get_current_player()
        observer.Event("update_state", f"{player.name} wants to trade. Select a property to trade.")
        observer.Event("choice", player.deed_names)

    def _start_equity(self, data):
        """Start the equity negotiation process"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return
            
        self.__equity_mode = True
        self.__trade_mode = False
        current_player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(current_player.position)
        
        if square.owner and square.owner != current_player:
            self.__current_equity_property = square
            observer.Event("update_state", f"Negotiating equity in {square.name}. Enter amount and percentage.")
        else:
            observer.Event("update_state", "Can only buy equity in other players' properties!")

    def _propose_trade(self, property_name):
        """Handle property selection for trading"""
        if not self.__trade_mode:
            return
            
        self.__current_trade_property = property_name
        current_player = self._gameboard.get_current_player()
        observer.Event("update_state", f"Enter amount for {property_name}:")

    def _propose_equity(self, data):
        """Handle equity proposal"""
        if not self.__equity_mode or not self.__current_equity_property:
            return
            
        try:
            amount, percentage = map(int, data.split())
            if percentage > 100 or percentage <= 0:
                observer.Event("update_state", "Percentage must be between 1 and 100!")
                return
                
            current_player = self._gameboard.get_current_player()
            if current_player.money < amount:
                observer.Event("update_state", "Not enough money!")
                return
                
            self.__equity_negotiation_count += 1
            observer.Event("update_state", f"Proposed: ${amount} for {percentage}% equity")
            
            if self.__equity_negotiation_count >= 2:
                observer.Event("update_state", "Maximum negotiation attempts reached. Turn ended.")
                self.__equity_mode = False
                self.__equity_negotiation_count = 0
                self._end_player_turn(lambda: None)
        except ValueError:
            observer.Event("update_state", "Please enter amount and percentage as numbers!")

    def _accept_trade(self, data):
        """Handle trade acceptance"""
        if not self.__trade_mode or not self.__current_trade_property:
            return
            
        try:
            amount = int(data)
            current_player = self._gameboard.get_current_player()
            other_player = self._gameboard.get_next_player()
            
            if current_player.trade_property(self.__current_trade_property, other_player, amount):
                observer.Event("update_state", f"Trade successful: {self.__current_trade_property} for ${amount}")
                observer.Event("update_state_box", str(self._gameboard))
            else:
                observer.Event("update_state", "Trade failed!")
                
            self.__trade_mode = False
            self.__current_trade_property = None
        except ValueError:
            observer.Event("update_state", "Please enter a valid amount!")

    def _accept_equity(self, data):
        """Handle equity acceptance"""
        if not self.__equity_mode or not self.__current_equity_property:
            return
            
        try:
            amount, percentage = map(int, data.split())
            current_player = self._gameboard.get_current_player()
            property_owner = self.__current_equity_property.owner
            
            if current_player.buy_equity(self.__current_equity_property.name, amount, percentage):
                observer.Event("update_state", f"Equity purchase successful: {percentage}% for ${amount}")
                observer.Event("update_state_box", str(self._gameboard))
            else:
                observer.Event("update_state", "Equity purchase failed!")
                
            self.__equity_mode = False
            self.__current_equity_property = None
            self.__equity_negotiation_count = 0
        except ValueError:
            observer.Event("update_state", "Please enter valid amount and percentage!")

    def _cancel_trade(self, data):
        """Cancel the trading process"""
        self.__trade_mode = False
        self.__current_trade_property = None
        observer.Event("update_state", "Trade cancelled.")

    def _cancel_equity(self, data):
        """Cancel the equity negotiation process"""
        self.__equity_mode = False
        self.__current_equity_property = None
        self.__equity_negotiation_count = 0
        observer.Event("update_state", "Equity negotiation cancelled.")

    def _save_game(self, data):
        """Save the current game state"""
        filename = self._game_state.save_game()
        if filename:
            observer.Event("update_state", f"Game saved as {filename}")
        else:
            observer.Event("update_state", "Failed to save game!")

    def _load_game(self, filename):
        """Load a saved game state"""
        if self._game_state.load_game(filename):
            observer.Event("update_state", f"Game loaded from {filename}")
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", self._gameboard.get_current_player().position)
        else:
            observer.Event("update_state", "Failed to load game!")




