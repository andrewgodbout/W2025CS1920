import player
import gamesquare

class GameBoard:

    __boardCSV = {
        "name": 0,
        "space": 1,
        "color": 2,
        "position": 3,
        "price": 4,
        "build": 5,
        "rent": 6,
        "rent1": 7,
        "rent2": 8,
        "rent3": 9,
        "rent4": 10,
        "rent5": 11,
        "hotelcost": 12,
        "owner": 13,
        "houses": 14,
        "groupmembers": 15
    }

    def __init__(self, properties_path, players):
        self.__properties = self._load_game_board(properties_path)
        self.__players = players
        self.__total_turns = 0

        # Set the first player as the current one
        self.__current_player = self.__players.pop(0)

    def next_turn(self):
        """Advance to the next player's turn"""
        if not self.__current_player.bankrupt_declared:
            self.__players.append(self.__current_player)

        self.__total_turns += 1
        self.__current_player = self.__players.pop(0)

        return self.__current_player.name

    def calculate_expected_value(self, pos, doubles_count):
        """Calculate the expected rent value of next move (used for AI/luck)"""
        expected_value = 0
        for i in range(1, 7):
            for j in range(1, 7):
                new_pos = (pos + i + j) % 40

                # Go to jail if 3 doubles
                if doubles_count == 2 and i == j:
                    continue

                expected_value += (self.get_board_square(new_pos).calculate_rent_or_tax(i + j) / 36)

                if i == j:
                    # Recursively calculate expected value on rolling doubles
                    expected_value += (self.calculate_expected_value(new_pos, doubles_count + 1) / 36)

        return expected_value

    def get_current_player(self):
        """Return the player whose turn it is"""
        return self.__current_player

    def get_all_squares(self):
        return self.__properties

    def get_square(self, index):
        return self.__properties[index]

    def get_board_square(self, index):
        """Return the square at a specific board index"""
        return self.__properties[index]

    def _load_game_board(self, csv_path):
        """Load game board data from CSV and return list of GameSquare instances"""
        properties = []
        with open(csv_path, "r") as f:
            next(f)  # Skip header
            for line in f:
                line = line.strip().split(",")

                utility = line[self.__boardCSV["space"]] == "Utility"
                railroad = line[self.__boardCSV["space"]] == "Railroad"

                sq = gamesquare.GameSquare(
                    name=line[self.__boardCSV["name"]],
                    price=int(line[self.__boardCSV["price"]]),
                    rent=int(line[self.__boardCSV["rent"]]),
                    color=line[self.__boardCSV["color"]],
                    is_utility=utility,
                    is_railroad=railroad,
                    space=line[self.__boardCSV["space"]]
                )

                properties.append(sq)

        return properties

    def __str__(self):
        """String summary of the gameboard showing players and their positions"""
        board_str = "player - cash - net worth - position\n"
        board_str += f"{self.__current_player} "
        board_str += f"{self.get_board_square(self.__current_player.position).name}\n"

        for player in self.__players:
            if player.bankrupt_declared:
                board_str += f"{player.name} declared bankruptcy\n"
            else:
                board_str += f"{player} "
                board_str += f"{self.get_board_square(player.position).name}\n"

        return board_str
