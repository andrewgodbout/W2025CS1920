import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)
        self._players_list = self._view.get_players()  # Retrieve the players list

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(len(self._players_list))
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")


    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i, name in enumerate(self._players_list):
            player = plr.Player(name, 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        player = self._gameboard.get_current_player()

        if dice1 == dice2:
            player.doubles_count += 1
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            if player.doubles_count == 3:
                observer.Event("update_state", f"{player.name} rolled doubles three times and goes to jail!")
                player.move_to_jail()
                self.__dice_rolled = False
                return dice_sum
        else:
            player.doubles_count = 0
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        if player.in_jail:
            if dice_sum == 12 or player.doubles_count > 0:
                observer.Event("update_state", f"{player.name} is out of jail!")
                player.in_jail = False
                player.turns_in_jail = 0
                player.move(dice_sum)
            else:
                observer.Event("update_state", f"{player.name} is still in jail. Turns in jail: {player.turns_in_jail}")
                player.turns_in_jail += 1
                if player.turns_in_jail >= 3:
                    observer.Event("update_state", f"{player.name} has been in jail for 3 turns and must pay $50 or use a 'Get Out of Jail Free' card")
                    # Handle paying $50 or using a 'Get Out of Jail Free' card
                return False

        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        if square.space == "Chance":
            self._gameboard.handle_chance(player)
        elif square.space == "Chest":
            self._gameboard.handle_community_chest(player)
        elif square.space == "GotoJail":
            observer.Event("update_state", f"{player.name} goes to jail!")
            player.move_to_jail()
        else:
            rent = player.pay_rent(square, dice_sum)
            if rent != 0:
                player.luck -= rent
                observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)




