import gameboard
import gamesquare
import observer


class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money, token):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__token= token

        #big numbers are lucky, negative numbers are unlucky
        self.__luck = 0

        #add a Data structure to track mortgaging order
        self.__mortgaging_order = []

#added by fatima,from here
        self.__jail_status = False
        self.__jail_rolls = 0
        self.__get_out_of_jail_cards = 0
#to here
    def __str__(self):
        """String representation of the player"""

        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"
# added by fatima from here
    def go_to_jail(self):
        """Send the player to jail."""
        # Go to jail for rolling doubles three times
        if self.__doubles_count == 3:
            self.__board_position = 10
            self.__jail_status = True
            self.__jail_rolls = 0
            print(f"{self.__name}, go to jail!")

        # Go to jail when landing on the "Go to Jail" square
        elif self.__board_position == 30:
            self.__board_position = 10
            self.__jail_status = True
            self.__jail_rolls = 0
            print(f"{self.__name}, go to jail!")

        # Just Visiting if they land on Jail without being sent
        elif self.__board_position == 10:
            self.__jail_status = False
            print(f"{self.__name} is just visiting jail.")

    def get_out_of_jail(self, rolled_doubles=False):
        """Allow the player to get out of jail by various means."""
        # Pay $50 to get out of jail or forced after 3 turns
        if self.__money >= 50 and (self.__jail_rolls >= 3 or not rolled_doubles):
            self.__money -= 50
            self.__jail_status = False
            self.__jail_rolls = 0
            print(f"{self.__name} paid $50 and is out of jail!")
            return

        # Use a "Get Out of Jail Free" card
        if self.__get_out_of_jail_cards > 0:
            self.__get_out_of_jail_cards -= 1
            self.__jail_status = False
            self.__jail_rolls = 0
            print(f"{self.__name} used a Get Out of Jail Free card and is out of jail!")
            return

        # Get out of jail by rolling doubles
        if rolled_doubles:
            self.__jail_status = False
            self.__jail_rolls = 0
            print(f"{self.__name} rolled doubles and is out of jail!")
        else:
            self.__jail_rolls += 1
            print(f"{self.__name} failed to roll doubles. Jail turns: {self.__jail_rolls}")
#to here

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

        if self.__board_position == 10 and not self.__jail_status:
            print(f"{self.__name} is visiting Jail.")



    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name
# added by fatima,from here
    @property
    def token(self):
        return self.__token
# to here
    @property
    def position(self):
        return self.__board_position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]