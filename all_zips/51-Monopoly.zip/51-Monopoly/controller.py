import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import time

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        #player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1, dice2 = random.randint(1, 6), random.randint(1, 6)
        total = dice1 + dice2
        current_player = self.players[self.current_player_index]

        if self.is_in_jail(current_player):
            self.handle_jail_roll(current_player, dice1, dice2)
        else:
            if dice1 == dice2:
                self.doubles_count[current_player] += 1
                if self.doubles_count[current_player] == 3:
                    self.send_to_jail(current_player)
                    return
            else:
                self.doubles_count[current_player] = 0

            self.move_player(current_player, total)

        self.update_player_info()
        self.log_action(f"{current_player} rolled {dice1} and {dice2} (Total: {total})")

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    def is_in_jail(self, player):
        return self.jail_data[player] > 0

    def handle_jail_roll(self, player, dice1, dice2):
        if self.player_stats[player]["get_out_of_jail_card"] > 0:
            self.player_stats[player]["get_out_of_jail_card"] -= 1
            self.jail_data[player] = 0
            self.log_action(f"{player} used a Get Out of Jail Free card!")
        elif dice1 == dice2:
            self.jail_data[player] = 0
            self.log_action(f"{player} rolled doubles and is free from jail!")
        else:
            self.jail_data[player] += 1
            if self.jail_data[player] >= 3:
                self.jail_data[player] = 0
                self.log_action(f"{player} served 3 turns in jail and is released!")

    def send_to_jail(self, player):
        self.jail_data[player] = 1
        self.log_action(f"{player} goes to jail!")

    def can_build_house(self, player, property_name):
        color_group = self.get_property_color_group(property_name)
        owned_properties = [p for p in self.player_stats[player]["properties"] if
                            self.get_property_color_group(p) == color_group]
        return len(owned_properties) == self.get_color_group_size(color_group)

    def build_house(self, player, property_name):
        if self.can_build_house(player, property_name):
            self.player_stats[player]["houses"][property_name] = self.player_stats[player]["houses"].get(property_name,
                                                                                                         0) + 1
            self.player_stats[player]["money"] -= self.get_house_cost(property_name)
            self.log_action(f"{player} built a house on {property_name}")

    def sell_house(self, player, property_name):
        if self.player_stats[player]["houses"].get(property_name, 0) > 0:
            self.player_stats[player]["money"] += self.get_house_cost(property_name) // 2
            self.player_stats[player]["houses"][property_name] -= 1
            self.log_action(f"{player} sold a house on {property_name}")

    def charge_double_rent(self, player, property_name):
        if self.can_build_house(player, property_name) and self.player_stats[player]["houses"].get(property_name,
                                                                                                   0) == 0:
            rent = self.get_rent(property_name) * 2
            self.player_stats[player]["money"] -= rent
            self.log_action(f"{player} paid double rent for {property_name}: ${rent}")

    def trade_property(self, from_player, to_player, property_name):
        if property_name in self.player_stats[from_player]["properties"]:
            self.player_stats[from_player]["properties"].remove(property_name)
            self.player_stats[to_player]["properties"].append(property_name)
            self.log_action(f"{from_player} traded {property_name} to {to_player}")

    def start_turn_timer(self, player):
        start_time = time.time()
        turn_time_limit = 60  # 60 seconds per turn
        while time.time() - start_time < turn_time_limit:
            # Wait for player input or move
            pass
        self.log_action(f"{player} took too long to make a move and is automatically skipped.")

    def animate_dice(self, dice1, dice2):
        for _ in range(10):
            self.dice_label.config(text=f"🎲 {random.randint(1, 6)} 🎲 {random.randint(1, 6)}")
            self.root.update()
            self.root.after(100)
        self.dice_label.config(text=f"🎲 {dice1} 🎲 {dice2}")

    def draw_card(self):
        cards = ["Advance to Go", "Bank error in your favor", "Pay hospital fees", "Get Out of Jail Free"]
        card = random.choice(cards)
        self.log_action(f"Card Drawn: {card}")

    def choose_token(self, player, token):
        self.tokens = []
        available_tokens = ['Car', 'Hat', 'Dog', 'Ship', 'Thimble', 'Boot']

        for i in range(4):  # Assuming 4 players for simplicity
            print(f"Available tokens: {', '.join(available_tokens)}")
            token = input(f"Player {i + 1}, choose your token: ")

            while token not in available_tokens:
                print("Invalid token. Please choose a valid one.")
                token = input(f"Player {i + 1}, choose your token: ")

            self.tokens.append(token)
            available_tokens.remove(token)

        print(f"Players have chosen tokens: {', '.join(self.tokens)}")
    def move_player(self, player, steps):
        current_token = self.player_stats[player]["token"]
        # Update player position on the board
        self.log_action(f"{player} moves {steps} steps. Token: {current_token}")

    def auction_property(self, property_name):
        highest_bidder = None
        highest_bid = 0
        while True:
            for player in self.players:
                bid = int(input(f"{player}, enter your bid for {property_name} (or 0 to pass): "))
                if bid > highest_bid:
                    highest_bid = bid
                    highest_bidder = player
            if highest_bidder:
                self.player_stats[highest_bidder]["money"] -= highest_bid
                self.player_stats[highest_bidder]["properties"].append(property_name)
                self.log_action(f"{highest_bidder} wins the auction for {property_name} with a bid of ${highest_bid}.")

    def get_out_of_jail_choice(self, player):
        choice = input(f"{player}, you are in jail. Do you want to use your 'Get Out of Jail Free' card? (yes/no): ")

        if choice.lower() == 'yes' and self.player_stats[player]["get_out_of_jail_card"] > 0:
            self.player_stats[player]["get_out_of_jail_card"] -= 1
            self.jail_data[player] = 0
            print(f"{player} used a Get Out of Jail Free card!")
        elif choice.lower() == 'no':
            money_choice = input(f"Do you want to pay $50 to get out of jail? (yes/no): ")
            if money_choice.lower() == 'yes' and self.player_stats[player]["money"] >= 50:
                self.player_stats[player]["money"] -= 50
                self.jail_data[player] = 0
                print(f"{player} paid $50 and is now out of jail.")
            else:
                print(f"{player} doesn't have enough money or declined to pay.")
        else:
            print("Invalid choice, please type 'yes' or 'no'.")



