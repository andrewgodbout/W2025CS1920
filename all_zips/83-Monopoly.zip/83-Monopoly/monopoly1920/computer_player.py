import random
from player import Player


class ComputerPlayer(Player):
    """A simple AI-controlled player that follows basic strategies."""

    def __init__(self, name="AI_Player", money=1500):
        super().__init__(name, money)

    def decide_to_buy(self, board_property):
        """Simple decision to buy a property if affordable."""
        return self.money >= board_property.price

    def move(self, dice_roll):
        """Move the AI player based on dice roll."""
        self.__board_position = (self.__board_position + dice_roll) % 40  # Assuming a 40-space board

    def take_turn(self, game_board):
        """Simulate a simple AI turn."""
        dice_roll = random.randint(1, 6) + random.randint(1, 6)  # Rolling two dice
        self.move(dice_roll)

        current_square = game_board.get_square(self.__board_position)
        if current_square.is_property() and not current_square.is_owned():
            if self.decide_to_buy(current_square):
                self.buy_property(current_square)
                print(f"{self.__name} bought {current_square.name}")
        else:
            print(f"{self.__name} landed on {current_square.name} but didn't buy anything.")
