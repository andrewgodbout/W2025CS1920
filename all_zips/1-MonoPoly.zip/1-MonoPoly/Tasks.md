# Task Ideas

- [x] Improve UI
    - [x] Replace text-boxes with proper info displays
        - [x] More clear indication of turn
    - [x] Display player icons on board
- [x] Save & Load
    - [x] Dialog
    - [x] Actual save load
- [ ] Menu
    - [ ] Main Menu
    - [ ] House Rules?
    - [ ] Online Multiplayer? (Unlikely)

# Time

- Task Idea planning (approx 25 minutes)
- Start Of Player info panel (MR/25/2025) (approx 30 mins)
- Dict instead of str + player card lables (approx 45 mins)
- Display Player position (approx 10 minutes)
- Display images ontop of board (preperation for player pieces) + UI reorganization (approx 1hr)
- Get player icons (aprox 25 minutes)
- Current player highlight (approx 15 mins)
- Remove Piece backgrounds (approx 10 mins)
- Load Piece images (approx 15 minutes)
- Display player pieces (approx 1h15)
- Pin Placer Start (approx 1h15)
- Jail (approx 1hr)
- Save Load Dialog (approx 1h30)
- Save + load (approx 1hr)
