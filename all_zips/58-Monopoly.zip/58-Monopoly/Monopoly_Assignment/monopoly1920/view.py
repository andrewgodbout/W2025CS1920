import tkinter as tk
import os
from tkinter import ttk
import controller
import observer
import player


def get_board_square_images():
    """Return a list of all file paths for board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images


class View(observer.Observer):
    """Main GUI class for Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        self.images = []
        self.root = root
        self.player_frames = []
        self._player_setup_done = False  # Track if setup was completed
        self.observe("request_player_setup", self.handle_player_setup)
        root.title("Monopoly 1920")
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        # Then set up UI
        self.main_frame = ttk.Frame(root, padding=10, relief='groove')
        self._create_ui_components()
        self._add_listeners()

        self._init_controller()

    def _init_controller(self):
        """Initialize controller after view is ready"""
        self.controller = controller.Controller(self.root)
        self.controller.set_view(self)

    def _create_ui_components(self):
        """Create and arrange all UI components"""
        # Logo frame (top)
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.image = logo_image
        logo.pack(side='top', anchor='n')

        # Middle frame (game board and controls)
        middle_frame = self._create_middle_frame()

        # Message frame (bottom)
        msg_frame = self._create_msg_frame()

        # Pack all frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

    def _create_middle_frame(self):
        """Create the central game area with board and controls"""
        frame = ttk.Frame(self.main_frame, padding=10)

        # Game board display
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # Preload property images
        self._preload_images()

        # Property card display
        card_image = self.images[0]
        self.card = ttk.Label(frame, image=card_image)
        self.card.image = card_image

        # Control buttons panel
        button_frame = ttk.Frame(frame, padding=10)
        self._create_control_buttons(button_frame)

        # Layout components
        board.pack(side='left', anchor='n', padx=75)
        button_frame.pack(side='left', anchor='center', padx=50)
        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))

        return frame

    def _create_control_buttons(self, parent_frame):
        """Create all game control buttons"""
        # Timer display
        self.timer_label = ttk.Label(
            parent_frame,
            text="Time: --",
            font=('Helvetica', 12, 'bold'),
            foreground='black'
        )
        self.timer_label.pack(side='top', pady=(0, 15))

        # Game action buttons
        button_configs = [
            ("Roll Dice", "roll"),
            ("Purchase", "purchase"),
            ("Mortgage", "mortgage"),
            ("Unmortgage", "unmortgage"),
            ("Go Bankrupt", "bankrupt"),
            ("End Turn", "end_turn"),
            ("Restart Game", "restart") # new button
        ]

        self.buttons = {}
        for text, action in button_configs:
            btn = ttk.Button(
                parent_frame,
                text=text,
                command=lambda a=action: self._action_taken(a),
                width=15
            )
            btn.pack(side='top', pady=5)
            self.buttons[action] = btn

    def _create_msg_frame(self):
        """Create the message display area"""
        frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        # Game state display
        self.state_box = tk.Text(
            frame,
            width=60,
            height=10,
            background='black',
            foreground='white',
            font=('Courier', 10)
        )
        self.state_box.pack(side='left', padx=(100, 30))

        # Game message log
        self.text_box = tk.Text(
            frame,
            width=60,
            height=10,
            background='black',
            foreground='white',
            font=('Courier', 10)
        )
        self.text_box.pack(side='left', padx=(30, 100))

        return frame

    def _add_listeners(self):
        """Set up all event listeners"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        self.observe("update_timer", self.update_timer)
        self.observe("show_timeout_warning", self.show_timeout_warning)

    def _preload_images(self):
        """Load all property card images"""
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def handle_player_setup(self, data):
        """Handle player setup request"""
        # Remove the "only run once" check completely
        num_players = data.get("num_players", 2)
        player_data = self._collect_player_details(num_players)
        observer.Event("player_setup_complete", {"players": player_data})
        self._player_setup_done = True  # Still track completion but don't block

    def reset_view(self):
        """More complete view reset"""
        # Clear displays
        for frame in self.player_frames:
            frame.destroy()
        self.player_frames = []

        # Reset UI elements
        self._clear_text()
        self.state_box.delete(1.0, tk.END)
        self.update_card({"index": 0})
        self.timer_label.config(text="Time: --")

        # Reset flags
        self._player_setup_done = False

    def _collect_player_details(self, num_players):
        """Dialog to collect player names and tokens"""
        available_tokens = player.Player.TOKENS.copy()
        players = []

        for i in range(1, num_players + 1):
            dialog = tk.Toplevel(self.root)
            dialog.title(f"Player {i} Setup")
            dialog.resizable(False, False)

            # Create a dictionary to store the player data before the dialog is destroyed
            player_data = {}

            # Name Entry
            tk.Label(dialog, text="Name:").grid(row=0, column=0, padx=5, pady=5)
            name_entry = tk.Entry(dialog)
            name_entry.grid(row=0, column=1, padx=5, pady=5)
            name_entry.insert(0, f"Player {i}")

            # Token Selection
            tk.Label(dialog, text="Token:").grid(row=1, column=0, padx=5, pady=5)
            token_var = tk.StringVar(value=available_tokens[0])
            token_menu = tk.OptionMenu(dialog, token_var, *available_tokens)
            token_menu.grid(row=1, column=1, padx=5, pady=5)

            # Confirmation button - use a lambda to capture the current values
            confirm_button = tk.Button(
                dialog,
                text="Confirm",
                command=lambda ne=name_entry, tv=token_var: [
                    player_data.update({
                        "name": ne.get() or f"Player {i}",
                        "token": tv.get(),
                        "money": 1500
                    }),
                    dialog.destroy()
                ]
            )
            confirm_button.grid(row=2, columnspan=2, pady=10)

            dialog.wait_window()

            # Now append the collected data
            players.append(player_data)
            available_tokens.remove(player_data["token"])

        return players

    def update_player_displays(self, data):
        """Update UI with player information"""
        # Clear previous displays
        for frame in self.player_frames:
            frame.destroy()
        self.player_frames = []

        # Create player info panels
        player_area = ttk.Frame(self.main_frame)
        player_area.pack(side='top', fill='x', padx=10, pady=5)

        for i, player in enumerate(data["players"]):
            frame = ttk.Frame(player_area, relief='groove', padding=5)
            frame.pack(side='left', expand=True, fill='both', padx=2)
            self.player_frames.append(frame)

            # Token and name
            tk.Label(frame, text=player["token"], font=('Arial', 16)).pack(side='left', padx=5)
            tk.Label(frame, text=player["name"], font=('Arial', 12)).pack(side='left', padx=5)

            # Money
            tk.Label(frame, text=f"${player['money']}", font=('Arial', 12, 'bold'),
                     foreground='green').pack(side='right', padx=5)

            # Current player highlight
            if data.get("current_player") == i:
                frame.config(relief='raised', borderwidth=2)
                for child in frame.winfo_children():
                    child.config(font=('Arial', 12, 'bold'))

    def _action_taken(self, action):
        """Handle button actions"""
        if action == "roll":
            observer.Event("roll", None)
        elif action == "purchase":
            observer.Event("purchase", None)
        elif action == "mortgage":
            observer.Event("mortgage", None)
        elif action == "unmortgage":
            observer.Event("unmortgage", None)
        elif action == "bankrupt":
            observer.Event("bankrupt", None)
        elif action == "end_turn":
            observer.Event("end_turn", self._clear_text)
        elif action == "restart":
            observer.Event("restart_game", None)

    def update_timer(self, data):
        """Update the timer display with dictionary data"""
        if isinstance(data, dict):
            seconds = data.get("seconds")
            if isinstance(seconds, int):
                if seconds <= 10:
                    self.timer_label.config(text=f"Time: {seconds}s", foreground='red')
                else:
                    self.timer_label.config(text=f"Time: {seconds}s", foreground='black')
            else:
                self.timer_label.config(text=f"Time: {seconds}", foreground='black')

    def show_timeout_warning(self,_=None):
        """Display timeout warning"""
        self.timer_label.config(text="TIME'S UP!", foreground='red')
        self.root.bell()  # System beep sound

    def update_state_box(self, data):
        """Update the game state display with dictionary data"""
        if isinstance(data, dict):
            text = data.get("text", "")
        else:
            text = str(data)
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def update_card(self, data):
        """Update the property card display with dictionary data"""
        if isinstance(data, dict):
            index = data.get("index", 0)
        else:
            index = int(data) if str(data).isdigit() else 0

        if 0 <= index < len(self.images):
            self.card.config(image=self.images[index])
            self.card.image = self.images[index]

    def _update_text(self, data):
        """Add text to the message log with dictionary data"""
        if isinstance(data, dict):
            text = data.get("text", "")
        else:
            text = str(data)
        self.text_box.insert(tk.END, text + "\n")
        self.text_box.see(tk.END)

    def _clear_text(self):
        """Clear the message log"""
        self.text_box.delete(1.0, tk.END)

    def _choose(self, data):
        """Show choice popup menu with dictionary data"""
        if isinstance(data, dict):
            choices = data.get("choices", [])
        else:
            choices = list(data) if hasattr(data, '__iter__') else []

        self.popup_menu = tk.Menu(self.root, tearoff=0)

        for choice in choices:
            self.popup_menu.add_command(
                label=choice,
                command=lambda c=choice: self.pick(c)
            )

        self.popup_menu.add_separator()
        cancel_label = "Cancel" if choices else "No options (click to cancel)"
        self.popup_menu.add_command(
            label=cancel_label,
            command=self.popup_menu.grab_release
        )

        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()
    @staticmethod
    def pick(choice):
        """Handle menu choice selection"""
        observer.Event("mortgage_specific", choice)




if __name__ == '__main__':
    root = tk.Tk()
    view = View(root)
    root.mainloop()

