import gameboard
import gamesquare
import observer



class Player:
    """Player class to represent a player in the game"""
    TOKENS = ["🚗 Car", "🐶 Dog", "🎩 Hat", "🚢 Ship", "🐱 Cat", "👞 Shoe"]  # Emoji make it fun!

    def __init__(self, name, money, token=None):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__token = token if token else self._assign_token()
        self.__board_position = 0
        # For tracking triple doubles
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__in_jail = False
        self.__jail_turns = 0
        self.__jail_free_cards = 0


        #big numbers are lucky, negative numbers are unlucky
        self.__luck = 0

        #add a Data structure to track mortgaging order
        self.__mortgaging_order = []

    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def _assign_token(self):
        """Auto-assign token based on player count"""
        return self.TOKENS[len(observer.Observer.get_observers()) % len(self.TOKENS)]

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name

    def go_to_jail(self):
        """Send player to jail"""
        self.__board_position = 10
        self.__in_jail = True
        self.__jail_turns = 0
        self.reset_doubles_count()

    def process_jail_turn(self, dice1, dice2, use_card=False, pay_bail=False):
        """
        Enhanced with payment options and bankruptcy checks
        Returns tuple: (released, reason)
        """
        if not self.__in_jail:
            return False, "not_in_jail"

        # Option 1: Use Get Out of Jail Free card
        if use_card and self.__jail_free_cards > 0:
            self.__jail_free_cards -= 1
            self.__in_jail = False
            return True, "used_card"

        # Option 2: Pay $50 bail
        if pay_bail:
            if self.__money >= 50:
                self.__money -= 50
                self.__in_jail = False
                return True, "paid_bail"
            else:
                self.declare_bankrupt()
                return True, "bankrupt"

        # Option 3: Roll doubles
        if dice1 == dice2:
            self.__in_jail = False
            self.move(dice1 + dice2)
            return True, "rolled_doubles"

        # Increment turn counter (only after roll attempt)
        self.__jail_turns += 1

        # Option 4: Forced release after 3 turns
        if self.__jail_turns >= 3:
            if self.__money >= 50:
                self.__money -= 50
                self.__in_jail = False
                return True, "forced_release"
            else:
                self.declare_bankrupt()
                return True, "bankrupt"

        return False, "still_in_jail"

    def add_get_out_of_jail_free_card(self):
        self.__jail_free_cards += 1


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    def reset(self):
        """Reset player to initial state"""
        self.__money = 1500
        self.__properties = []
        self.__board_position = 0  # Reset position to GO (0)
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0
        self.__in_jail = False
        self.__jail_turns = 0
        self.__jail_free_cards = 0
        self.__luck = 0
        self.__mortgaging_order = []

    @property
    def doubles_count(self):
        return self.__doubles_count



    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @property
    def position(self):
        return self.__board_position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]

    @property
    def token(self):
        return self.__token

    @property
    def in_jail(self):
        return self.__in_jail

    @property
    def jail_turns(self):
        return self.__jail_turns

    @jail_turns.setter
    def jail_turns(self, value):
        self.__jail_turns = value

    @property
    def jail_free_cards(self):
        return self.__jail_free_cards

    @jail_free_cards.setter
    def jail_free_cards(self, value):
        self.__jail_free_cards = value

    @doubles_count.setter
    def doubles_count(self, value):
        """Set the doubles count with validation"""
        if not isinstance(value, int):
            raise ValueError("Doubles count must be an integer")
        self.__doubles_count = max(0, value)  # Ensure it's never negative

