import os
import random
import gameboard
import player as plr
import gamesquare
import observer


class Controller(observer.Observer):
    """Control the game flow with timer implementation"""

    def __init__(self, root):
        super().__init__()
        self.root = root
        self._view = None # Will be set after View is created
        self._players = []
        self._gameboard = None
        self.__game_ready = False

        # Game state variables
        self.__dice_rolled = False
        self.__roll_count = 0

        # Timer variables
        self.timer = None
        self.time_left = 30  # 30-second timer
        self.timer_running = False

        # Set up event listeners
        self._add_listeners()
    # REMOVED the game state initialization from here
    # It will be handled after player setup completes
        self.__was_in_jail = False  # Track jail state between turns
        self.__current_player_index = 0  # Explicit turn tracking

    def set_view(self, view):
        """Set the view reference after initialization"""
        self._view = view
        view.reset_view()
        self._init_player_setup()
    @staticmethod
    def _init_player_setup():
        """Start player setup process"""
        observer.Event("show_loading", {"message": "Setting up players..."})
        observer.Event("request_player_setup", {"num_players": 3})  # Default to 3 players

    def _add_listeners(self):
        """Add listeners for all game events"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("bankrupt", self._handle_bankruptcy)
        self.observe("player_setup_complete", self.handle_player_setup_complete)
        self.observe("restart_game", self._restart_game)

    def handle_player_setup_complete(self, data):
        """Handle completed player setup"""
        self._players = [plr.Player(p["name"], 1500, p["token"]) for p in data["players"]]
        csv_path = os.path.join("resources", "data", "board.csv")
        self._gameboard = gameboard.GameBoard(csv_path, self._players)
        self.__game_ready = True

        observer.Event("update_state_box", {"text": str(self._gameboard)})
        self._set_expected_val()

    def _set_expected_val(self):
        """Calculate and display expected value for current position"""
        player = self._gameboard.get_current_player()
        ev = self._gameboard.calculate_expected_value(player.position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", {"text": f"Expected value: {ev}"})
        player.luck += ev

    def _roll_dice(self):
        """Simulate dice roll and return sum"""
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            observer.Event("update_state", {"text": f"Doubles rolled: {dice1}+{dice2} = {dice_sum}"})
            self.__dice_rolled = False  # Allow another roll for doubles
        else:
            observer.Event("update_state", {"text": f"Dice rolled: {dice1} + {dice2} = {dice_sum}"})

        return dice_sum

    # Timer Methods
    def _start_timer(self, duration=30):
        """Start timer with validation and jail awareness"""
        if not self.__game_ready or not self._gameboard:
            return

        current_player = self._gameboard.get_current_player()

        # Don't start timer if player is in jail and has options
        if current_player.in_jail and (current_player.jail_free_cards > 0 or current_player.money >= 50):
            return

        if self.timer_running:
            self._cancel_timer()

        self.time_left = duration
        self.timer_running = True
        observer.Event("update_timer", {"seconds": self.time_left})
        self.timer = self.root.after(1000, self._update_timer)

    def _update_timer(self):
        """Handle each timer tick with visual feedback"""
        if not self.timer_running:  # Emergency stop
            return

        self.time_left -= 1
        observer.Event("update_timer", {"seconds": self.time_left})

        # Visual warning at 10 seconds
        if self.time_left == 10:
            self.root.bell()  # System beep
            observer.Event("update_state", {"text": "10 seconds remaining!"})

        # Handle timeout
        if self.time_left <= 0:
            self._handle_timeout()
        else:
            self.timer = self.root.after(1000, self._update_timer)

    def _handle_timeout(self):
        """Handle timer expiration more gracefully"""
        self.timer_running = False
        current_player = self._gameboard.get_current_player()

        observer.Event("show_timeout_warning", {})
        observer.Event("update_state", {
            "text": f"Time's up! {current_player.name}'s turn ended automatically"
        })

        # Force end turn without callback dependency
        self.__dice_rolled = True  # Satisfy turn-end requirement
        self._end_player_turn(lambda: None)

    def _cancel_timer(self):
        """Cancel the running timer"""
        if self.timer:
            self.root.after_cancel(self.timer)
        self.timer_running = False
        observer.Event("update_timer", {"seconds": "--"})

    # Game Action Handlers
    def _handle_roll_dice(self):
        """Handle dice rolling logic"""
        if self._gameboard is None:  # Add this check
            return False

        if self.__dice_rolled:
            observer.Event("update_state", {"text": "One roll per turn or Doubles required"})
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        player.move(dice_sum)

        # Handle property landing
        position = player.position
        square = self._gameboard.get_square(position)
        rent = player.pay_rent(square, dice_sum)

        if rent != 0:
            player.luck -= rent
            observer.Event("update_state", {"text": f"Rent paid: {rent}"})

        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _roll_action(self, _=None):
        if self._gameboard is None:
            observer.Event("update_state", {"text": "Game not ready - please wait"})
            return

        # Handle jail cases first (no timer if player has jail options)
        if self._handle_jail_turn():
            return

        # Start timer on first roll if not already running
        if not self.timer_running and not self.__dice_rolled:
            self._start_timer()

        if not self._handle_roll_dice():
            return

        # Rest of the roll logic...
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)
        observer.Event("update_state", {"text": f"{player.name} landed on {square}."})
        observer.Event("update_state_box", {"text": str(self._gameboard)})
        observer.Event("update_card", {"index": player.position})

    def _end_player_turn(self, callback):
        self._cancel_timer()

        if not self.__dice_rolled and not self._gameboard.get_current_player().in_jail:
            observer.Event("update_state", {"text": "Roll the dice first"})
            return

        self.__was_in_jail = self._gameboard.get_current_player().in_jail
        self.__dice_rolled = False
        self.__roll_count = 0

        # Move to next player
        player_name = self._gameboard.next_turn()

        # Update UI
        observer.Event("update_state_box", {"text": str(self._gameboard)})
        observer.Event("update_card", {"index": self._gameboard.get_current_player().position})

        # Only start timer if not in jail with options
        if not self._handle_jail_turn():
            # Timer will start on first roll (not here)
            pass

        callback()
        observer.Event("update_state", {"text": f"{player_name}'s turn"})
        self._set_expected_val()
    def _handle_jail_turn(self):
        """Special handling for jail turns"""
        player = self._gameboard.get_current_player()

        if not player.in_jail:
            return False

        # Player has options (card or bail)
        if player.jail_free_cards > 0 or player.money >= 50:
            observer.Event("update_state", {
                "text": f"{player.name} in jail. Use card or pay $50?"
            })
            self._cancel_timer()  # Pause timer for decision
            return True

        # No options - must roll
        return False

    def _buy_square(self, _):
        """Handle property purchase attempt"""
        if self.__roll_count == 0:
            observer.Event("update_state", {"text": "Roll the dice first"})
            return
        self._cancel_timer()  # Decision made, stop timer
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)

        if player.buy_property(square):
            observer.Event("update_state", {"text": f"Purchased: {square.name}"})
            self._cancel_timer()  # Decision made, cancel timer
        else:
            observer.Event("update_state", {"text": f"Could not purchase: {square.name}"})

        observer.Event("update_state_box", {"text": str(self._gameboard)})

    def _mortgage(self,_):
        """Handle mortgage action initiation"""
        player = self._gameboard.get_current_player()
        available_properties = [p for p in player.properties if not p.is_mortgaged]

        if available_properties:
            observer.Event("choice", {"choices": [p.name for p in available_properties]})
            self._cancel_timer()  # Decision in progress, cancel timer
        else:
            observer.Event("update_state", {"text": "No properties to mortgage"})

        observer.Event("update_state_box", {"text": str(self._gameboard)})

    def _mortgage_specific(self, data):
        """Handle specific property mortgage"""
        property_name = data
        player = self._gameboard.get_current_player()
        if player.mortgage_property(property_name):
            observer.Event("update_state", {"text": f"Mortgaged: {property_name}"})
        else:
            observer.Event("update_state", {"text": f"Failed to mortgage: {property_name}"})

        observer.Event("update_state_box", {"text": str(self._gameboard)})

    def _unmortgage(self, _):
        """Handle unmortgage action"""
        player = self._gameboard.get_current_player()
        property_name = player.unmortgage_property()

        if property_name:
            observer.Event("update_state", {"text": f"Unmortgaged: {property_name}"})
            self._cancel_timer()  # Decision made, cancel timer
        else:
            observer.Event("update_state", {"text": "No properties to unmortgage"})

        observer.Event("update_state_box", {"text": str(self._gameboard)})

    def _handle_bankruptcy(self, _=None):
        """Handle player bankruptcy"""
        player = self._gameboard.get_current_player()
        player.declare_bankrupt()
        observer.Event("update_state", {"text": f"{player.name} declared bankruptcy!"})
        self._end_player_turn(lambda: None)

    def button_clicked(self, button):
        """Handle direct button clicks (legacy support)"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _restart_game(self, _=None):
        """Reset the game to its initial state"""
        # Cancel any running timer
        self._cancel_timer()

        # Reset game state variables
        self.__game_ready = False
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__was_in_jail = False

        # Reset players and their positions
        for player in self._players:
            player.reset()  # This will reset position to 0

        # Reset gameboard
        if self._gameboard:
            self._gameboard.reset(self._players)

        # Reset view state
        if self._view:
            self._view.reset_view()

        # Update UI
        observer.Event("update_timer", {"seconds": "--"})
        observer.Event("update_state_box", {"text": "Game restarted. Setting up new game..."})
        observer.Event("update_state", {"text": ""})
        observer.Event("update_card", {"index": 0})  # Show GO card

        # Reinitialize player setup
        self._init_player_setup()
