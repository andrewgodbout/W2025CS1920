import os

import player
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
from gameboard import GameBoard


class Controller(observer.Observer):
    """Control the game flow"""
    drawn_chance = []
    drawn_community = []
    def __init__(self, root):
        with open("game log.txt", "w") as file:
            file.write("")
        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        chest_path = os.path.join("resources", "data", "community_chest.csv")


        while True:
            try:
                player_amount = int(input(f"How many players (max 4)? "))

                if 2 <= player_amount <= 4:
                    print(f"Number of players is {player_amount}.")
                    break
                else:
                    print(f"Please enter a number between 1 and 4.")

            except ValueError:
                print("Invalid! Please enter a number.")

        players = self._create_players(player_amount)
        self._gameboard = gameboard.GameBoard(csv_path, chest_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("pay_fine", self._pay_fine)
        self.observe("save_game", self._save_game)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        names = []
        for i in range(num_players):
            while True:
                name = input(f"Player {i+1}, please enter your name: ")
                if name in names:
                    print("This name is taken. Please choose a different name.")
                else:
                    names.append(name)
                    player = plr.Player(f"{name}", 1500)
                    players.append(player)
                    break
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        player = self._gameboard.get_current_player()
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1!=dice2 and player.in_jail:             # If player in JAIL and rolls DOUBLES, leave jail
            observer.Event("update_state", f"Doubles not rolled({dice1} & {dice2}): {player.name} stays in jail")
            return 0

        if dice1==dice2 and self.__roll_count == 3:     # GO TO JAIL if doubles rolled 3 times in a row
            observer.Event("update_state", f"{player.name} rolled doubles 3 times.")
            player.go_to_jail()
            return 0

        elif dice1==dice2 and player.in_jail:
            observer.Event("update_state", f"Doubles rolled: {player.name} leaves jail")
            player.leave_jail()
            return dice_sum

        elif dice1==dice2 and player.position + dice_sum == 30:     # GO TO JAIL if player lands on GO TO JAIL
            observer.Event("update_state", f"Landed on 'Go to Jail'")
            player.go_to_jail()
            return 0

        elif dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")

            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

                #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            if square.owner:
                observer.Event("update_state", f"Rent paid to {square.owner.name}: {rent}")
            else:
                observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        player = self._gameboard.get_current_player()

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return

        if player.in_jail:
            if player.jail_time == 3:
                observer.Event("update_state", f"Final turn in jail. {player.name} must Pay Fine or Go Bankrupt.")
                return False
            else:
                player.jail_time += 1



        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")


        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "Player must end turn")
            return False

        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        if self.__dice_rolled and player.in_jail:
            #only one roll per turn
            observer.Event("update_state", "Player must end turn")
            return False
        res = player.mortgage_property(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")

        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "Player must end turn")
            return False
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _pay_fine(self, data):
        player = self._gameboard.get_current_player()

        # this will let player out of jail if 3rd turn in their and they didn't roll doubles
        if self.__dice_rolled and player.jail_time == 3 and player.jail_cards < 1:
            player.money -= 50
            observer.Event("update_state", f"{player.name} paid $50 fine to leave Jail")
            observer.Event("update_state_box", str(self._gameboard))
            player.leave_jail()
            return

        elif player.in_jail and player.jail_time == 3 and player.jail_cards >= 1:
            observer.Event("update_state", f"{player.name} used a Get Out of Jail Free Card")
            observer.Event("update_state_box", str(self._gameboard))
            player.jail_cards -= 1
            player.leave_jail()
            return

        elif self.__dice_rolled and player.jail_time !=1:
            #only one roll per turn
            observer.Event("update_state", "Player can't leave Jail")
            return False

        if player.in_jail and player.jail_cards >= 1:
            observer.Event("update_state", f"{player.name} used a Get Out of Jail Free Card")
            observer.Event("update_state_box", str(self._gameboard))
            player.jail_cards -= 1
            player.leave_jail()
            return
        elif player.in_jail and player.money >= 50:
            player.money -= 50
            observer.Event("update_state", f"{player.name} paid $50 fine to leave Jail")
            observer.Event("update_state_box", str(self._gameboard))
            player.leave_jail()
            return
        elif player.in_jail and player.money < 50:
            observer.Event("update_state", f"{player.name} does not have enough money to pay fine.")
            return False
        else:
            observer.Event("update_state", f"{player.name} is not in Jail")
            return False

    #### NOT WORKING
    def _save_game(self, data):
        game_name = input("Enter save file name: ")
        player = self._gameboard.get_current_player()
        with open(f"{game_name}.txt", "w") as file:
            properties = []
            for i in player.properties:
                properties.append(i)
            file.write(f"Name: {player.name}\nProperties: {properties}\nBoard Position: {player.position}\nDoubles Count: {player.doubles_count}\nDeclared Bankrupt: {player.bankrupt_declared}\nUtility Count: {player.utility_count}\nRailroad Count: {player.railroad_count}\nJail: {player.jail}\nJail Time: {player.jail_time}\n\n")

    def community_chest(self):
        player = self._gameboard.get_current_player()

        card_num = random.randint(0, 13)

        # Checks if that card has been drawn. If it has, go to different card
        while card_num in Controller.drawn_community:
             card_num = random.randint(0, 13)

        # Add the card to the drawn list
        Controller.drawn_community.append(card_num)

        # If the drawn list is len(14), all cards have been drawn. Empty list, essentially reshuffling the deck
        if len(Controller.drawn_community) == 14:
            Controller.drawn_community = []
        card = self._gameboard.get_chance_chest(card_num)

        if card_num == 5:   # Go To Jail
            self.__dice_rolled = True
            player.go_to_jail()
            return

        elif card_num == 4: # Get out of Jail Free card
            player.jail_cards += 1
            observer.Event("update_state", f"{card[1]}")
            return

        else:               # Increases or decreases players money
            player.money += int(card[2])
            observer.Event("update_state", f"{player.name}: {card[1]}")
            return

    def chance(self):
        player = self._gameboard.get_current_player()

        card_num = random.randint(14, 27)

        # Checks if that card has been drawn. If it has, go to different card
        while card_num in Controller.drawn_chance:
             card_num = random.randint(14, 27)

        # Add the card to the drawn list
        Controller.drawn_chance.append(card_num)

        # If the drawn list is len(14), all cards have been drawn. Empty list, essentially reshuffling the deck

        if len(Controller.drawn_chance) == 14:
            Controller.drawn_chance = []
        card = self._gameboard.get_chance_chest(card_num)
        observer.Event("update_state", f"{card[1]}")
        if card[3] == "move":   # if it is a card that moves the player
            if card_num == 23:          # go to jail
                self.__dice_rolled = True
                player.go_to_jail()
                return

            elif card_num == 14:          #boardwalk
                move = 39 - player.position
                player.position += move
                square = self._gameboard.get_square(player.position)
                if square.owner != None:
                    player.pay_rent(self._gameboard.get_square(player.position), 0)
                return

            elif card_num == 15:        # go to Go
                move = 0 - player.position
                player.position += move
                player.money += 200
                return

            elif card_num == 16:        # illinoise
                if player.position > 24:
                    player.money += 200
                move = 24 - player.position
                player.position += move
                return

            elif card_num == 17:        # st james
                if player.position > 11:
                    player.money += 200
                move = 11 - player.position
                player.position += move
                return

            elif card_num == 18:                # move to nearest railroad
                if player.position == 7:
                    player.position += 8
                elif player.position == 22:
                    player.position += 3
                else:
                    player.position += 9
                    player.money += 200
                square = self._gameboard.get_square(player.position)

                if square.owner != None:
                    player.pay_rent(self._gameboard.get_square(player.position), 101)
                return

            elif card_num == 19:                # move to nearest utility
                if player.position == 7:
                    player.position += 5
                elif player.position == 22:
                    player.position += 6
                else:
                    player.position += 16
                    player.money += 200
                dice1 = random.randint(1, 6)
                dice2 = random.randint(1, 6)
                dice_sum = dice1 + dice2

                square = self._gameboard.get_square(player.position)

                if square.owner != None:
                    observer.Event("update_state",
                               f"{player.name} rolled {dice1} + {dice2} = {dice_sum}")
                player.pay_rent(self._gameboard.get_square(player.position),dice_sum + 100)
                return

            elif card_num == 22:        # move back 3 spaces
                player.position -= 3
                square = self._gameboard.get_square(player.position)

                if square.owner != None or square.space == "Tax":
                    player.pay_rent(self._gameboard.get_square(player.position),100)
                return

            elif card_num == 25:
                move = 5 - player.position
                player.position += move
                player.money += 200
                square = self._gameboard.get_square(player.position)

                if square.owner != None:
                    player.pay_rent(self._gameboard.get_square(player.position), 0)
                return

        elif card_num == 21: # get out of jail free card
            player.jail_cards += 1
            return

        elif card_num == 26: # pay each player 50 dollars
            for players in player.get_players():
                if players != player:
                    players.money += 50
                    player.money -= 50
            return

        else:   # else it is a card that increases or decreases the players money
            player.money += int(card[2])
            return

        if card_num != (18 or 19):
            player.pay_rent(self._gameboard.get_square(player.position), 0)
            return

    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."
        if player.position == 10 and player.in_jail:
            msg = f"{player.name} is in {square}."

        elif player.position == 10 and not player.in_jail:
            msg = f"{player.name} is Just Visiting {square}."

        observer.Event("update_state", msg)

        if player.position == 2 or player.position == 17 or player.position ==  33:
            self.community_chest()
        elif player.position == 7 or player.position == 22 or player.position == 36:
            self.chance()

        # Next two lines save a gamelog with the update_state log
        with open("game log.txt", "a") as file:
            file.write(f"{msg}\n")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)







