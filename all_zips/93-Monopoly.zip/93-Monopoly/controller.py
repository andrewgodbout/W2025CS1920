import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0
        self.timer_running = False

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("quit_game", self._end_the_game)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """

        dice1, dice2 = random.randint(1, 6), random.randint(1, 6)
        dice_sum = dice1 + dice2

        print(f"Dice roll: {dice1} + {dice2} = {dice_sum}")

        if dice1 == dice2:
            print("Doubles rolled! Another turn allowed.")
            observer.Event("update_state", f"Doubles rolled: {dice1} + {dice2} = {dice_sum}")
            self.__dice_rolled = False  # Allow another roll
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
            self.__dice_rolled = True  # Lock rolling for this turn

        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        print(f"Handling roll dice. Dice rolled: {self.__dice_rolled}, Roll count: {self.__roll_count}")

        if self.__dice_rolled:
            print("ROLL PREVENTED: Already rolled this turn.")
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        # Actually roll the dice now
        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        player.move(dice_sum)
        self.__roll_count +=1
        # Get the square landed on
        square = self._gameboard.get_square(player.position)
        rent = player.pay_rent(square, dice_sum)

        if rent:
            print(f"Rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            print("Player has no money left! Declaring bankruptcy.")
            player.declare_bankrupt()

        # Update UI to reflect new position
        print(f"Updating card for position: {player.position}")
        observer.Event("update_card", player.position)

        # If the player did NOT roll doubles, prevent another roll this turn
        if dice_sum % 2 != 0:
            self.__dice_rolled = True  # Only lock rolling if it wasn't doubles

        return True


    def end_turn(self):
        """End the current player's turn"""
        self.__dice_rolled = False  # Reset the dice roll flag for the next turn
        # Add any other end-turn logic here...

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        print("Ending player turn...")

        if not self._view.timer_running:
            self._view._next_turn()
            callback()
        else:
            self._view.timer_running = False
            self._view._next_turn()
            callback()

        print(f"Checking if roll was done: {self.__dice_rolled}")
        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return

        # Reset rolling permission for the next player
        self.__dice_rolled = False
        self.__roll_count = 0

        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)

        # Announce next turn
        player_name = self._gameboard.next_turn()
        observer.Event("update_state", f"{player_name}'s turn")
        self._set_expected_val()


    def _end_the_game(self, callback):

        """End the game and stop the timer"""
        self._view._stop_timer()  # Stop the timer and display "Game Over"

        # Disable buttons
        self._view.roll_button.config(state="disabled")
        self._view.purchase_button.config(state="disabled")
        self._view.mortgage_button.config(state="disabled")
        self._view.unmortgage_button.config(state="disabled")
        self._view.bankrupt_button.config(state="disabled")
        self._view.end_turn_button.config(state="disabled")
        self._view.quit.config(state="disabled")
        observer.Event("update_state_box", str(self._view))
        observer.Event("update_state", f"THE GAME HAS ENDED! Thanks for playing!")


    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        print("ROLL ACTION TRIGGERED")

        self._view._start_timer()

        if not self._handle_roll_dice():
            print("Roll was prevented.")
            return

        player = self._gameboard.get_current_player()
        observer.Event("update_state", f"{player.name} landed on {self._gameboard.get_square(player.position)}.")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)




