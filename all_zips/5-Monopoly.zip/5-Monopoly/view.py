import tkinter as tk
from tkinter import simpledialog
import os
from tkinter import ttk
import controller
import observer
from PIL import Image, ImageTk


class View(observer.Observer):
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        self.images = []
        self.root = root
        self.available_tokens = ["Car", "Hat"]
        self.player_tokens = {}
        self.token_images = {}

        self.player_names = self._ask_for_player_names()
        root.title("Monopoly 1920")
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self._add_listeners()

        self.turn_banner = tk.Label(self.root, text="", font=("Arial", 14, "bold"), fg="white", bg="darkblue")
        self.turn_banner.pack(fill='x')

    def _ask_for_token(self, player_name):
        popup = tk.Toplevel(self.root)
        popup.title(f"{player_name}, choose your token")

        label = ttk.Label(popup, text=f"{player_name}, choose your token:", font=("Arial", 12))
        label.pack(pady=10)

        if not self.token_images:
            for token in self.available_tokens:
                path = os.path.join("resources", "images", "tokens", f"{token.lower()}.png")
                img = Image.open(path)
                img = img.resize((80, 80), Image.Resampling.LANCZOS)
                self.token_images[token] = ImageTk.PhotoImage(img)

        selected_token = tk.StringVar()

        def choose_token(token_name):
            selected_token.set(token_name)
            popup.destroy()

        for token in self.available_tokens:
            btn = ttk.Button(popup, image=self.token_images[token], command=lambda t=token: choose_token(t))
            btn.pack(side='left', padx=20, pady=10)

        self.root.wait_window(popup)

        chosen = selected_token.get()
        if not chosen:
            chosen = self.available_tokens[0]

        self.available_tokens.remove(chosen)
        return chosen

    def _ask_for_player_names(self):
        names = []
        for i in range(2):
            name = simpledialog.askstring("Player Name", f"Enter name for Player {i + 1}:", parent=self.root)
            if not name:
                name = f"Player {i + 1}"
            token = self._ask_for_token(name)
            self.player_tokens[name] = token
            names.append(name)
        return names

    def _add_listeners(self):
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)

    def _create_middle_frame(self):
        middle_frame = ttk.Frame(self.main_frame, padding=10)

        button_frame = ttk.Frame(middle_frame, padding=10)
        button_frame.pack(side='left', anchor='n', padx=20, pady=10)

        self.mid_buttons = []

        for text, action in [
            ("Roll Dice", "roll"),
            ("Purchase", "purchase"),
            ("Mortgage", "mortgage"),
            ("Unmortgage", "unmortgage"),
            ("Go Bankrupt", "bankrupt"),
            ("End Turn", "end_turn"),
        ]:
            btn = ttk.Button(button_frame, text=text, command=lambda a=action: self._action_taken(a))
            btn.pack(side='top', pady=5, fill='x')
            self.mid_buttons.append(btn)

        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.image = board_image
        board.pack(side='left', anchor='n', padx=30, pady=10)

        self._preload_images()

        right_frame = ttk.Frame(middle_frame)
        right_frame.pack(side='left', anchor='n', padx=20, pady=10)

        self.dice_images = []
        for i in range(1, 7):
            img_path = os.path.join("resources", "images", "dice", f"dice{i}.png")
            img = Image.open(img_path)
            img = img.resize((40, 40), Image.Resampling.LANCZOS)
            self.dice_images.append(ImageTk.PhotoImage(img))

        dice_frame = ttk.Frame(right_frame)
        dice_frame.pack(side='top', anchor='center', pady=(0, 10))

        self.die1_label = ttk.Label(dice_frame, image=self.dice_images[0])
        self.die1_label.pack(side='left', padx=5)

        self.die2_label = ttk.Label(dice_frame, image=self.dice_images[1])
        self.die2_label.pack(side='left', padx=5)

        card_image = self.images[0]
        self.card = ttk.Label(right_frame, image=card_image)
        self.card.image = card_image
        self.card.pack(side='top', anchor='center', pady=(10, 0))

        return middle_frame

    def _create_msg_frame(self):
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)
        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100, 30))

        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30, 100))
        return msg_frame

    def _create_logo_frame(self):
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image
        return logo_frame

    def _action_taken(self, action):
        if action == "roll":
            observer.Event("roll", None)
        elif action == "purchase":
            observer.Event("purchase", None)
        elif action == "mortgage":
            observer.Event("mortgage", None)
        elif action == "unmortgage":
            observer.Event("unmortgage", None)
        elif action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)
        elif action == "end_turn":
            observer.Event("end_turn", self._clear_text)

    def update_turn_banner(self, player):
        self.turn_banner.config(
            text=f"● {player.name}'s Turn (Position {player.position})"
        )

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        self.text_box.insert(tk.END, text + "\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        self.popup_menu = tk.Menu(self.root, tearoff=0)
        for c in choices:
            self.popup_menu.add_command(label=c, command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()
        lbl = "Cancel"
        if len(choices) == 0:
            lbl = "No properties to mortgage (click to cancel)"
        self.popup_menu.add_command(label=lbl, command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)

    def _preload_images(self):
        for i in range(40):
            path = os.path.join("resources", "images", "properties", f"{i}.png")
            img = tk.PhotoImage(file=path)
            self.images.append(img)

    def animate_dice(self, dice1, dice2):
        import time
        from random import randint

        def roll():
            for _ in range(10):
                r1 = randint(0, 5)
                r2 = randint(0, 5)
                self.die1_label.config(image=self.dice_images[r1])
                self.die2_label.config(image=self.dice_images[r2])
                self.root.update()
                time.sleep(0.05)

            self.die1_label.config(image=self.dice_images[dice1 - 1])
            self.die2_label.config(image=self.dice_images[dice2 - 1])

        self.root.after(0, roll)



# Launch the game
if __name__ == '__main__':
    root = tk.Tk()
    controller = controller.Controller(root)
    root.mainloop()


