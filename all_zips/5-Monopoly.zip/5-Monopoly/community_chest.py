import random
import observer

class CommunityChest:
    def __init__(self):
        self.cards = [
            {"text": "Advance to Go (Collect $200)", "action": self.advance_to_go},
            {"text": "Bank error in your favor – Collect $200", "action": self.collect_200},
            {"text": "Doctor's fees – Pay $50", "action": self.pay_50},
            {"text": "It is your birthday – Collect $10 from every player", "action": self.birthday},
            {"text": "Get Out of Jail Free", "action": self.get_out_of_jail},
            {"text": "Go to Jail. Do not pass Go, do not collect $200", "action": self.go_to_jail},
            {"text": "From sale of stock you get $50", "action": self.collect_50}
        ]

    def draw(self, player, gameboard):
        card = random.choice(self.cards)
        observer.Event("update_state", f"Community Chest: {card['text']}")
        card["action"](player, gameboard)

    def advance_to_go(self, player, gameboard):
        player.move(40 - player.position)  # move to 0
        player.collect(200)

    def collect_200(self, player, gameboard):
        player.collect(200)

    def pay_50(self, player, gameboard):
        player.money -= 50

    def birthday(self, player, gameboard):
        for p in gameboard._GameBoard__players:
            if p != player and not p.bankrupt_declared:
                p.money -= 10
                player.money += 10

    def get_out_of_jail(self, player, gameboard):
        # placeholder – you could implement a "has_get_out_card" flag on the player
        observer.Event("update_state", "You received a Get Out of Jail Free card!")

    def go_to_jail(self, player, gameboard):
        player.declare_bankrupt()  # again, update later when jail is fully implemented

    def collect_50(self, player, gameboard):
        player.collect(50)