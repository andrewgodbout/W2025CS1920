import random
import observer

class ChanceDeck:
    def __init__(self):
        self.cards = [
            {"text": "Advance to Go (Collect $200)", "action": self.advance_to_go},
            {"text": "Bank pays you dividend of $50", "action": self.get_dividend},
            {"text": "Go to Jail. Do not pass Go, do not collect $200", "action": self.go_to_jail},
            {"text": "Pay poor tax of $15", "action": self.pay_tax},
            {"text": "You have won a crossword competition. Collect $100", "action": self.crossword_win}
        ]

    def draw(self, player, gameboard):
        card = random.choice(self.cards)
        observer.Event("update_state", f"Chance Card: {card['text']}")
        card["action"](player, gameboard)

    def advance_to_go(self, player, gameboard):
        player.move(40 - player.position)  # move to 0
        player.collect(200)

    def get_dividend(self, player, gameboard):
        player.collect(50)

    def go_to_jail(self, player, gameboard):
        player.declare_bankrupt()  # placeholder: update to proper jail logic later

    def pay_tax(self, player, gameboard):
        player.money -= 15

    def crossword_win(self, player, gameboard):
        player.collect(100)