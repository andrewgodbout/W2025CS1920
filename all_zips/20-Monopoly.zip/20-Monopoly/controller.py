import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)
        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0  # Track rolls per turn (not just doubles)
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("use_card", self._use_get_out_of_jail_card)
        self.observe("bankrupt", self._declare_bankrupt)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate rolling of two dice and return sum and doubles status."""
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2
        rolled_doubles = dice1 == dice2
        observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum, rolled_doubles

    def _handle_roll_dice(self):
        """Handle dice rolling with jail and doubles logic."""
        player = self._gameboard.get_current_player()

        # Allow rolling if not yet rolled this turn or if doubles were rolled previously
        if self.__dice_rolled and player.doubles_count < 2 and not player.in_jail():
            observer.Event("update_state", "One roll per turn unless doubles are rolled")
            return False

        dice_sum, rolled_doubles = self._roll_dice()

        # Handle jail status
        if player.in_jail():
            result = player.attempt_exit_jail(rolled_doubles)
            observer.Event("update_state", result)
            if "Still in jail" in result:
                self.__roll_count += 1
                self.__dice_rolled = True  # End turn if still in jail
                return False
            self.__dice_rolled = False  # Allow roll after escaping jail

        # Move player and check doubles
        player.move(dice_sum, rolled_doubles)
        position = player.position
        square = self._gameboard.get_square(position)

        if player.doubles_count >= 3:
            player.go_to_jail()
            observer.Event("update_state", f"{player.name} rolled doubles 3 times and is sent to jail!")
            self.__dice_rolled = True
            self.__roll_count = 0
            return False

        # Handle "Go to Jail" square
        if square.name == "Go to Jail":
            player.go_to_jail()
            observer.Event("update_state", f"{player.name} landed on Go to Jail and is sent to jail!")
            self.__dice_rolled = True
            return False

        # Pay rent or tax
        rent = player.pay_rent(square, dice_sum)
        if rent > 0:
            observer.Event("update_state", f"Rent paid: {rent}")

        # Check for bankruptcy
        if player.money < 0:
            player.declare_bankrupt()

        # If doubles, allow another roll; otherwise, end turn
        if rolled_doubles:
            self.__dice_rolled = False  # Keep turn alive for another roll
            observer.Event("update_state", f"{player.name} rolled doubles! Roll again.")
        else:
            self.__dice_rolled = True  # End turn if no doubles
        self.__roll_count += 1

        return True

    def _end_player_turn(self, callback):
        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return

        player = self._gameboard.get_current_player()
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        observer.Event("update_state", f"{player_name}'s turn")
        self.__dice_rolled = False
        self.__roll_count = 0
        self._set_expected_val()
        callback()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _draw_card(self, card_type):
        """Simulate drawing a Chance or Community Chest card."""
        player = self._gameboard.get_current_player()
        if random.random() < 0.1:  # 10% chance to go to jail
            player.go_to_jail()
            observer.Event("update_state", f"{player.name} drew a {card_type} card and is sent to jail!")
            return True
        elif random.random() < 0.05:  # 5% chance to get a jail card
            player.get_out_of_jail_cards += 1
            observer.Event("update_state", f"{player.name} drew a Get Out of Jail Free card!")
            return True
        return False


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()
        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money
        msg = f"{player.name} landed on {square}."

        # Check for Chance or Community Chest
        if square.space in ["Chance", "Chest"]:
            self._draw_card(square.space)

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    def _use_get_out_of_jail_card(self, data):
        """Player uses a Get Out of Jail Free card if they have one."""
        player = self._gameboard.get_current_player()
        if player.in_jail() and player.get_out_of_jail_cards > 0:
            result = player.attempt_exit_jail(False)  # False since no doubles
            observer.Event("update_state", result)
            self.__dice_rolled = False  # Allow rolling after card use
        else:
            observer.Event("update_state", "No Get Out of Jail Free card available.")

    def _declare_bankrupt(self, data):
        player = self._gameboard.get_current_player()
        player.declare_bankrupt()
        observer.Event("update_state", f"{player.name} declared bankruptcy!")
        observer.Event("update_state_box", str(self._gameboard))


