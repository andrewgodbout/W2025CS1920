import random
import os
import tkinter
import observer

class CommunityChest:
    def __init__(self, root):
        self.cards = [
            {"text": "Advance to Go (Collect $200)", "action": "move", "value": 0, "image": "01.png"},
            {"text": "You have won second prize in a beauty contest. Collect $10", "action": "collect", "value": 10, "image": "02.png"},
            {"text": "Bank error in your favor. Collect $200", "action": "collect", "value": 200, "image": "03.png"},
            {"text": "Life insurance matures. Collect $100", "action": "collect", "value": 100, "image": "04.png"},
            {"text": "From sale of stock you get $45", "action": "collect", "value": 45, "image": "05.png"},
            {"text": "Income tax refund. Collect $20", "action": "collect", "value": 20, "image": "06.png"},
            {"text": "Receive for services $25", "action": "collect", "value": 25, "image": "07.png"},
            {"text": "You inherit $100", "action": "collect", "value": 100, "image": "08.png"},
            {"text": "XMas Fund matures. Receive $100", "action": "collect", "value": 100, "image": "09.png"},
            {"text": "Doctor's fees. Pay $50", "action": "pay", "value": 50, "image": "11.png"},
            {"text": "Pay hospital $100", "action": "pay", "value": 100, "image": "12.png"},
            {"text": "Pay school tax of $150", "action": "pay", "value": 150, "image": "13.png"}
        ]
        self.root = root
        self.image_path = os.path.join("resources", "images", "community_chest")
        random.shuffle(self.cards)
        self.discard_pile = []

        self._load_images()

    def _load_images(self):
        self.card_images = []
        for card in self.cards:
            image_path = os.path.join(self.image_path, card["image"])

            if os.path.exists(image_path):
                img = tkinter.PhotoImage(file=image_path)
                img = img.subsample(2, 2)
                self.card_images.append(img)
            else:
                self.card_images.append(None)

    def draw_card(self):
        if not self.cards:
            self._recycle_discard_pile()

        card = self.cards.pop(0)
        image = self.card_images.pop(0)
        self.discard_pile.append((card, image))

        return card, image

    def _recycle_discard_pile(self):
        self.cards = [item[0] for item in self.discard_pile]
        self.card_images = [item[1] for item in self.discard_pile]

        indices = list(range(len(self.cards)))
        random.shuffle(indices)

        self.cards = [self.cards[i] for i in indices]
        self.card_images = [self.card_images[i] for i in indices]

        self.discard_pile = []