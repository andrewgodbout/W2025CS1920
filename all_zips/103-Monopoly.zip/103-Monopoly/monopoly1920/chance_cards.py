import random
import os
import tkinter
import observer

class ChanceCards:
    def __init__(self, root):
        self.cards = [
            {"text": "Advance to Go (Collect $200)", "action": "move", "value": 0, "image": "01.png"},
            {"text": "Take a walk on the Boardwalk. Advance to Boardwalk", "action": "move", "value": 39, "image": "02.png"},
            {"text": "Advance to Illinois Ave.", "action": "move", "value": 24, "image": "03.png"},
            {"text": "Advance to St.Charles Place. Collect $200 if you pass go", "action": "collect", "value": 11, "image": "04.png"},
            {"text": "Go back three spaces", "action": "subtract", "value": 3, "image": "05.png"},
            {"text": "Bank pays you dividend of $50", "action": "collect", "value": 50, "image": "06.png"},
            {"text": "Your building and loan matures. Collect $150", "action": "collect", "value": 150, "image": "07.png"},
            {"text": "Pay poor tax of $15", "action": "pay", "value": 15, "image": "08.png"},
            {"text": "Go directly to jail. Do not collect 200$ if you passing Go.", "action": "move", "value": 10, "image": "09.png"},
        ]
        self.root = root
        self.image_path = os.path.join("resources", "images", "chance_cards")
        random.shuffle(self.cards)
        self.discard_pile = []

        self._load_images()

    def _load_images(self):
        self.card_images = []
        for card in self.cards:
            image_path = os.path.join(self.image_path, card["image"])

            if os.path.exists(image_path):
                img = tkinter.PhotoImage(file=image_path)
                img = img.subsample(2, 2)
                self.card_images.append(img)
            else:
                self.card_images.append(None)

    def draw_card(self):
        if not self.cards:
            self._recycle_discard_pile()

        card = self.cards.pop(0)
        image = self.card_images.pop(0)
        self.discard_pile.append((card, image))

        return card, image

    def _recycle_discard_pile(self):
        self.cards = [item[0] for item in self.discard_pile]
        self.card_images = [item[1] for item in self.discard_pile]

        indices = list(range(len(self.cards)))
        random.shuffle(indices)

        self.cards = [self.cards[i] for i in indices]
        self.card_images = [self.card_images[i] for i in indices]

        self.discard_pile = []