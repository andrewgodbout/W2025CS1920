import tkinter as tk
import os
from tkinter import ttk
import controller
import observer


class View(observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        # Tight coupling with the controller (not ideal, but we will refactor later)
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        # Create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        # Pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

        # Preload all images for the board squares and dice
        self._preload_images()
        self._preload_dice_images()

    def _preload_dice_images(self):
        """Preload dice images for the dice roll animation."""
        self.dice_images = {
            i: tk.PhotoImage(file=f"resources/images/dice_{i}.png").subsample(4, 4) for i in range(1, 7)
        }

    def _add_listeners(self):
        """Add listeners to the view."""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)

    def _create_middle_frame(self):
        """Create the middle frame of the GUI."""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # Preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)

        # Dice display
        self.dice_label1 = ttk.Label(button_frame, image=self.dice_images[1])
        self.dice_label1.pack(side='top', pady=(10, 0))

        self.dice_label2 = ttk.Label(button_frame, image=self.dice_images[1])
        self.dice_label2.pack(side='top', pady=(0, 10))

        # Create buttons
        self.mid_buttons = []
        self.roll_button = ttk.Button(
            button_frame, text="Roll Dice", command=lambda: observer.Event("roll", None)
        )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(
            button_frame, text="Purchase", command=lambda: observer.Event("purchase", None)
        )
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(
            button_frame, text="Mortgage", command=lambda: observer.Event("mortgage", None)
        )
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(
            button_frame, text="Unmortgage", command=lambda: observer.Event("unmortgage", None)
        )
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(
            button_frame, text="Go Bankrupt", command=lambda: observer.Event("bankrupt", None)
        )
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(
            button_frame, text="End Turn", command=lambda: observer.Event("end_turn", self._clear_text)
        )
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        return middle_frame

    def animate_dice_roll(self):
        """Animate dice roll by rapidly changing dice faces."""
        def update_dice():
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            self.dice_label1.config(image=self.dice_images[dice1])
            self.dice_label2.config(image=self.dice_images[dice2])
            if self.animation_steps > 0:
                self.animation_steps -= 1
                self.root.after(100, update_dice)  # Update every 100ms

        self.animation_steps = 10  # Number of animation steps
        update_dice()

    def update_dice_faces(self, dice1, dice2):
        """Update dice faces to the final rolled values."""
        self.dice_label1.config(image=self.dice_images[dice1])
        self.dice_label2.config(image=self.dice_images[dice2])

    # ... (rest of the methods remain unchanged)

if __name__ == '__main__':
    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = Controller(root)

    root.mainloop()

