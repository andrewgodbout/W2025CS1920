class Player {
    constructor(name, money = 1500) {
        this.name = name;
        this.money = money;
        this.position = 0;
        this.doublesCount = 0;
        this.inJail = false;
        this.turnsInJail = 0;
        this.getOutOfJailFreeCards = 0;
        this.properties = [];
    }

    move(spaces) {
        if (this.inJail) return;
        this.position = (this.position + spaces) % 40;
        if (this.position < spaces) {
            this.collect(200);  // Passing Go
        }
    }

    moveTo(position) {
        this.position = position;
    }

    moveToJail() {
        this.position = 10;  // Jail position
        this.inJail = true;
        this.turnsInJail = 0;
        this.doublesCount = 0;
        updateState(`${this.name} goes to Jail`);
    }

    leaveJail() {
        if (this.getOutOfJailFreeCards > 0) {
            this.getOutOfJailFreeCards--;
        } else {
            this.pay(50);
        }
        this.inJail = false;
        this.turnsInJail = 0;
        updateState(`${this.name} leaves Jail`);
    }

    collect(amount) {
        this.money += amount;
    }

    pay(amount) {
        this.money -= amount;
    }

    buyProperty(property) {
        if (property.canBePurchased() && this.money >= property.price) {
            this.properties.push(property);
            this.pay(property.price);
            property.owner = this;
            console.log(`${this.name} has purchased the property: ${property.name}`);
            return true;
        }
        return false;
    }

    payRent(property, diceSum) {
        if (property.owner !== this && !property.isMortgaged) {
            const rent = property.calculateRentOrTax(diceSum);
            this.pay(rent);
            if (property.owner) {
                property.owner.collect(rent);
            }
            return rent;
        }
        return 0;
    }
}

class Property {
    constructor(name, price, rent, isUtility, isRailroad) {
        this.name = name;
        this.price = price;
        this.rent = rent;
        this.isUtility = isUtility;
        this.isRailroad = isRailroad;
        this.owner = null;
        this.isMortgaged = false;
    }

    canBePurchased() {
        return this.owner === null && !this.isSpecial();
    }

    isSpecial() {
        const specialSpaces = ["Tax", "Chance", "Chest", "GotoJail", "Jail", "Parking", "Go"];
        return specialSpaces.includes(this.name);
    }

    calculateRentOrTax(diceSum) {
        if (this.isUtility) {
            return 4 * diceSum;
        }
        if (this.isRailroad) {
            return 25 * (2 ** (this.owner.railroadCount - 1));
        }
        return this.rent;
    }
}

class Game {
    constructor() {
        this.players = [];
        this.currentPlayerIndex = 0;
        this.diceRolled = false;
        this.board = this.loadBoard();
        this.promptForPlayers();
        this.initUI();
    }

    loadBoard() {
        // Load the board from resources/data/board.csv
        // For simplicity, we hardcode it here
        return [
            new Property("Go", 0, 0, false, false),
            new Property("Mediterranean Avenue", 60, 2, false, false),
            // Add other properties...
        ];
    }

    promptForPlayers() {
        let numPlayers = prompt("Enter the number of players (2-4):", "2");
        numPlayers = Math.min(Math.max(parseInt(numPlayers), 2), 4);

        for (let i = 0; i < numPlayers; i++) {
            let playerName = prompt(`Enter the name for Player ${i + 1} (leave empty for default):`, "");
            if (!playerName) {
                playerName = `Player ${i + 1}`;
            }
            this.players.push(new Player(playerName));
        }
    }

    initUI() {
        document.getElementById('roll-button').addEventListener('click', () => this.rollDice());
        document.getElementById('purchase-button').addEventListener('click', () => this.purchaseProperty());
        document.getElementById('mortgage-button').addEventListener('click', () => this.mortgageProperty());
        document.getElementById('unmortgage-button').addEventListener('click', () => this.unmortgageProperty());
        document.getElementById('bankrupt-button').addEventListener('click', () => this.goBankrupt());
        document.getElementById('end-turn-button').addEventListener('click', () => this.endTurn());
        this.updateUI();
    }

    updateUI() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        updateState(`${currentPlayer.name}'s turn`);
        updateStateBox(this.getGameState());
        updateCard(currentPlayer.position);
        updatePropertiesBox(currentPlayer);
    }

    getGameState() {
        return this.players.map(player => `${player.name} - $${player.money} - Position: ${player.position}`).join('\n');
    }

    rollDice() {
        if (this.diceRolled) {
            updateState("One roll per turn or Doubles required");
            return;
        }

        const dice1 = Math.floor(Math.random() * 6) + 1;
        const dice2 = Math.floor(Math.random() * 6) + 1;
        const diceSum = dice1 + dice2;

        const currentPlayer = this.players[this.currentPlayerIndex];
        currentPlayer.doublesCount = (dice1 === dice2) ? currentPlayer.doublesCount + 1 : 0;

        if (currentPlayer.doublesCount === 3) {
            updateState(`${currentPlayer.name} rolled doubles three times and goes to jail!`);
            currentPlayer.moveToJail();
            this.diceRolled = true;
            return;
        }

        if (currentPlayer.inJail) {
            if (dice1 === dice2) {
                currentPlayer.leaveJail();
                currentPlayer.move(diceSum);
            } else {
                currentPlayer.turnsInJail++;
                updateState(`${currentPlayer.name} is still in jail. Turns in jail: ${currentPlayer.turnsInJail}`);
                if (currentPlayer.turnsInJail >= 3) {
                    updateState(`${currentPlayer.name} must pay $50 or use a 'Get Out of Jail Free' card to leave jail.`);
                    // Implement paying $50 or using 'Get Out of Jail Free' card
                }
                this.diceRolled = true;
                return;
            }
        } else {
            currentPlayer.move(diceSum);
        }

        this.handleSquare(currentPlayer.position);
        this.diceRolled = true;

        // Display the result of the dice roll
        updateState(`${currentPlayer.name} rolled ${dice1} and ${dice2} (Total: ${diceSum})`);
    }

    handleSquare(position) {
        const currentPlayer = this.players[this.currentPlayerIndex];
        const square = this.board[position];

        updateState(`${currentPlayer.name} landed on ${square.name}`);

        switch (square.name) {
            case "Chance":
                this.handleChance(currentPlayer);
                break;
            case "Chest":
                this.handleCommunityChest(currentPlayer);
                break;
            case "GotoJail":
                currentPlayer.moveToJail();
                break;
            default:
                const rent = currentPlayer.payRent(square, 0);
                if (rent > 0) {
                    updateState(`Rent paid: $${rent}`);
                }
                break;
        }

        this.updateUI();
    }

    handleChance(player) {
        const effects = [
            "Advance to Go (Collect $200)",
            "Bank error in your favor – Collect $75",
            "Doctor's fee – Pay $50",
            "From sale of stock you get $50",
            "Go to Jail – Go directly to jail – Do not pass Go – Do not collect $200",
            // Add more effects...
        ];
        const effect = effects[Math.floor(Math.random() * effects.length)];
        this.applyEffect(player, effect);
    }

    handleCommunityChest(player) {
        const effects = [
            "Advance to Go (Collect $200)",
            "Go to Jail – Go directly to jail – Do not pass Go – Do not collect $200",
            "It is your birthday Collect $10 from each player",
            "Grand Opera Night – Collect $50 from every player for opening night seats",
            // Add more effects...
        ];
        const effect = effects[Math.floor(Math.random() * effects.length)];
        this.applyEffect(player, effect);
    }

    applyEffect(player, effect) {
        updateState(effect);
        switch (effect) {
            case "Advance to Go (Collect $200)":
                player.moveTo(0);
                player.collect(200);
                break;
            case "Bank error in your favor – Collect $75":
                player.collect(75);
                break;
            case "Doctor's fee – Pay $50":
                player.pay(50);
                break;
            case "From sale of stock you get $50":
                player.collect(50);
                break;
            case "Go to Jail – Go directly to jail – Do not pass Go – Do not collect $200":
                player.moveToJail();
                break;
            case "It is your birthday Collect $10 from each player":
                this.players.forEach(p => {
                    if (p !== player) {
                        p.pay(10);
                        player.collect(10);
                    }
                });
                break;
            case "Grand Opera Night – Collect $50 from every player for opening night seats":
                this.players.forEach(p => {
                    if (p !== player) {
                        p.pay(50);
                        player.collect(50);
                    }
                });
                break;
            // Implement more effects...
        }
    }

    purchaseProperty() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        const square = this.board[currentPlayer.position];
        if (currentPlayer.buyProperty(square)) {
            updateState(`Square bought: ${square.name}`);
        } else {
            updateState(`Square not bought: ${square.name}`);
        }
        this.updateUI();
    }

    mortgageProperty() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        const propertyNames = currentPlayer.properties.map(p => p.name);
        const propertyToMortgage = prompt(`Choose a property to mortgage: ${propertyNames.join(', ')}`);
        const property = currentPlayer.properties.find(p => p.name === propertyToMortgage);
        if (property && !property.isMortgaged) {
            property.isMortgaged = true;
            currentPlayer.collect(property.price / 2);
            updateState(`${property.name} mortgaged`);
        } else {
            updateState(`Invalid property or already mortgaged.`);
        }
        this.updateUI();
    }

    unmortgageProperty() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        const mortgagedProperties = currentPlayer.properties.filter(p => p.isMortgaged).map(p => p.name);
        const propertyToUnmortgage = prompt(`Choose a property to unmortgage: ${mortgagedProperties.join(', ')}`);
        const property = currentPlayer.properties.find(p => p.name === propertyToUnmortgage);
        if (property && property.isMortgaged) {
            const unmortgageCost = property.price / 2 + (property.price / 2) * 0.1;
            if (currentPlayer.money >= unmortgageCost) {
                property.isMortgaged = false;
                currentPlayer.pay(unmortgageCost);
                updateState(`${property.name} unmortgaged`);
            } else {
                updateState(`Not enough money to unmortgage ${property.name}`);
            }
        } else {
            updateState(`Invalid property or not mortgaged.`);
        }
        this.updateUI();
    }

    goBankrupt() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        currentPlayer.money = 0;
        currentPlayer.properties.forEach(property => property.owner = null);
        currentPlayer.properties = [];
        updateState(`${currentPlayer.name} has gone bankrupt!`);
        this.endTurn();
    }

    endTurn() {
        this.diceRolled = false;
        this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
        this.updateUI();
    }
}

function updateState(message) {
    const stateBox = document.getElementById('state-box');
    stateBox.innerHTML += `<p>${message}</p>`;
    stateBox.scrollTop = stateBox.scrollHeight;
}

function updateStateBox(message) {
    const stateBox = document.getElementById('state-box');
    stateBox.innerHTML = `<p>${message}</p>`;
}

function updateCard(position) {
    const cardImage = document.getElementById('card-image');
    cardImage.src = `resources/images/properties/${position}.png`;
}

function updatePropertiesBox(player) {
    const propertiesBox = document.getElementById('properties-box');
    propertiesBox.innerHTML = `<p>${player.name}'s Properties: ${player.properties.map(p => p.name).join(', ')}</p>`;
}

// Initialize the game
const game = new Game();
game.updateUI();