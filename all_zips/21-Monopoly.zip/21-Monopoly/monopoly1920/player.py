import gameboard
import gamesquare
import observer
import random
import json
from datetime import datetime


class ChatSystem:
    def __init__(self, max_history=100):
        self.messages = []
        self.max_history = max_history
        self.current_sender = None

    def send_message(self, sender, message):
        """Record a new chat message"""
        if not message.strip():
            return False

        entry = {
            'sender': sender.name,
            'token': sender.token,
            'message': message.strip(),
            'turn': sender.game.current_turn if hasattr(sender, 'game') else 0,
            'timestamp': datetime.now().strftime("%H:%M:%S")
        }

        self.messages.append(entry)
        if len(self.messages) > self.max_history:
            self.messages.pop(0)
        return True

    def get_recent_messages(self, count=5):
        """Get most recent chat messages"""
        return self.messages[-count:]

    def __str__(self):
        """Display chat history"""
        return "\n".join(
            f"[{msg['timestamp']}] {msg['sender']} ({msg['token']}): {msg['message']}"
            for msg in self.get_recent_messages(10)
        )



class Player:
    """Player class to represent a player in the game"""


    TOKEN_OPTIONS = {
        "1": "🚗",  # Car
        "2": "🏠",  # House
        "3": "🐶",  # Dog
        "4": "👞",  # Shoe
        "5": "🛒",  # Shopping Cart
        "6": "🎩",  # Hat
        "7": "⛵",  # Boat
        "8": "✈️"  # Airplane
    }

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name =  self._get_player_name(name)  # Modified name handling
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0

        self.__token = self._select_token()

        self.in_jail = False
        self.jail_turns = 0
        self.get_out_of_jail_free_cards = 0
        self.consecutive_doubles = 0

        #big numbers are lucky, negative numbers are unlucky
        self.__luck = 0

        #add a Data structure to track mortgaging order
        self.__mortgaging_order = []

    def handle_chat(self, game):
        """Process chat input during player's turn"""
        print("\nChat commands: /msg [message], /read, /exit")
        while True:
            cmd = input("(chat) ").strip().split(maxsplit=1)
            if not cmd or cmd[0].lower() == '/exit':
                break

            if cmd[0].lower() == '/read':
                print("\nChat History:")
                print(game.chat)

            elif cmd[0].lower() == '/msg' and len(cmd) > 1:
                game.chat.send_message(self, cmd[1])
                print(f"Message sent to all players!")

            else:
                print("Invalid command. Try /msg [message] or /read")

    def _get_player_name(self, default_name=None):
        """Get player name through input if not provided
            Args:
            default_name (str): If provided, uses this name without prompting
            Returns:
            str: Validated player name
        """
        if default_name:
            return default_name

        while True:
            name = input("Enter player name (2-15 characters): ").strip()
            if 2 <= len(name) <= 15:
                return name
            print("Invalid name! Must be 2-15 characters.")


    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"



    def _select_token(self):
        """Let player choose their token"""
        print("\nAvailable tokens:")
        for num, token in self.TOKEN_OPTIONS.items():
            print(f"{num}: {token}")

        while True:
            choice = input("Choose a token (1-8): ")
            if choice in self.TOKEN_OPTIONS:
                return self.TOKEN_OPTIONS[choice]
            print("Invalid choice! Please select 1-8")




    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
        """Function to attempt to pay rent or tax on a square"""
        if square.owner is self:
            return 0
        rent = square.calculate_rent_or_tax(dice_sum)
        self.__money -= rent

        if square.owner is not None:
            square.owner.money += rent
        return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount

    def move(self, spaces):
        """Function to move the player on the board"""
        prior_position = self.__board_position
        self.__board_position += spaces
        if self.__board_position >= 40:
            self.__board_position -= 40
        # careful about passing go
        if self.__board_position < prior_position:
            observer.Event("update_state", "pass_go +200")
            self.collect(200)

    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @property
    def position(self):
        return self.__board_position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return self.__railroad_count

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]

    @property
    def token(self):
        return self.__token