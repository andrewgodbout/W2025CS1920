import player
import gamesquare
import random


class JailSystem:
    def __init__(self):
        self.JAIL_POSITION = 10
        self.GO_TO_JAIL_POSITION = 30

    def handle_jail(self, player, dice1, dice2):
        """Handle all jail-related logic for a player"""
        # Check if player should be sent to jail
        if self.should_go_to_jail(player, dice1, dice2):
            self.send_to_jail(player)
            return True

        # Handle turns while in jail
        if player.in_jail:
            return self.handle_jail_turn(player, dice1, dice2)

        # Check if just visiting
        if player.position == self.JAIL_POSITION and not player.in_jail:
            print(f"{player.name} is just visiting jail.")
            return False

        return False

    def should_go_to_jail(self, player, dice1, dice2):
        """Check if player should be sent to jail"""
        # Landed on "Go to Jail" square
        if player.position == self.GO_TO_JAIL_POSITION:
            return True

        # Rolled three consecutive doubles
        if player.consecutive_doubles >= 2 and dice1 == dice2:
            return True

        return False

    def send_to_jail(self, player):
        """Send player to jail"""
        player.in_jail = True
        player.jail_turns = 0
        player.position = self.JAIL_POSITION
        player.consecutive_doubles = 0  # Reset doubles counter
        print(f"{player.name} has been sent to jail!")

    def handle_jail_turn(self, player, dice1, dice2):
        """Handle player's turn while in jail"""
        player.jail_turns += 1
        is_double = (dice1 == dice2)


        if player.get_out_of_jail_free_cards > 0:
            player.get_out_of_jail_free_cards -= 1
            player.in_jail = False
            player.jail_turns = 0
            print(f"{player.name} used a Get Out of Jail Free card!")
            return True


        if is_double:
            player.in_jail = False
            player.jail_turns = 0
            print(f"{player.name} rolled doubles and is released from jail!")
            return True


        if player.jail_turns >= 3:
            if player.money >= 50:
                player.money -= 50
                player.in_jail = False
                player.jail_turns = 0
                print(f"{player.name} paid $50 to get out of jail.")
                return True
            else:
                print(f"{player.name} cannot afford to pay $50 and remains in jail.")
                return False

        print(f"{player.name} remains in jail (Turn {player.jail_turns}/3)")
        return False

class GameBoard:

    __boardCSV = {
        "name": 0,
        "space": 1,
        "color": 2,
        "position": 3,
        "price": 4,
        "build": 5,
        "rent": 6,
        "rent1": 7,
        "rent2": 8,
        "rent3": 9,
        "rent4": 10,
        "rent5": 11,
        "hotelcost": 12,
        "owner": 13,
        "houses": 14,
        "groupmembers": 15
    }

    def __init__(self, properties_path, players ):
        self.__properties = self._load_game_board(properties_path)

        self.__players = players

        self.__total_turns = 0

        # set the current player
        self.__current_player = self.__players.pop(0)

        self.jail_system = JailSystem()

        self.chat = ChatSystem()

    def roll_dice(self):
        """Simulate rolling two dice"""
        return random.randint(1, 6), random.randint(1, 6)

    def next_turn(self):
        #add the prior player to the end of the queue
        if not self.__current_player.bankrupt_declared:
            self.__players.append(self.__current_player)

        self.__total_turns += 1

        print(f"\n{self.__current_player.name}'s turn (Money: ${self.__current_player.money})")
        self.__current_player.handle_chat(self)

        #set the current player to the next player in the queue
        self.__current_player = self.__players.pop(0)

        # Handle jail logic if player is in jail
        if self.__current_player.in_jail:
            dice1, dice2 = self.roll_dice()

            self.jail_system.handle_jail(self.__current_player, dice1, dice2)

        return self.__current_player.name


    def calculate_expected_value(self, pos, doubles_count):
        """calculate the expected outcome of the next turn"""
        expected_value = 0
        for i in range(1,7):
            for j in range(1,7):
                new_pos = (pos + i + j) % 40
                #base case calculate the outcome of landing on the square
                if doubles_count == 2 and i == j:
                    continue #go to jail

                expected_value += (self.get_board_square(new_pos).calculate_rent_or_tax(i+j) / 36)
                if i == j:
                    #recursive case roll again don't forget this must be multiplied by
                    # the probability of rolling a double (1/36)
                    expected_value += (self.calculate_expected_value(new_pos, doubles_count+1) / 36)
        return expected_value

    def get_current_player(self):
        """return the current player"""
        return self.__current_player

    def get_all_squares(self):
        return self.__properties

    def get_square(self, index):
        return self.__properties[index]

    def get_board_square(self, index):
        """Function to return the board square at the given index
            @:param game_board: an ordered list of Properties
            @:param index: the index of the space on the board
            @:return square: the square at the given index
        """
        square = self.__properties[index]
        return square

    def _load_game_board(self, csv_path):
        """Function to load and return the game board from a file
            :param csv_path: the path to the csv file containing the board data
            :return game_board: an ordered list of the game board spaces
                                 where the 0th index is "GO" and the indices
                                 proceed clockwise around the board
        """
        properties = []

        f = open(csv_path, "r")
        next(f)  # skip the header row of the file, we don't need it for this game
        for line in f:
            line = line.strip()
            line = line.split(",")

            # create a property object
            utility = line[self.__boardCSV["space"]] == "Utility"
            railroad = line[self.__boardCSV["space"]] == "Railroad"
            sq = gamesquare.GameSquare(name=line[self.__boardCSV["name"]], price=int(line[self.__boardCSV["price"]]),
                                      rent=int(line[self.__boardCSV["rent"]]), color=line[self.__boardCSV["color"]],
                                      is_utility=utility, is_railroad=railroad, space=line[self.__boardCSV["space"]])
            properties.append(sq)
        f.close()

        return properties

    def __str__(self):
        board_str = "Current Board:\n"

        board_str = "player - cash - net worth - position\n"
        board_str += f"{self.__current_player} "
        board_str += f"{self.get_board_square(self.__current_player.position).name}\n"


        player_positions = {}
        for player in self.__players + [self.__current_player]:
            if not player.bankrupt_declared:
                player_positions.setdefault(player.position, []).append(player.token)

        for i, square in enumerate(self.__properties):
            board_str += f"\n{i:2d}: {square.name}"
            if i in player_positions:
                board_str += " " + " ".join(player_positions[i])
        board_str += "\n\nCurrent Chat:\n"
        board_str += str(self.chat)
        return board_str

        for player in self.__players:
            if player.bankrupt_declared:
                board_str += f"{player.name} declared bankruptcy\n"
                continue
            board_str += f"{player} "
            board_str += f"{self.get_board_square(player.position).name}\n"

        return board_str

