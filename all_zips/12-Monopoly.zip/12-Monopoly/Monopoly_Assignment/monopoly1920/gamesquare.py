import player
import gameboard

class GameSquare:
    def __init__(self, name, price, rent, space, color, is_utility, is_railroad):
        """Constructor for the GameSquare class"""
        self.__name = name
        self.__price = price
        self.__rent = rent
        self.__color = color
        self.__space = space
        self.__is_utility = is_utility
        self.__is_railroad = is_railroad
        self.__owner = None

        # Mortgage attribute
        self.__is_mortgaged = False

        # House and hotel attributes
        self.__house_count = 0
        self.__hotel_count = 0

    # Accessor methods
    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, owner):
        self.__owner = owner

    @property
    def house_count(self):
        return self.__house_count

    @property
    def hotel_count(self):
        return self.__hotel_count

    @property
    def is_mortgaged(self):
        return self.__is_mortgaged

    # New method to check if the owner has a monopoly
    def has_monopoly(self):
        if not self.owner:
            return False
        properties_in_group = [sq for sq in gameboard.get_squares_by_color(self.color)]
        return all(sq.owner == self.owner for sq in properties_in_group)

    # Charge double rent if monopoly is held but no buildings
    def calculate_rent_or_tax(self, dice_sum):
        """Function to calculate rent or tax for a square"""
        if self.owner is None and self.space != "Tax" or self.__is_mortgaged:
            return 0
        if self.is_utility:
            return 4 * dice_sum
        if self.is_railroad:
            return 25 * (2 ** (self.owner.railroad_count - 1))
        if self.has_monopoly() and self.house_count == 0 and self.hotel_count == 0:
            return self.__rent * 2
        return self.__rent

    # Allow purchasing houses
    def buy_house(self):
        """Function to buy a house if the player has a monopoly"""
        if self.has_monopoly() and self.house_count < 4 and not self.__is_mortgaged:
            house_price = self.price // 2  # Example pricing
            if self.owner.money >= house_price:
                self.owner.money -= house_price
                self.__house_count += 1
                return True
        return False

    # Allow upgrading to a hotel
    def buy_hotel(self):
        """Function to upgrade to a hotel if player has 4 houses"""
        if self.__house_count == 4 and self.__hotel_count == 0 and not self.__is_mortgaged:
            hotel_price = self.price  # Example pricing
            if self.owner.money >= hotel_price:
                self.owner.money -= hotel_price
                self.__house_count = 0
                self.__hotel_count = 1
                return True
        return False

    def auction_property(self):
        """Function to handle auctions when a property is declined"""
        print(f"Auctioning {self.name}...")
        # Implement bidding logic here

    def __str__(self):
        """Function to return a string representation of the GameSquare object"""
        return f"{self.name} - ${self.price} - Rent: ${self.rent} - Houses: {self.house_count} - Hotel: {self.hotel_count}"

