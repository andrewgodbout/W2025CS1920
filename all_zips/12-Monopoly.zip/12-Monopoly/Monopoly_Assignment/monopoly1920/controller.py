import os
import view
import random
import gameboard
import player as plr  # avoid naming conflict with the player module
import gamesquare
import observer


class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root, csv_path: str, num_players: int = 3):
        super().__init__()
        self._view = view.View(root)
        self._gameboard = gameboard.GameBoard(csv_path, self._create_players(num_players))
        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()

    def _add_listeners(self) -> None:
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _create_players(self, num_players: int) -> list[plr.Player]:
        """Create num_players players and return a list of them"""
        return [plr.Player(f"Player {i}", 1500) for i in range(num_players)]

    def _set_expected_val(self) -> None:
        player = self._gameboard.get_current_player()
        ev = round(self._gameboard.calculate_expected_value(player.position, 0), 2)
        observer.Event("update_state", f"Expected value: {ev}")
        player.luck += ev

    def _roll_dice(self) -> int:
        """Simulate rolling two dice"""
        dice1, dice2 = random.randint(1, 6), random.randint(1, 6)
        dice_sum = dice1 + dice2
        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            if self.__roll_count == 3:
                observer.Event("update_state", "Rolled three doubles! Go to Jail!")
                self._gameboard.get_current_player().go_to_jail()
                return 0
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")

        return dice_sum

    def _handle_roll_dice(self) -> bool:
        """Handle dice roll event"""
        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        if dice_sum == 0:  # Player sent to jail
            return False

        player.move(dice_sum)
        square = self._gameboard.get_square(player.position)
        rent = player.pay_rent(square, dice_sum)
        if rent > 0:
            observer.Event("update_state", f"Rent paid: {rent}")
            player.luck -= rent

        if player.money < 0:
            if player.can_mortgage_or_trade():
                observer.Event("update_state", "You are low on cash! Consider mortgaging or trading before bankruptcy.")
            else:
                player.declare_bankrupt()
                observer.Event("update_state", f"{player.name} has gone bankrupt!")

        return True

    def _end_player_turn(self, callback) -> None:
        """End the current player's turn"""
        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        self._set_expected_val()

    def _buy_square(self, data: dict) -> None:
        """Try to buy the square the active player is currently on"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)
        if player.buy_property(square):
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data: dict) -> None:
        player = self._gameboard.get_current_player()
        observer.Event("choice", [d.name for d in player.properties if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name: str) -> None:
        player = self._gameboard.get_current_player()
        if player.mortgage_property(deed_name):
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"Attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data: dict) -> None:
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name:
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button: str) -> None:
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data: dict) -> None:
        player = self._gameboard.get_current_player()
        if not self._handle_roll_dice():
            return
        square = self._gameboard.get_square(player.position)
        observer.Event("update_state", f"{player.name} landed on {square}.")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)





