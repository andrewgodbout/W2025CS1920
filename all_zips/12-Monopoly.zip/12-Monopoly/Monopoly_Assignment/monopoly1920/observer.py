#the following code draws inspiration
#from: https://stackoverflow.com/questions/1904351/python-observer-pattern-examples-tips

class Observer:
    """Observer class to represent an observer that can observe events"""

    # Static attribute to store all observers
    _observers = []

    def __init__(self):
        """Constructor for the Observer class"""
        self._observers.append(self)
        self._observables = {}  # Dictionary of event names and their callbacks

    def observe(self, event_name, callback):
        """Function to observe an event with multiple callbacks support"""
        if event_name not in self._observables:
            self._observables[event_name] = []
        self._observables[event_name].append(callback)

    def stop_observing(self, event_name):
        """Function to stop observing an event"""
        if event_name in self._observables:
            del self._observables[event_name]

    def remove_observer(self):
        """Function to remove an observer from the list"""
        if self in Observer._observers:
            Observer._observers.remove(self)

    @property
    def observables(self):
        return self._observables

    @staticmethod
    def get_observers():
        """Function to get all observers"""
        return Observer._observers

class Event:
    """Event class to represent an event that can be observed"""

    def __init__(self, event_name, data):
        """Constructor for the Event class"""
        self.__name = event_name
        self.__data = data
        print(f"Event created: {self.__name}")
        self.notify()

    def notify(self):
        """Function to fire the event"""
        for observer in Observer.get_observers():
            if self.__name in observer.observables:
                for callback in observer.observables[self.__name]:
                    callback(self.__data)




