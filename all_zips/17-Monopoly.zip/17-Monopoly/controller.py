import os
import view
import random
import gameboard
import player as plr  # avoid naming conflict with the player module
import gamesquare
import observer
import threading
import json

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False
        self.__roll_count = 0
        self.__timer = None
        self.__time_limit = 30  # Time limit in seconds
        self.__leaderboard = self._load_leaderboard()

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()
        self._start_turn_timer()

    def _start_turn_timer(self):
        """Start a timer for the player's turn."""
        if self.__timer:
            self.__timer.cancel()
        self.__timer = threading.Timer(self.__time_limit, self._force_end_turn)
        self.__timer.start()

    def _force_end_turn(self):
        """Automatically end the turn if the timer runs out."""
        observer.Event("update_state", "Time's up! Turn automatically ended.")
        self._end_player_turn(lambda: None)

    def _load_leaderboard(self):
        """Load the leaderboard from a JSON file."""
        if os.path.exists("leaderboard.json"):
            with open("leaderboard.json", "r") as file:
                return json.load(file)
        return {}

    def _save_leaderboard(self):
        """Save the leaderboard to a JSON file."""
        with open("leaderboard.json", "w") as file:
            json.dump(self.__leaderboard, file, indent=4)

    def _update_leaderboard(self, winner_name):
        """Update the leaderboard when a player wins."""
        if winner_name in self.__leaderboard:
            self.__leaderboard[winner_name] += 1
        else:
            self.__leaderboard[winner_name] = 1
        self._save_leaderboard()
        observer.Event("update_state", f"Leaderboard Updated: {self.__leaderboard}")

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")
        player = self._gameboard.get_current_player()
        player.luck += ev

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()
            remaining_players = [p for p in self._gameboard.players if not p.bankrupt_declared]
            if len(remaining_players) == 1:
                self._update_leaderboard(remaining_players[0].name)

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        if self.__timer:
            self.__timer.cancel()

        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return

        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()
        self._start_turn_timer()

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        observer.Event("update_state", f"{player.name} landed on {square}.")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)





