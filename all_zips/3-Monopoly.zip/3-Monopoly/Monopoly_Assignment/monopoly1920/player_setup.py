import tkinter as tk
from tkinter import ttk
import observer

class PlayerSetup:
    def __init__(self, root, num_players=3):
        self.root = root
        self.num_players = num_players
        self.players = []

        self._setup_ui()

    def _setup_ui(self):
        self.frame = ttk.Frame(self.root, padding=10)
        self.entries = []
        self.token_vars = []

        tokens = ["Dog", "Car", "Hat", "Ship", "Thimble", "Wheelbarrow"]

        for i in range(self.num_players):
            ttk.Label(self.frame, text=f"Player {i+1} Name:").grid(row=i, column=0)
            entry = ttk.Entry(self.frame)
            entry.grid(row=i, column=1)
            self.entries.append(entry)

            var = tk.StringVar(value=tokens[i])
            ttk.Label(self.frame, text="Token:").grid(row=i, column=2)
            dropdown = ttk.Combobox(self.frame, textvariable=var, values=tokens)
            dropdown.grid(row=i, column=3)
            self.token_vars.append(var)

        ttk.Button(self.frame, text="Start Game", command=self._start_game).grid(
            row=self.num_players, columnspan=4)

        self.frame.pack()

    def _start_game(self):
        for i in range(self.num_players):
            name = self.entries[i].get() or f"Player {i+1}"
            token = self.token_vars[i].get()
            self.players.append({"name": name, "token": token})

        observer.Event("players_ready", self.players)
        self.frame.destroy()
