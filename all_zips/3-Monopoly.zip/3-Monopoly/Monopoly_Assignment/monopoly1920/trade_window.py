import tkinter as tk
from tkinter import ttk

class TradeWindow:
    def __init__(self, root, player, other_player):
        self.root = root
        self.top = tk.Toplevel(root)
        self.top.title(f"Trade with {other_player.name}")

        self._setup_ui(player, other_player)

    def _setup_ui(self, player, other_player):
        # Left side - player's properties and money
        ttk.Label(self.top, text=f"{player.name}'s Offer").grid(row=0, column=0)

        # Right side - other player's properties and money
        ttk.Label(self.top, text=f"{other_player.name}'s Offer").grid(row=0, column=1)

        # Add property lists and money input fields
        # Add submit/cancel buttons
