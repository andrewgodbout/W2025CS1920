import json
from datetime import datetime

class GameSaver:
    @staticmethod
    def save_game(gameboard, filename=None):
        if not filename:
            filename = f"monopoly_save_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        game_state = {
            "players": [],
            "properties": [],
            "current_player_index": 0,
            "total_turns": gameboard._GameBoard__total_turns
        }

        # Save player data
        for player in gameboard._GameBoard__players:
            game_state["players"].append({
                "name": player._Player__name,
                "money": player._Player__money,
                "position": player._Player__board_position,
                "properties": [prop.name for prop in player._Player__properties],
                "bankrupt": player._Player__bankrupt_declared
            })

        # Save property data
        for prop in gameboard._GameBoard__properties:
            game_state["properties"].append({
                "name": prop._GameSquare__name,
                "owner": prop._GameSquare__owner._Player__name if prop._GameSquare__owner else None,
                "mortgaged": prop._GameSquare__is_mortgaged
            })

        with open(filename, 'w') as f:
            json.dump(game_state, f)

        return filename

class GameLoader:
    @staticmethod
    def load_game(filename, gameboard_class):
        with open(filename) as f:
            game_state = json.load(f)

        # Recreate players
        players = []
        for p_data in game_state["players"]:
            player = plr.Player(p_data["name"], p_data["money"])
            player._Player__board_position = p_data["position"]
            player._Player__bankrupt_declared = p_data["bankrupt"]
            players.append(player)

        # Create gameboard
        csv_path = os.path.join("resources", "data", "board.csv")
        gameboard = gameboard_class(csv_path, players)

        # Restore properties
        for prop_data in game_state["properties"]:
            for prop in gameboard._GameBoard__properties:
                if prop.name == prop_data["name"]:
                    if prop_data["owner"]:
                        owner = next(p for p in players if p.name == prop_data["owner"])
                        prop.owner = owner
                        owner._Player__properties.append(prop)
                    prop._GameSquare__is_mortgaged = prop_data["mortgaged"]

        # Set current player
        for _ in range(game_state["current_player_index"]):
            gameboard.next_turn()

        gameboard._GameBoard__total_turns = game_state["total_turns"]

        return gameboard
