import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import tkinter.simpledialog as simpledialog

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)

        self._gameboard = gameboard.GameBoard(csv_path, players)


        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        self.__doubles_rolled = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("use_jail_free_card", self._use_jail_free_card)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")


    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player_name = simpledialog.askstring("Player Name", f"Enter name for Player {i + 1}:")
            if player_name:  # If the player provided a name
                player = plr.Player(player_name, 1500)
            else:  # If no name was provided, use a default name
                player = plr.Player(f"Player {i + 1}", 1500)

            players.append(player)
        #    name = input(f"Enter player {i} name: ")
        #    player = plr.Player(name, 1500)
        #    players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)

        dice1 = 3
        dice2 = 4

        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            self.__doubles_rolled += 1
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
            if self.__doubles_rolled == 3:
                player = self._gameboard.get_current_player()
                observer.Event("update_state",f"{player.name} must go to jail for rolling doubles three times in a row")
                self.jail()
                self.__doubles_rolled = 0
                self.__dice_rolled = False
                self._end_player_turn(lambda: None)
                return 0
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
            self.__doubles_rolled = 0
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        if dice_sum == 0:  # If the return value is 0, that means the player was sent to jail.
            return False

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        if position == 30:
            print(f"{player.name} landed on Go to Jail!")
            self.jail()

        if position == 7 or position == 22 or position == 36:
            observer.Event("update_state", f"{player.name} landed on a Chance square!")
            draw_chance_card(player)

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    def jail(self):
        player = self._gameboard.get_current_player()
        player.position = 10  # Move the player to jail (position 10)
        observer.Event("update_state", f"{player.name} is in jail!")

    def _action_taken(self, action):
        print(f"Action received: {action}")
        if action == "use_jail_free_card":
            self._use_jail_free_card()

    def _use_jail_free_card(self):
        print("Use Jail Free Card")
        player = self._gameboard.get_current_player()

        if player.jail_free_card and self._gameboard.get_current_player().position == 10:
            player.jail_free_card = False
            player.move(10)
            observer.Event("update_state", f"{player.name} used a Get Out of Jail Free card!")
        else:
            observer.Event("update_state", f"{player.name} cannot use the Get Out of Jail Free card.")

class ChanceCard:
    def __init__(self, description, effect):
        self.description = description
        self.effect = effect

    def apply_effect(self, player):
        self.effect(player)

def effect_move_ahead(player):
    player.move(5)
    observer.Event("update_state", f"{player.name} moved to position 5 due to Chance card!")

def effect_money(player):
    amount = 100
    player.money += amount
    observer.Event("update_state", f"{player.name} received {amount} from a Chance card.")


def effect_pay_rent(player):
    amount = 50
    player.money -= amount
    observer.Event("update_state", f"{player.name} paid {amount} from a Chance card.")


def effect_get_out_of_jail(player):
    player.jail_free_card = True
    observer.Event("update_state", f"{player.name} now had a get out of jail free card.")

chance_cards = [ChanceCard("Move to square 5", effect_move_ahead), ChanceCard("Receive $100", effect_money), ChanceCard("Pay $50", effect_pay_rent), ChanceCard("Get out of jail free", effect_get_out_of_jail)]


def draw_chance_card(player):
    #card = chance_cards[3]
    card = random.choice(chance_cards)
    observer.Event("update_state", f"Chance card: {card.description}")
    card.apply_effect(player)


