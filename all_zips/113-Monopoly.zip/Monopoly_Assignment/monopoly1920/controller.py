import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import random
#Walkthrough 5: Chance and Community cards
CHANCE_CARDS = [
    {"type": "money", "text": "Bank pays you dividend of $50", "value": 50},
    {"type": "jail", "text": "Go directly to Jail. Do not pass GO.", "value": 10},
    {"type": "move", "text": "Advance to GO", "value": 0},
    {"type": "money", "text": "Speeding fine. Pay $15", "value": -15},
    {"type": "free_jail", "text": "Get Out of Jail Free. Keep until needed.", "value": 0}
]

CHEST_CARDS = [
    {"type": "money", "text": "You inherit $100", "value": 100},
    {"type": "money", "text": "Doctor's fees. Pay $50", "value": -50},
    {"type": "jail", "text": "Go directly to Jail.", "value": 10},
    {"type": "move", "text": "Advance to GO", "value": 0},
    {"type": "free_jail", "text": "Get Out of Jail Free. Keep until needed.", "value": 0}
]

class Controller(observer.Observer):
    """Control the game flow"""

    #Walkthrough 1: modify init and make _start_game to prioritize asking names first before starting the game.
    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)
        self._view.get_player_names(3, self._start_game)

    def _start_game(self, names):
        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(names)  # Now this is a list of strings
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        # Walkthrough 2: Houses and Hotels
        self.observe("build_house", self._build_house)
        self.observe("sell_house", self._sell_house)
        # Walkthrough 4: Adding a suggest button
        self.observe("suggest", self._handle_suggestion)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, names):
        #Walkthrough 1: modify ^ to accept inputted player names
        """Create num_players players and return a list of them"""
        players = []
        for name in names:
            player = plr.Player(name, 1500)
            players.append(player)
        return players


    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        player = self._gameboard.get_current_player()

        # Walkthrough 6: Jail.
        if player.in_jail:
            if player.has_jail_free_card:
                player.has_jail_free_card = False
                player.in_jail = False
                player.jail_turns = 0
                observer.Event("update_state", f"{player.name} used a 'Get Out of Jail Free' card!")
                self.__dice_rolled = True
                self.__roll_count += 1

                # let them roll and move like a normal turn
                dice_sum = self._roll_dice()
                player.move(dice_sum)

                # Continue as normal
                square = self._gameboard.get_square(player.position)
                if square.space == "Chance":
                    self._draw_card("Chance")
                elif square.space == "Chest":
                    self._draw_card("Chest")

                rent = player.pay_rent(square, dice_sum)
                if rent != 0:
                    player.luck -= rent
                    observer.Event("update_state", f"Rent paid: {rent}")

                if player.money < 0:
                    player.declare_bankrupt()

                return True
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            dice_sum = dice1 + dice2

            observer.Event("update_state", f"In Jail: rolled {dice1} + {dice2}")

            self.__dice_rolled = True
            self.__roll_count += 1

            player.jail_turns += 1

            if dice1 == dice2:
                # Rolled doubles, get out
                player.in_jail = False
                player.jail_turns = 0
                observer.Event("update_state", f"{player.name} escapes Jail with doubles!")
                player.move(dice_sum)
            elif player.jail_turns >= 3:
                # Pay $50
                player.in_jail = False
                player.jail_turns = 0
                player.money -= 50
                observer.Event("update_state", f"{player.name} pays $50 and leaves Jail.")
                player.move(dice_sum)
            else:
                # Stay in jail
                observer.Event("update_state", f"{player.name} remains in Jail (turn {player.jail_turns}/3).")
                return True

        else:
            dice_sum = self._roll_dice()
            self.__dice_rolled = True
            self.__roll_count += 1

            player.move(dice_sum)

        position = player.position
        square = self._gameboard.get_square(position)

        #Walkthrough 5: Chance or Chest
        if square.space == "Chance":
            self._draw_card("Chance")
        elif square.space == "Chest":
            self._draw_card("Chest")


        # Pay rent
        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

    #Walkthrough 2: Houses and Hotels

    def _build_house(self, data):
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)

        if not player.can_build_on(square):
            observer.Event("update_state", f"Can't build here.")
            return

        house_cost = square.price // 2  # Example: half property price
        if player.money < house_cost:
            observer.Event("update_state", "Not enough money to build.")
            return

        if square.add_house():
            player.money -= house_cost
            observer.Event("update_state", f"Built house on {square.name}")
        else:
            observer.Event("update_state", f"Can't build more houses.")

    def _sell_house(self, data):
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)

        if square.owner != player or square.houses == 0:
            observer.Event("update_state", "No houses to sell here.")
            return

        refund = square.price // 4  # Half of half price
        if square.sell_house():
            player.money += refund
            observer.Event("update_state", f"Sold house on {square.name} for {refund}")

    # Walkthrough 4: Adding a suggest button
    def _handle_suggestion(self, data):
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)

        advice = self._generate_advice(player, square)

        observer.Event("update_state", f"Suggestion: {advice}")

    # Walkthrough 4: Adding a suggest button
    def _generate_advice(self, player, square):
        if square.owner is not None and square.owner != player:
            return "Already owned — you might have to owe rent."

        if square.owner == player:
            # You landed on your own property
            group_props = [p for p in player.properties if p.color == square.color]
            group_size = square.group_size

            if len(group_props) == group_size:
                # Player owns the whole group (monopoly)
                if square.houses < 4 and not square.hotel:
                    return f"You have a monopoly on {square.color}. Consider building houses."
                if square.hotel:
                    return f"You’ve already built a hotel here. Time to charge serious rent!"
                return f"You have a monopoly on {square.color}. Build evenly across the group."

            return "You own this, but not the full group yet. Try to trade!"

        if not square.can_be_purchased():
            return "This square can't be bought. Just passing through."

            # Property is unowned and available
        if player.money < square.price:
            return "You can't afford this property — save your cash."

        if square.is_utility:
            return "Utilities are high risk. Skip unless you want to gamble."

        if square.is_railroad:
            return "Railroads are strong — always a solid buy."

            # Specific logic for key spots
        if square.name == "Boardwalk":
            return "Boardwalk is powerful but expensive — only buy if you're cash-rich."
        if square.name == "Baltic Avenue":
            return "Baltic is cheap and can become deadly with houses. Good early buy."

            # General case
        return f"{square.name} looks like a good buy — go for it!"

    #Walkthrough 5: Chance and chest cards
    def _draw_card(self, deck_type):
        player = self._gameboard.get_current_player()
        deck = CHANCE_CARDS if deck_type == "Chance" else CHEST_CARDS
        card = random.choice(deck)

        observer.Event("update_state", f"{deck_type} Card: {card['text']}")

        if card["type"] == "money":
            player.money += card["value"]
            observer.Event("update_state",
                           f"{player.name} {'received' if card['value'] > 0 else 'paid'} ${abs(card['value'])}")
        elif card["type"] == "jail":
            self._send_to_jail(player)
        elif card["type"] == "move":
            player.position = card["value"]
            observer.Event("update_state", f"{player.name} moves to square {card['value']}")
        #Walkthrough 7: GOJFC
        elif card["type"] == "free_jail":
            player.has_jail_free_card = True
            observer.Event("update_state", f"{player.name} received a 'Get Out of Jail Free' card!")

        observer.Event("update_state_box", str(self._gameboard))

    #Walkthrough 6: Jail.
    def _send_to_jail(self, player):
        player.position = 10  # Jail square index
        player.in_jail = True
        player.jail_turns = 0
        observer.Event("update_state", f"{player.name} is sent to Jail!")

