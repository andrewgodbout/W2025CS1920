import player
import gameboard


class GameSquare:
    def __init__(self, name, price, rent, space, color, is_utility, is_railroad, build_cost=0, rent_levels=None, hotel_cost=0, group_size=3):
        """Constructor for the GameSquare class"""
        self.__name = name
        self.__price = price
        self.__rent = rent
        self.__color = color
        self.__space = space
        self.__is_utility = is_utility
        self.__is_railroad = is_railroad
        self.__owner = None
        #Walkthrough 2: HOUSES AND HOTELS
        self.__houses = 0
        self.__hotel = False
        self.__build_cost = build_cost
        self.__hotel_cost = hotel_cost
        self.__group_size = group_size
        self.__rent_levels = rent_levels if rent_levels else [0, 0, 0, 0, 0]

        #add an is_mortgaged attribute
        self.__is_mortgaged = False

    # accessor methods
    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, owner):
        self.__owner = owner

    @property
    def name(self):
        return self.__name

    @property
    def price(self):
        return self.__price

    @property
    def rent(self):
        return self.__rent

    @property
    def color(self):
        return self.__color

    @property
    def space(self):
        return self.__space

    @property
    def is_utility(self):
        return self.__is_utility

    @property
    def is_railroad(self):
        return self.__is_railroad

    @property
    def is_mortgaged(self):
        return self.__is_mortgaged

    # Walkthrough 2: HOUSES AND HOTELS

    @property
    def houses(self):
        return self.__houses

    @property
    def hotel(self):
        return self.__hotel

    @property
    def build_cost(self):
        return self.__build_cost

    @property
    def group_size(self):
        return self.__group_size

    def add_house(self):
        if self.__houses < 4 and not self.__hotel:
            self.__houses += 1
            return True
        return False

    def add_hotel(self):
        if self.__houses == 4:
            self.__houses = 0
            self.__hotel = True
            return True
        return False

    def sell_house(self):
        if self.__houses > 0:
            self.__houses -= 1
            return True
        return False

    def sell_hotel(self):
        if self.__hotel:
            self.__hotel = False
            self.__houses = 4
            return True
        return False

    #Add methods to mortgage and unmortgage a property
    #remember to add a 10% fee to unmortgage
    def mortgage(self):
        """Function to mortgage a property
        return True if mortgaging was successful and False otherwise"""
        amt = self.price // 2
        if not self.__is_mortgaged:
            self.__is_mortgaged = True
            self.owner.money += amt
            return True
        return False

    def unmortgage(self):
        """Function to unmortgage a property if the player has the money
        and the property is currently mortgaged
        return True if the unmortgage was successful and False otherwise"""
        # add a 10% fee to unmortgage
        amt = self.price // 2
        amt = amt + amt // 10

        if self.owner.money >= amt and self.__is_mortgaged:
            self.__is_mortgaged = False
            self.owner.money -= amt
            return True

        return False

    def can_be_purchased(self):
        """Function to determine if a square can be purchased"""
        if self.owner is None:
            if (self.space == "Tax" or self.space == "Chance" or self.space == "Chest"
                    or self.space == "GotoJail" or self.space == "Jail"
                    or self.space == "Parking" or self.space == "Go"):
                return False
            else:
                return True

    def calculate_rent_or_tax(self, dice_sum):
        """Function to calculate the rent or tax for a square"""

        if self.owner is None and self.space != "Tax" or self.__is_mortgaged:
            return 0
        if self.is_utility:
            return 4 * dice_sum
        if self.is_railroad:
            return 25 * (2 ** (self.owner.railroad_count - 1))

        # Walkthrough #2: Houses and hotels
        if self.__hotel:
            return self.__rent_levels[4]
        elif self.__houses > 0:
            return self.__rent_levels[self.__houses - 1]

        # Walkthrough #3: Charge Double Rent
        has_monopoly = False
        no_buildings = False

        if self.owner:
            same_color_props = [p for p in self.owner.properties if p.color == self.color]
            has_monopoly = len(same_color_props) == self.__group_size
            no_buildings = all(p.houses == 0 and not p.hotel for p in same_color_props)

        if has_monopoly and no_buildings:
            return self.__rent * 2

        return self.__rent

    def __str__(self):
        """Function to return a string representation of the GameSquare object"""
        return f"{self.name} - {self.price} - {self.rent} \nHouses: {self.__houses} Hotel: {self.__hotel}"
