import random


class MonopolyAI:
    def __init__(self, strategy="moderate"):
        self.strategy = strategy
        self.personality = {
            "risk_tolerance": 0.5 if strategy == "moderate" else 0.8,
            "property_aggression": 0.7 if strategy == "aggressive" else 0.4
        }

    def make_decision(self, game_state, current_player):
        current_square = game_state.board.get_square(current_player.position)

        if self._should_buy_property(current_player, current_square):
            return "buy"

        # Auction participation logic
        if self._should_bid_in_auction(current_player, game_state.auction):
            return f"bid {self._calculate_bid_amount(current_player, game_state.auction)}"

        # Default action
        return "end_turn"

    def _should_buy_property(self, player, square):
        """Decision matrix for property purchases"""
        if not square.can_be_purchased():
            return False

        buy_probability = self.personality['property_aggression'] * (
                1 - (player.money / 1500)
        )
        return random.random() < buy_probability

    def _should_bid_in_auction(self, player, auction):
        """Determine bidding behavior"""
        if auction.current_bid > player.money * 0.5:
            return False

        bid_chance = self.personality['risk_tolerance'] * (
                auction.property.price / 1000  # More interested in valuable properties
        )
        return random.random() < bid_chance

    def _calculate_bid_amount(self, player, auction):
        """Smart bidding within means"""
        max_bid = min(
            auction.current_bid * 1.2,
            player.money * 0.75
        )
        return round(max_bid / 10) * 10  # Round to nearest $10