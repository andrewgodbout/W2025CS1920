import player
import gameboard
import random
import csv
import os


class GameSquare:
    def __init__(self, name, price, rent, space, color, is_utility, is_railroad, is_jail=False):
        """Constructor for the GameSquare class"""
        self.__name = name
        self.__price = price
        self.__rent = rent
        self.__color = color
        self.__space = space
        self.__is_utility = is_utility
        self.__is_railroad = is_railroad
        self.__is_jail = is_jail
        self.__owner = None

        #add an is_mortgaged attribute
        self.__is_mortgaged = False

        self.__cards = []
        if self.space in ["Chance", "Chest"]:
            self._load_cards()

    def _load_cards(self):
        """Load cards from CSV file"""
        filename = "chance.csv" if self.space == "Chance" else "community_chest.csv"
        filepath = os.path.join("resources", "data", filename)

        cards = []
        try:
            with open(filepath, 'r') as f:
                # Skip header line
                next(f)
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    # Split the line safely
                    parts = line.split(',')
                    if len(parts) != 3:
                        continue

                    cards.append({
                        'text': parts[0],
                        'action': parts[1],
                        'amount': int(parts[2])
                    })

        except Exception as e:
            print(f"Error loading cards from {filepath}: {e}")
            # Provide default cards if loading fails
            cards = [
                {'text': 'Advance to Go', 'action': 'move', 'amount': 0},
                {'text': 'Bank error', 'action': 'collect', 'amount': 50}
            ]

        self.__cards = cards
        print(f"Loaded {len(cards)} cards for {self.space}")  # Debug print
    def draw_card(self):
        if not self.__cards:
            return None
        return random.choice(self.__cards)


    # accessor methods
    @property
    def owner(self):
        return self.__owner

    @property
    def is_jail(self):
        return self.__is_jail

    @owner.setter
    def owner(self, owner):
        self.__owner = owner

    @property
    def name(self):
        return self.__name

    @property
    def price(self):
        return self.__price

    @property
    def rent(self):
        return self.__rent

    @property
    def color(self):
        return self.__color

    @property
    def space(self):
        return self.__space

    @property
    def is_utility(self):
        return self.__is_utility

    @property
    def is_railroad(self):
        return self.__is_railroad

    @property
    def is_mortgaged(self):
        return self.__is_mortgaged

    #Add methods to mortgage and unmortgage a property
    #remember to add a 10% fee to unmortgage
    def mortgage(self):
        """Function to mortgage a property
        return True if mortgaging was successful and False otherwise"""
        amt = self.price // 2
        if not self.__is_mortgaged:
            self.__is_mortgaged = True
            self.owner.money += amt
            return True
        return False

    def unmortgage(self):
        """Function to unmortgage a property if the player has the money
        and the property is currently mortgaged
        return True if the unmortgage was successful and False otherwise"""
        # add a 10% fee to unmortgage
        amt = self.price // 2
        amt = amt + amt // 10

        if self.owner.money >= amt and self.__is_mortgaged:
            self.__is_mortgaged = False
            self.owner.money -= amt
            return True

        return False

    def can_be_purchased(self):
        """Function to determine if a square can be purchased"""
        if self.owner is None:
            if (self.space == "Tax" or self.space == "Chance" or self.space == "Chest"
                    or self.space == "GotoJail" or self.space == "Jail"
                    or self.space == "Parking" or self.space == "Go"):
                return False
            else:
                return True

    def calculate_rent_or_tax(self, dice_sum):
        """Function to calculate the rent or tax for a square"""

        if self.owner is None and self.space != "Tax" or self.__is_mortgaged:
            return 0
        if self.is_utility:
            return 4 * dice_sum
        if self.is_railroad:
            return 25 * (2 ** (self.owner.railroad_count - 1))

        return self.rent

    def __str__(self):
        """Function to return a string representation of the GameSquare object"""
        return f"{self.name} - {self.price} - {self.rent}"
