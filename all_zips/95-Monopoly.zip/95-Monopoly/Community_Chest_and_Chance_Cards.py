import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer


class Card:
    def __init__(self, description, action):
        self.description = description
        self.action = action  # This would be a function that modifies game state


class CardDeck:
    def __init__(self, card_type="chance"):
        self.cards = []
        self.discard = []
        self.card_type = card_type
        self._initialize_cards()

    def _initialize_cards(self):
        # Basic cards - you would expand this with all official cards
        if self.card_type == "chance":
            self.cards.append(Card("Advance to Go (Collect $200)", self._advance_to_go))
            self.cards.append(Card("Go to Jail", self._go_to_jail))
            self.cards.append(Card("Bank pays you dividend of $50",self._bank_pays_you_dividend_of_50))
            self.cards.append(Card("Make general repairs on all your property (75$ each)",self._make_general_repairs_on_all_your_property))
            self.cards.append(Card("Speeding fine $15", self._speeding_fine_15))
            self.cards.append(Card("Take a trip to Reading Railroad. If you pass Go, collect $200.", self._take_a_trip_to_reading_railroad))
            self.cards.append(Card("You have been elected Chairman of the Board. Pay each player $50", self._elected_Chairman_of_the_board))
            self.cards.append(Card("Your building loan matures. Collect $150",self._your_building_loan_matures))

        else:  # community chest
            self.cards.append(Card("Bank error in your favor. Collect $200", self._bank_error))
            self.cards.append(Card("Advance to Go (Collect $200)", self._advance_to_go))
            self.cards.append(Card("Doctor’s fee. Pay $50", self._doctor_fee))
            self.cards.append(Card("From sale of stock you get $50", self._from_sale_of_stock_you_get))
            self.cards.append(Card("Get Out of Jail Free", self._get_out_of_jail_free))
            self.cards.append(Card("Go to Jail", self._go_to_jail))
            self.cards.append(Card("Holiday fund matures. Receive $100", self._holiday_fund_matures))
            self.cards.append(Card("Income tax refund", self._income_tax_refund))
            self.cards.append(Card("It is your birthday. Collect $10 from every player", self._it_is_your_birthday))
            self.cards.append(Card("You inherit $100", self._you_inherit))
            self.cards.append(Card("Pay hospital fees of $100", self._hospital_fees))
            self.cards.append(Card("Pay school fees of $50", self._school_fees))

        random.shuffle(self.cards)

    def draw(self):
        if not self.cards:
            self.cards, self.discard = self.discard, []
            random.shuffle(self.cards)
        return self.cards.pop()

    # Card actions
    def _holiday_fund_matures(self,player,gameboard):
        player.money+=100

    def _doctor_fee(self,player,gameboard):
        player.money-=50

    def _from_sale_of_stock_you_get(self,player,gameboard):
        player.money-=50
    def _income_tax_refund(self,player,gameboard):
        player.collect(20)

    def _it_is_your_birthday(self,player,gameboard):
        player.money+= (len(gameboard.players)-1)*10
        for contestant in gameboard.players:
            if player != contestant:
               contestant.money-=10

    def _you_inherit(self,player,gameboard):
        player.money+=100

    def _hospital_fees(self,player,gameboard):
        player.money-=100

    def _school_fees(self,player,gameboard):
        player.money-=50

    def _advance_to_go(self, player, gameboard):
        player.position = 0
        player.collect(200)

    def _bank_error(self, player, gameboard):
        player.collect(200)

    def _bank_pays_you_dividend_of_50(self,player,gameboard):
        player.collect(50)

    def _get_out_of_jail_free(self,player,gameboard):
        player.add_get_out_of_jail_card()

    def _go_to_jail(self,player,gameboard):
        player.send_to_jail()

    def _go_back_3_spaces(self,player,gameboard):
        player.move(-3)

    def _speeding_fine_15(self,player,gameboard):
        player.money-=15

    def _your_building_loan_matures(self,player,gameboard):
        player.collect(150)

    def _elected_Chairman_of_the_board(self,player,gameboard):
        for contestant in gameboard.players():
            if player.money>0:
                if player != contestant:
                    contestant.collect(50)
                    player.money-=50
            else:
                player.declare_bankrupt()

    def _make_general_repairs_on_all_your_property(self,player,gameboard):
        """$75 each"""
        for _ in player.properties:
            if player.money>0:
               player.money-=75
            else:
                player.declare_bankrupt()

    def _take_a_trip_to_reading_railroad(self,player,gameboard):
        if player.position > 5:
            player.collect(200)
            player.position=5
        else:
            player.position=5

