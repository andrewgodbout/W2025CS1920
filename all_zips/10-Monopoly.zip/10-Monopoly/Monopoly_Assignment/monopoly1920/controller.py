import os
import view
import random
import gameboard
import player as plr  # avoid naming conflict with the player module
import gamesquare
import observer
from tkinter import simpledialog

# --- Card Feature Integration ---
CHANCE_CARDS = [
    {
        "description": "Advance to Go (Collect $200)",
        "action": "advance_to_go",
        "amount": 200
    },
    {
        "description": "Bank pays you dividend of $50",
        "action": "collect_money",
        "amount": 50
    },
    {
        "description": "Go back 3 spaces",
        "action": "go_back",
        "spaces": 3
    },
    {
        "description": "Go to Jail. Do not pass Go, do not collect $200",
        "action": "go_to_jail"
    }
]

COMMUNITY_CHEST_CARDS = [
    {
        "description": "Doctor's fees – Pay $50",
        "action": "pay_money",
        "amount": 50
    },
    {
        "description": "From sale of stock you get $50",
        "action": "collect_money",
        "amount": 50
    },
    {
        "description": "Advance to Go (Collect $200)",
        "action": "advance_to_go",
        "amount": 200
    },
    {
        "description": "Go to Jail. Do not pass Go, do not collect $200",
        "action": "go_to_jail"
    }
]

def draw_card(card_type):
    if card_type == "Chance":
        return random.choice(CHANCE_CARDS)
    elif card_type == "Community Chest":
        return random.choice(COMMUNITY_CHEST_CARDS)
    else:
        return None

def apply_card_effect(card, player, gameboard_instance):
    if card is None:
        return
    action = card.get("action")
    if action == "advance_to_go":
        player.position = 0
        player.money += card.get("amount", 0)
    elif action == "collect_money":
        player.money += card.get("amount", 0)
    elif action == "pay_money":
        player.money -= card.get("amount", 0)
    elif action == "go_back":
        spaces = card.get("spaces", 0)
        player.position = max(0, player.position - spaces)
    elif action == "go_to_jail":
        player.position = 10  # send player to jail
        player.in_jail = True

class Controller(observer.Observer):
    TIMER_SECONDS = 30  # seconds allowed per turn

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)
        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players()
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__consecutive_doubles = 0  # For tracking consecutive doubles
        self.timer_id = None  # For scheduled timer callbacks

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()
        self.start_move_timer(self.TIMER_SECONDS)

    def _add_listeners(self):
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _create_players(self):
        """
        Prompt the user for the number of players (min 2, max 5).
        Continue prompting until a valid number is entered.
        Then, for each player, prompt for their name and have them choose a token.
        """
        while True:
            players_input = simpledialog.askstring("Number of Players",
                "Enter number of players (min 2, max 5):", parent=self._view.root)
            try:
                num_players = int(players_input)
                if 2 <= num_players <= 5:
                    break
                else:
                    observer.Event("update_state", "Number not in range. Please enter a number between 2 and 5.")
            except (TypeError, ValueError):
                observer.Event("update_state", "Invalid input. Please enter a number between 2 and 5.")

        # Define token options (actual emoji characters)
        tokens = {
            "1": "♟",  # Pawn
            "2": "🚗",  # Car
            "3": "🐶",  # Dog
            "4": "🐱",  # Cat
            "5": "🌟"   # Star
        }
        token_options = "\n".join([f"{key}. {value}" for key, value in tokens.items()])

        players = []
        for i in range(num_players):
            name = simpledialog.askstring("Player Name", f"Enter name for Player {i+1}:", parent=self._view.root)
            if not name:
                name = f"Player {i+1}"
            token_choice = simpledialog.askstring("Token Choice",
                                                  f"Choose your token by entering the corresponding number (1-5):\n{token_options}",
                                                  parent=self._view.root)
            token = tokens.get(token_choice, "♟")  # default to Pawn if invalid
            player = plr.Player(name, 1500)
            player.token = token
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")
        player = self._gameboard.get_current_player()
        player.luck += ev

    def start_move_timer(self, seconds):
        if self.timer_id is not None:
            self._view.root.after_cancel(self.timer_id)
        self._update_timer(seconds)

    def _update_timer(self, remaining):
        self._view.update_timer(remaining)
        if remaining > 0:
            self.timer_id = self._view.root.after(1000, self._update_timer, remaining - 1)
        else:
            observer.Event("update_state", "Time is up! Ending turn.")
            self._auto_end_turn()

    def _auto_end_turn(self):
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__consecutive_doubles = 0
        self._end_player_turn(lambda: None, auto_end=True)
        self.start_move_timer(self.TIMER_SECONDS)

    def _roll_dice(self):
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2
        self.__dice_rolled = True
        self.__roll_count += 1
        if dice1 == dice2:
            self.__consecutive_doubles += 1
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
        else:
            self.__consecutive_doubles = 0
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        if self.__consecutive_doubles == 3:
            observer.Event("update_state", f"{player.name} rolled doubles three times and is sent to jail!")
            player.position = 10
            player.in_jail = True
            self.__consecutive_doubles = 0
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", player.position)
            return True

        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)
        if square.name == "GotoJail":
            observer.Event("update_state", f"{player.name} landed on Go to Jail! Moving to Jail.")
            player.position = 10
            player.in_jail = True
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", player.position)
            return True

        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        if square.name in ["Chance", "Community Chest"]:
            card = draw_card(square.name)
            observer.Event("update_state", f"Card drawn: {card['description']}")
            apply_card_effect(card, player, self._gameboard)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
        return True

    def _end_player_turn(self, callback, auto_end=False):
        if not self.__dice_rolled and not auto_end:
            observer.Event("update_state", "Roll the dice first")
            return
        if self.timer_id is not None:
            self._view.root.after_cancel(self.timer_id)
            self.timer_id = None
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__consecutive_doubles = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        self._set_expected_val()
        self.start_move_timer(self.TIMER_SECONDS)

    def _buy_square(self, data):
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        player = self._gameboard.get_current_player()
        deeds = player.properties
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"Attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()
        # --- Jail Check: If player is in jail, require them to pay $50 to get out ---
        if player.in_jail:
            if player.money >= 50:
                player.money -= 50
                observer.Event("update_state", f"{player.name} pays $50 to get out of jail.")
            else:
                observer.Event("update_state", f"{player.name} cannot afford $50 to get out of jail and remains in jail.")
                return
            player.in_jail = False
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", player.position)
        # -------------------------------------------------------------------------
        if not self._handle_roll_dice():
            return
        square = self._gameboard.get_square(player.position)
        msg = f"{player.name} landed on {square}."
        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
