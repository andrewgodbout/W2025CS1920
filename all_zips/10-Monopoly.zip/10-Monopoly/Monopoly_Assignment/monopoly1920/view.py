import tkinter as tk
import os
from tkinter import ttk
import controller
import observer

def get_board_square_images():
    """Return a list of all the file paths for the board square images."""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View(observer.Observer):
    """Class to create the GUI for the Monopoly game."""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        self.images = []  # Preloaded board square images
        self.root = root
        root.title("Monopoly 1920")
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)
        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

    def _add_listeners(self):
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)

    def _create_logo_frame(self):
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image
        return logo_frame

    def _create_middle_frame(self):
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        self.board_canvas = tk.Canvas(middle_frame, width=board_image.width(), height=board_image.height())
        self.board_canvas.create_image(0, 0, image=board_image, anchor='nw')
        self.board_canvas.image = board_image
        self.board_canvas.pack(side='left', anchor='n', padx=75)

        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)
        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        button_frame = ttk.Frame(middle_frame, padding=10)
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll"))
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        return middle_frame

    def _create_msg_frame(self):
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)
        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))
        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,100))
        # Timer label with yellow background for visibility.
        self.timer_label = ttk.Label(msg_frame, text="Time left: 30s", font=("Helvetica", 14), background="yellow")
        self.timer_label.pack(side='top', anchor='center', pady=5, fill=tk.X)
        return msg_frame

    def _action_taken(self, action):
        if action == "roll":
            print("roll clicked")
            observer.Event("roll", None)
        if action == "purchase":
            observer.Event("purchase", None)
        if action == "mortgage":
            observer.Event("mortgage", None)
        if action == "unmortgage":
            observer.Event("unmortgage", None)
        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)
        if action == "end_turn":
            observer.Event("end_turn", self._clear_text)

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        self.text_box.insert(tk.END, text + "\n")

    def update_card(self, index):
        if index < len(self.images):
            card_image = self.images[index]
            try:
                self.card['image'] = card_image
            except Exception:
                pass

    def _choose(self, choices):
        self.popup_menu = tk.Menu(self.root, tearoff=0)
        for c in choices:
            self.popup_menu.add_command(label=c, command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()
        lbl = "Cancel" if choices else "No properties to mortgage (click to cancel)"
        self.popup_menu.add_command(label=lbl, command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)

    def _preload_images(self):
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def update_timer(self, seconds):
        self.timer_label.config(text=f"Time left: {seconds}s")
        print(f"Timer update: {seconds}s")

'''Launch the GUI'''
if __name__ == '__main__':
    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()
    controller = controller.Controller(root)
    root.mainloop()
