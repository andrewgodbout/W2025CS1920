import random

# Sample Chance cards
CHANCE_CARDS = [
    {
        "description": "Advance to Go (Collect $200)",
        "action": "advance_to_go",
        "amount": 200
    },
    {
        "description": "Bank pays you dividend of $50",
        "action": "collect_money",
        "amount": 50
    },
    {
        "description": "Go back 3 spaces",
        "action": "go_back",
        "spaces": 3
    },
    {
        "description": "Go to Jail. Do not pass Go, do not collect $200",
        "action": "go_to_jail"
    }
]

# Sample Community Chest cards
COMMUNITY_CHEST_CARDS = [
    {
        "description": "Doctor's fees – Pay $50",
        "action": "pay_money",
        "amount": 50
    },
    {
        "description": "From sale of stock you get $50",
        "action": "collect_money",
        "amount": 50
    },
    {
        "description": "Advance to Go (Collect $200)",
        "action": "advance_to_go",
        "amount": 200
    },
    {
        "description": "Go to Jail. Do not pass Go, do not collect $200",
        "action": "go_to_jail"
    }
]


def draw_card(card_type):
    """
    Randomly draw a card from the specified deck.

    :param card_type: either "Chance" or "Community Chest"
    :return: a dictionary representing the drawn card.
    """
    if card_type == "Chance":
        return random.choice(CHANCE_CARDS)
    elif card_type == "Community Chest":
        return random.choice(COMMUNITY_CHEST_CARDS)
    else:
        return None


def apply_card_effect(card, player, gameboard):
    """
    Apply the effect of a drawn card to the player.

    :param card: the card dictionary drawn from the deck
    :param player: the player object to be affected
    :param gameboard: the gameboard instance (can be used for board-related actions)
    """
    if card is None:
        return

    action = card.get("action")

    if action == "advance_to_go":
        player.position = 0
        player.money += card.get("amount", 0)
    elif action == "collect_money":
        player.money += card.get("amount", 0)
    elif action == "pay_money":
        player.money -= card.get("amount", 0)
    elif action == "go_back":
        spaces = card.get("spaces", 0)
        # Ensure the position doesn't go negative; wrap around if desired.
        player.position = max(0, player.position - spaces)
    elif action == "go_to_jail":
        # Assume jail is at a fixed position, for example position 10.
        player.position = 10
    # Extend with additional actions as needed.
