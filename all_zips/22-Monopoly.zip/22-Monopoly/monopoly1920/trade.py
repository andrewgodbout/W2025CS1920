import tkinter as tk



class Trade:
    def __init__(self, parent, game_board):
        self.parent = parent
        self.trade_data = None
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Trade Properties")

        self.trade_gameboard = game_board
        self.current_player = self.trade_gameboard.get_current_player()
        self.all_players = self.trade_gameboard.get_all_players()

        self.selected_player = None
        self.create_initial_widgets()

        self.dialog.transient(parent)
        self.dialog.grab_set()
        parent.wait_window(self.dialog)

    def create_initial_widgets(self):
        tk.Label(self.dialog, text="Select Player to Trade With:").grid(row=0, column=0, padx=10, pady=10)

        self.to_player_var = tk.StringVar(self.dialog)
        self.to_player_var.set(self.all_players[0].name)
        self.to_player_menu = tk.OptionMenu(self.dialog, self.to_player_var,
                                            *[player.name for player in self.all_players])
        self.to_player_menu.grid(row=0, column=1, padx=10, pady=10)

        self.submit_player_button = tk.Button(self.dialog, text="Submit", command=self.select_player)
        self.submit_player_button.grid(row=1, column=0, columnspan=2, pady=10)

    def select_player(self):
        selected_player_name = self.to_player_var.get()
        self.selected_player = next(player for player in self.all_players if player.name == selected_player_name)

        # Clear existing widgets
        for widget in self.dialog.winfo_children():
            widget.destroy()

        # Show trade details now
        self.create_trade_widgets()
        self.update_properties()

    def create_trade_widgets(self):
        tk.Label(self.dialog, text=f"{self.current_player.name} Offers:").grid(row=0, column=0, padx=10, pady=10)
        tk.Label(self.dialog, text=f"{self.selected_player.name} Gives:").grid(row=0, column=1, padx=10, pady=10)

        tk.Label(self.dialog, text="Properties to Offer:").grid(row=1, column=0, padx=10, pady=5)
        self.offer_properties_entry = tk.Entry(self.dialog)
        self.offer_properties_entry.grid(row=2, column=0, padx=10, pady=5)

        tk.Label(self.dialog, text="Properties Requested:").grid(row=1, column=1, padx=10, pady=5)
        self.request_properties_entry = tk.Entry(self.dialog)
        self.request_properties_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(self.dialog, text="Money to Offer:").grid(row=3, column=0, padx=10, pady=5)
        self.offer_money_entry = tk.Entry(self.dialog)
        self.offer_money_entry.grid(row=4, column=0, padx=10, pady=5)

        tk.Label(self.dialog, text="Money Requested:").grid(row=3, column=1, padx=10, pady=5)
        self.request_money_entry = tk.Entry(self.dialog)
        self.request_money_entry.grid(row=4, column=1, padx=10, pady=5)

        self.current_player_info = tk.Label(self.dialog, text="")
        self.current_player_info.grid(row=5, column=0, padx=10, pady=10)

        self.selected_player_info = tk.Label(self.dialog, text="")
        self.selected_player_info.grid(row=5, column=1, padx=10, pady=10)

        self.submit_trade_button = tk.Button(self.dialog, text="Submit Trade", command=self.submit)
        self.submit_trade_button.grid(row=6, column=0, columnspan=2, pady=10)

    def update_properties(self):
        self.current_player_info.config(
            text=f"{self.current_player.name} - Properties: {', '.join(p.name for p in self.current_player.properties)} | Money: {self.current_player.money}")

        self.selected_player_info.config(
            text=f"{self.selected_player.name} - Properties: {', '.join(p.name for p in self.selected_player.properties)} | Money: {self.selected_player.money}")

    def submit(self):
        offer_properties = self.offer_properties_entry.get().split(',')
        request_properties = self.request_properties_entry.get().split(',')
        offer_money = int(self.offer_money_entry.get()) if self.offer_money_entry.get().isdigit() else 0
        request_money = int(self.request_money_entry.get()) if self.request_money_entry.get().isdigit() else 0

        self.trade_data = {
            "to": self.selected_player.name,
            "offer_properties": offer_properties,
            "offer_money": offer_money,
            "request_properties": request_properties,
            "request_money": request_money
        }
        self.dialog.destroy()
