import random

class Card:
    def __init__(self, description, action_type, value=0):
        self.description = description
        self.action_type = action_type
        self.value = value

class ChanceCard(Card):
    pass

class CommunityChestCard(Card):
    pass

# Define Chance cards
chance_cards = [
    ChanceCard("Advance to Go (Collect $200)", "advance", 0),
    ChanceCard("Pay $50 in taxes", "pay", 50),
    ChanceCard("Move forward 3 spaces", "move", 3),
    ChanceCard("Receive $100 from the bank", "bonus", 100)
]

# Define Community Chest cards
community_chest_cards = [
    CommunityChestCard("You have won a beauty contest, collect $150", "bonus", 150),
    CommunityChestCard("Go directly to jail. Do not pass Go. Do not collect $200.", "jail", 0),
    CommunityChestCard("Pay $100 in medical expenses", "pay", 100),
    CommunityChestCard("You have been audited, pay $200", "pay", 200)
]

def get_card(card_type):
    """Draw a random card from Chance or Community Chest"""
    if card_type == "Chance":
        return random.choice(chance_cards)
    elif card_type == "Community Chest":
        return random.choice(community_chest_cards)