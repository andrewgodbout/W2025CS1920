import os
import view
import random
import gameboard
import player as plr
import gamesquare
import observer
import jail_handler
import card_deck
import property_manager


class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        # Initialize new components
        self.jail_handler = jail_handler.JailHandler(self._gameboard)
        self.property_manager = property_manager.PropertyManager(self._gameboard)
        self.card_deck = card_deck.CardDeck(self.jail_handler, self._gameboard)

        self._add_listeners()

        self.__dice_rolled = False
        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

        # Add new listeners
        self.observe("pay_jail", self._pay_jail_fee)
        self.observe("build_house", self._build_house)
        self.observe("sell_house", self._sell_house)

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")
        player = self._gameboard.get_current_player()
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values and the individual dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            # Double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")

            # Check for 3 doubles in a row
            player = self._gameboard.get_current_player()
            player.doubles_count += 1

            if player.doubles_count >= 3:
                observer.Event("update_state", f"{player.name} rolled doubles 3 times in a row!")
                self.jail_handler.send_to_jail(player)
                player.doubles_count = 0
                self.__dice_rolled = True  # End turn after going to jail
                return dice_sum, dice1, dice2

            self.__dice_rolled = False  # Allow another roll for doubles
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
            # Reset doubles count
            player = self._gameboard.get_current_player()
            player.doubles_count = 0

        return dice_sum, dice1, dice2

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""
        player = self._gameboard.get_current_player()

        # Check if player is in jail
        if player in self.jail_handler.players_in_jail:
            dice_sum, dice1, dice2 = self._roll_dice()
            got_out = self.jail_handler.handle_jail_turn(player, dice1, dice2)

            if got_out and dice1 == dice2:
                # Player got out with doubles, allow movement
                player.move(dice_sum)
                position = player.position
                square = self._gameboard.get_square(position)
                self._handle_square_landed_on(square, dice_sum)

            return got_out

        if self.__dice_rolled:
            # Only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum, dice1, dice2 = self._roll_dice()

        # Move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        # Handle special squares
        if position == self.jail_handler.go_to_jail_position:
            self.jail_handler.handle_go_to_jail_square(player)
            return True

        self._handle_square_landed_on(square, dice_sum)
        return True

    def _handle_square_landed_on(self, square, dice_sum):
        """Handle the effects of landing on a square"""
        player = self._gameboard.get_current_player()

        # Handle Chance and Community Chest
        if square.space == "Chance":
            self.card_deck.draw_chance_card(player)
            return

        if square.space == "Chest":
            self.card_deck.draw_community_chest_card(player)
            return

        # Pay rent with monopoly consideration
        rent = self.property_manager.calculate_rent_with_monopoly(square, dice_sum)
        if rent != 0:
            player.money -= rent
            if square.owner:
                square.owner.money += rent
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        # Check for bankruptcy
        if player.money < 0:
            player.declare_bankrupt()
            observer.Event("update_state", f"{player.name} has gone bankrupt!")

    def _end_player_turn(self, callback):
        """End the current player's turn"""
        player = self._gameboard.get_current_player()

        if not self.__dice_rolled and player not in self.jail_handler.players_in_jail:
            # Player must roll the dice first unless in jail
            observer.Event("update_state", "Roll the dice first")
            return

        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """Try to buy the square the active player is currently on"""
        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return

        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)

        if buy:
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")

            # Could implement auction here

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # Only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"Attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property"""
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def _pay_jail_fee(self, data):
        """Pay the $50 fee to get out of jail"""
        player = self._gameboard.get_current_player()
        success = self.jail_handler.pay_to_get_out(player)
        if success:
            observer.Event("update_state", f"{player.name} paid $50 to get out of jail")
        else:
            observer.Event("update_state", f"{player.name} cannot pay to get out of jail")

    def _build_house(self, data):
        """Build a house on a property"""
        player = self._gameboard.get_current_player()

        # Get player's monopolies
        monopolies = self.property_manager.get_player_monopolies(player)

        if not monopolies:
            observer.Event("update_state", "You don't have any monopolies to build on")
            return

        # Show properties where houses can be built
        buildable_properties = []
        for color in monopolies:
            for square in self.property_manager.color_groups[color]:
                if self.property_manager.can_build_house(player, square):
                    buildable_properties.append(square.name)

        if buildable_properties:
            observer.Event("choice", buildable_properties)
        else:
            observer.Event("update_state", "No properties available for building")

    def _sell_house(self, data):
        """Sell a house from a property"""
        player = self._gameboard.get_current_player()

        # In a real implementation, we would check which properties have houses
        # For simplicity, we'll just allow selling from any property

        observer.Event("choice", [p.name for p in player.properties])

    def _roll_action(self, data):
        """Handle the roll action"""
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

