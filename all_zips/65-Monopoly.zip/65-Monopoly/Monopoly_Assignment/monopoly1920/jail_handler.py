import random
import observer


class JailHandler:
    """Handle jail-related game mechanics"""

    def __init__(self, gameboard):
        self.gameboard = gameboard
        self.jail_position = 10  # Standard Monopoly jail position
        self.go_to_jail_position = 30  # Standard Monopoly "Go To Jail" position
        self.players_in_jail = {}  # Dictionary to track players in jail and their turns
        self.get_out_of_jail_cards = {
            "chance": [],
            "community_chest": []
        }

    def send_to_jail(self, player):
        """Send a player to jail"""
        player.position = self.jail_position
        self.players_in_jail[player] = 0  # Initialize turns in jail
        observer.Event("update_state", f"{player.name} was sent to jail!")

    def handle_go_to_jail_square(self, player):
        """Handle when a player lands on the Go To Jail square"""
        self.send_to_jail(player)
        return True

    def handle_jail_turn(self, player, dice1, dice2):
        """Handle a player's turn when they are in jail
        Returns True if the player gets out of jail, False otherwise"""

        if player not in self.players_in_jail:
            return True  # Player is not in jail

        # Increment turns in jail
        self.players_in_jail[player] += 1

        # Check if player rolled doubles
        if dice1 == dice2:
            observer.Event("update_state", f"{player.name} rolled doubles and got out of jail!")
            del self.players_in_jail[player]
            return True

        # Check if player has been in jail for 3 turns
        if self.players_in_jail[player] >= 3:
            # Force payment after 3 turns
            player.money -= 50
            observer.Event("update_state", f"{player.name} paid $50 after 3 turns in jail")
            del self.players_in_jail[player]
            return True

        # Player stays in jail
        observer.Event("update_state", f"{player.name} is still in jail ({self.players_in_jail[player]}/3 turns)")
        return False

    def pay_to_get_out(self, player):
        """Player pays $50 to get out of jail"""
        if player in self.players_in_jail and player.money >= 50:
            player.money -= 50
            del self.players_in_jail[player]
            observer.Event("update_state", f"{player.name} paid $50 to get out of jail")
            return True
        return False

    def use_get_out_of_jail_card(self, player, card_type):
        """Use a Get Out of Jail Free card"""
        if player in self.players_in_jail and card_type in self.get_out_of_jail_cards:
            if len(self.get_out_of_jail_cards[card_type]) > 0:
                # Return the card to the bottom of the deck
                card = self.get_out_of_jail_cards[card_type].pop(0)
                del self.players_in_jail[player]
                observer.Event("update_state", f"{player.name} used a Get Out of Jail Free card")
                return True
        return False

