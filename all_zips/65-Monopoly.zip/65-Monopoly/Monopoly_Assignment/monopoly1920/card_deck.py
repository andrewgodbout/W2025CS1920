import random
import observer


class Card:
    """Represents a Chance or Community Chest card"""

    def __init__(self, title, action, value=0):
        self.title = title
        self.action = action  # Function to call when card is drawn
        self.value = value  # Value associated with the card (money amount, etc.)

    def __str__(self):
        return self.title


class CardDeck:
    """Manages Chance and Community Chest card decks"""

    def __init__(self, jail_handler, gameboard):
        self.jail_handler = jail_handler
        self.gameboard = gameboard
        self.chance_cards = []
        self.community_chest_cards = []
        self._initialize_cards()
        self._shuffle_decks()

    def _initialize_cards(self):
        """Initialize the card decks with standard Monopoly cards"""
        # Chance cards
        self.chance_cards = [
            Card("Advance to Go", self._advance_to_go),
            Card("Advance to Illinois Avenue", lambda player: self._advance_to_position(player, 24)),
            Card("Advance to St. Charles Place", lambda player: self._advance_to_position(player, 11)),
            Card("Bank pays you dividend of $50", lambda player: self._collect_money(player, 50)),
            Card("Go to Jail", lambda player: self.jail_handler.send_to_jail(player)),
            Card("Get Out of Jail Free", self._get_jail_free_chance),
            Card("Go back 3 spaces", self._go_back_three),
            Card("Pay each player $50", self._pay_each_player_50),
            Card("Make general repairs on your property", lambda player: self._pay_repairs(player, 25, 100)),
            Card("Speeding fine $15", lambda player: self._pay_money(player, 15))
        ]

        # Community Chest cards
        self.community_chest_cards = [
            Card("Advance to Go", self._advance_to_go),
            Card("Bank error in your favor. Collect $200", lambda player: self._collect_money(player, 200)),
            Card("Doctor's fee. Pay $50", lambda player: self._pay_money(player, 50)),
            Card("From sale of stock you get $50", lambda player: self._collect_money(player, 50)),
            Card("Get Out of Jail Free", self._get_jail_free_community),
            Card("Go to Jail", lambda player: self.jail_handler.send_to_jail(player)),
            Card("Holiday fund matures. Receive $100", lambda player: self._collect_money(player, 100)),
            Card("Income tax refund. Collect $20", lambda player: self._collect_money(player, 20)),
            Card("Life insurance matures. Collect $100", lambda player: self._collect_money(player, 100)),
            Card("Pay hospital fees of $100", lambda player: self._pay_money(player, 100))
        ]

    def _shuffle_decks(self):
        """Shuffle both card decks"""
        random.shuffle(self.chance_cards)
        random.shuffle(self.community_chest_cards)

    def draw_chance_card(self, player):
        """Draw a card from the Chance deck"""
        if not self.chance_cards:
            self._shuffle_decks()

        card = self.chance_cards.pop(0)
        observer.Event("update_state", f"{player.name} drew Chance card: {card.title}")

        # Execute the card's action
        card.action(player)

        # Return the card to the bottom of the deck unless it's a Get Out of Jail Free card
        if "Get Out of Jail Free" not in card.title:
            self.chance_cards.append(card)

    def draw_community_chest_card(self, player):
        """Draw a card from the Community Chest deck"""
        if not self.community_chest_cards:
            self._shuffle_decks()

        card = self.community_chest_cards.pop(0)
        observer.Event("update_state", f"{player.name} drew Community Chest card: {card.title}")

        # Execute the card's action
        card.action(player)

        # Return the card to the bottom of the deck unless it's a Get Out of Jail Free card
        if "Get Out of Jail Free" not in card.title:
            self.community_chest_cards.append(card)

    # Card actions
    def _advance_to_go(self, player):
        """Advance to Go and collect $200"""
        old_position = player.position
        player.position = 0
        player.money += 200
        observer.Event("update_state", f"{player.name} advanced to Go and collected $200")

    def _advance_to_position(self, player, position):
        """Advance to a specific position"""
        old_position = player.position
        player.position = position

        # If passing Go, collect $200
        if position < old_position:
            player.money += 200
            observer.Event("update_state", f"{player.name} passed Go and collected $200")

    def _collect_money(self, player, amount):
        """Collect money from the bank"""
        player.money += amount
        observer.Event("update_state", f"{player.name} collected ${amount}")

    def _pay_money(self, player, amount):
        """Pay money to the bank"""
        player.money -= amount
        observer.Event("update_state", f"{player.name} paid ${amount}")

    def _get_jail_free_chance(self, player):
        """Get Out of Jail Free card from Chance"""
        self.jail_handler.get_out_of_jail_cards["chance"].append("Get Out of Jail Free")
        observer.Event("update_state", f"{player.name} received a Get Out of Jail Free card")

    def _get_jail_free_community(self, player):
        """Get Out of Jail Free card from Community Chest"""
        self.jail_handler.get_out_of_jail_cards["community_chest"].append("Get Out of Jail Free")
        observer.Event("update_state", f"{player.name} received a Get Out of Jail Free card")

    def _go_back_three(self, player):
        """Go back 3 spaces"""
        player.position = (player.position - 3) % 40
        observer.Event("update_state",
                       f"{player.name} moved back 3 spaces to {self.gameboard.get_square(player.position).name}")

    def _pay_each_player_50(self, player):
        """Pay each player $50"""
        players = self.gameboard._GameBoard__players  # Access the private attribute
        current_player = self.gameboard.get_current_player()

        total = len(players) * 50
        player.money -= total

        for p in players:
            if p != player:
                p.money += 50

        observer.Event("update_state", f"{player.name} paid each player $50 (total: ${total})")

    def _pay_repairs(self, player, house_cost, hotel_cost):
        """Pay for repairs on properties"""
        # In a real implementation, we would count houses and hotels
        # For simplicity, we'll just charge a flat fee
        player.money -= 50
        observer.Event("update_state", f"{player.name} paid $50 for property repairs")

