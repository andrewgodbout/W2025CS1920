import observer


class PropertyManager:
    """Manages property-related game mechanics like building houses/hotels"""

    def __init__(self, gameboard):
        self.gameboard = gameboard
        self.color_groups = self._initialize_color_groups()
        self.houses_available = 32  # Standard Monopoly has 32 houses
        self.hotels_available = 12  # Standard Monopoly has 12 hotels

    def _initialize_color_groups(self):
        """Initialize color groups from the game board"""
        color_groups = {}

        for square in self.gameboard.get_all_squares():
            if square.color and square.color != "None":
                if square.color not in color_groups:
                    color_groups[square.color] = []
                color_groups[square.color].append(square)

        return color_groups

    def has_monopoly(self, player, color):
        """Check if a player has a monopoly on a color group"""
        if color not in self.color_groups:
            return False

        for square in self.color_groups[color]:
            if square.owner != player:
                return False

        return True

    def get_player_monopolies(self, player):
        """Get all color groups where the player has a monopoly"""
        monopolies = []

        for color, squares in self.color_groups.items():
            if self.has_monopoly(player, color):
                monopolies.append(color)

        return monopolies

    def can_build_house(self, player, property_square):
        """Check if a player can build a house on a property"""
        if not property_square or not property_square.owner == player:
            return False

        color = property_square.color
        if not self.has_monopoly(player, color):
            return False

        # Check if houses are available
        if self.houses_available <= 0:
            return False

        # In a real implementation, we would check for even building
        # For simplicity, we'll allow building anywhere

        return True

    def build_house(self, player, property_square):
        """Build a house on a property"""
        if not self.can_build_house(player, property_square):
            observer.Event("update_state", "Cannot build a house on this property")
            return False

        # In a real implementation, we would track houses per property
        # and increase rent accordingly

        # Deduct house cost (using build cost from property)
        house_cost = 50  # Simplified for now
        player.money -= house_cost
        self.houses_available -= 1

        observer.Event("update_state", f"{player.name} built a house on {property_square.name} for ${house_cost}")
        return True

    def sell_house(self, player, property_square):
        """Sell a house from a property"""
        # In a real implementation, we would check if the property has houses

        # Return half the house cost
        house_cost = 50  # Simplified for now
        player.money += house_cost // 2
        self.houses_available += 1

        observer.Event("update_state", f"{player.name} sold a house from {property_square.name} for ${house_cost // 2}")
        return True

    def calculate_rent_with_monopoly(self, square, dice_sum):
        """Calculate rent considering monopolies"""
        if square.owner is None or square.is_mortgaged:
            return 0

        if square.is_utility or square.is_railroad:
            return square.calculate_rent_or_tax(dice_sum)

        # Check for monopoly
        if self.has_monopoly(square.owner, square.color):
            # Double rent for monopoly without houses
            return square.rent * 2

        return square.rent

