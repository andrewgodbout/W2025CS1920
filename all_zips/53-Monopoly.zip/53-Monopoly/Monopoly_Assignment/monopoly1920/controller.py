import traceback
from player import Player
import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        self._gameboard = None
        self.__dice_rolled = False
        self.__roll_count = 0
        self._view.controller = self

        #csv_path = os.path.join("resources", "data", "board.csv")
        #players = self._create_players(3)
        #self._gameboard = gameboard.GameBoard(csv_path, players)
        csv_path = os.path.join("resources", "data", "board.csv")
          # Will be initialized after players are created
        self._view.setup_players()

        self._add_listeners()





        #observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        #observer.Event("update_state_box", str(self._gameboard))

        #self._set_expected_val()

    def initialize_players(self, names, tokens):
        """Initialize players with names and tokens from view"""
        if not names or not tokens:
            raise ValueError("Player names and tokens cannot be empty")

        players = [Player(name, 1500, token_id)
                   for name, token_id in zip(names, tokens)]
        csv_path = os.path.join("resources", "data", "board.csv")
        self._gameboard = gameboard.GameBoard(csv_path, players)

        # Only proceed if gameboard was created successfully
        if self._gameboard:
            observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
            observer.Event("update_state_box", str(self._gameboard))
            self._set_expected_val()

    def _create_players(self, num_players):
        """Deprecated - kept for compatibility if needed"""
        from player import Player
        return [Player(f"Player {i + 1}", 1500) for i in range(num_players)]



    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("suggest", self._suggest_action)


        #@ add a suggest_logic
    # In the _suggest_action method in controller.py
    def _suggest_action(self, data):
        player = self._gameboard.get_current_player()
        square = self._gameboard.get_square(player.position)

        # First show the property card
        observer.Event("update_card", player.position)  # <-- Add this line

        if not square.can_be_purchased():
            suggestion = "CAN'T BUY: "
            reason = "This property cannot be purchased"
        else:
            can_afford = player.money >= square.price
            suggestion = "BUY" if can_afford else "DON'T BUY"
            reason = f"Cost: ${square.price} | You have: ${player.money}"

        # Send to both boxes for visibility
        full_msg = f"SUGGESTION: {suggestion} {square.name}\n{reason}"
        observer.Event("update_state_box", full_msg)
        observer.Event("update_state", full_msg)  # <-- Also show in main text box






    '''def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            # @ Modified this code to create the names of players
            player_name = input(f"Enter name for player {i+1}: ")
            player = plr.Player(player_name, 1500)
            players.append(player)
        return players'''

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev



    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1


        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""


        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()




        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True




    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    #@ Reset Game




    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)




