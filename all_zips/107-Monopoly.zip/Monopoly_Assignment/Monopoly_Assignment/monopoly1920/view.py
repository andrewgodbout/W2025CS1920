import tkinter as tk
import os
from tkinter import ttk
import controller
import observer
import random


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        
        self.player_tokens = {}
        self.token_offset = 0
        self.board_image = None 
        self.board_label = None
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()


        

        #self.setup_game()
        
    def _calculate_board_position(self, space_index):
        """Calculate screen coordinates for a given board space index"""
        if not self.board_label:
            return 0, 0

        corner_spaces = {0: "Go", 10: "Jail", 20: "Free Parking", 30: "Go To Jail"}
              
        # Get the board's screen position
        board_x = self.board_label.winfo_rootx()+10
        board_y = self.board_label.winfo_rooty()-35
        board_width = self.board_label.winfo_width() 
        board_height = self.board_label.winfo_height()

        # Calculate positions based on space index
        segment_length = board_width // 10
        if 0 <= space_index <= 10:
            x = board_x + board_width - (space_index * segment_length) - segment_length//2
            y = board_y + board_height - 20
        elif 11 <= space_index <= 20:
            x = board_x + 20
            y = board_y + board_height - ((space_index-10) * segment_length) - segment_length//2
        elif 21 <= space_index <= 30:
            x = board_x + ((space_index-20) * segment_length) - segment_length//2
            y = board_y + 20
        else:
            x = board_x + board_width - 20
            y = board_y + ((space_index-30) * segment_length) - segment_length//2

       
        if(y == 381):
            x -= 10

        if x == 143:
            x -= 20
            y -= 10

        if x == 133:
            x -= 10
            y -= 10
        
       
        print(x,y)
        x += random.randint(-3, 3)
        y += random.randint(-3, 3) # this is to make sure tokens don't overlap
        return x, y
    
    def _update_player_tokens(self, players):
        """Update all player tokens on the board with proper size accounting"""
        # Remove all existing tokens
        for token in self.player_tokens.values():
            token.place_forget()
        
        space_counts = {}
        
        for player in players:
            if player.bankrupt_declared:
                continue
                
            pos = player.position
            space_counts[pos] = space_counts.get(pos, 0) + 1
            offset = self.token_offset * (space_counts[pos] - 1)
            
            x, y = self._calculate_board_position(pos)
            
            # Adjust for token size (assuming tokens are roughly 20x20 pixels)
            token_size = 20
            x += offset - token_size//2
            y += offset - token_size//2
            
            x -= 1
            y -= 1
            if player.name not in self.player_tokens:
                # Create a styled label for the token
                token_label = ttk.Label(
                    self.main_frame, 
                    text=player.token, 
                    font=("Arial", 12),
                    relief='solid',
                    width=2,
                    anchor='center'
                )
                self.player_tokens[player.name] = token_label
            else:
                token_label = self.player_tokens[player.name]
                
            token_label.place(x=x, y=y)

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)


    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        self.board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        self.board_label = ttk.Label(middle_frame, image= self.board_image)
        self.board_label.pack(side='left', anchor='n', padx=75)
        

        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)
         
    
        #create buttons
        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll") )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        self.pay_jail_button = ttk.Button(button_frame, text="Pay Jail Fine", command=lambda: self._action_taken("pay_jail"))
        self.pay_jail_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.pay_jail_button)

        self.use_jail_card_button = ttk.Button(button_frame, text="Use Jail Card", command=lambda: self._action_taken("use_jail_card"))
        self.use_jail_card_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.use_jail_card_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image



        return middle_frame

        
       
    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        self.state_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(100,30))

        self.text_box = tk.Text(msg_frame, width=60, height=10, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(30,100))

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action):
        print(f"Action taken: {action}")  

        if action == "roll":
            #tell the controller roll was clicked
            print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)

        if action == "end_turn":
            #self.text_box.delete(1.0, tk.END)
            observer.Event("end_turn", self._clear_text)
        
        if action == "use_jail_card":
            observer.Event("use_jail_card", None)
        if action == "pay_jail_fine":
            observer.Event("pay_jail_fine", None)


    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

        if hasattr(self, '_gameboard'):
            self._update_player_tokens([self._gameboard.get_current_player()] + self._gameboard._GameBoard_players)

   
    def _choose(self, choices):
        #good idea disable all buttons
        
        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                        command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()
        for btn in self.mid_buttons:
            btn.state(['!disabled'])    

    def pick(self, s):
        observer.Event("mortgage_specific", s)

    def get_player_info(self, player_num):
        """name and token"""
        from tkinter import Toplevel, ttk, StringVar
        tokens = ["🎩 Top Hat", "👢 Boot", "🐈 Cat", "🛳️ Battleship", 
                "🚗 Racecar", "🎙️ Thimble", "🛞 Wheelbarrow", "🔨 Iron"]
        
        dialog = Toplevel(self.root)
        dialog.title(f"Player {player_num}")
        
        ttk.Label(dialog, text="Name:").grid(row=0, column=0, padx=5, pady=5)
        name_entry = ttk.Entry(dialog)
        name_entry.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(dialog, text="Token:").grid(row=1, column=0, padx=5, pady=5)
        token_var = StringVar()
        token_var.set(tokens[0])
        token_dropdown = ttk.Combobox(dialog, textvariable=token_var, values=tokens)
        token_dropdown.grid(row=1, column=1, padx=5, pady=5)
        
        result = [None, None]

        def on_ok():
            result[0] = name_entry.get() or f"Player {player_num}"
            result[1] = token_var.get().split()[0]
            dialog.destroy()
        
        ttk.Button(dialog, text="OK", command=on_ok).grid(row=2, columnspan=2)
        
        dialog.wait_window()
        return result[0], result[1]

    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
        self.images.append(img)
    



    def ask_player_names(self, num_players, on_submit):
        """Ask for player names via a popup and pass them to the controller"""
        name_window = tk.Toplevel(self.root)
        name_window.title("Enter Player Names")

        entries = []

        for i in range(num_players):
          label = ttk.Label(name_window, text=f"Player {i+1} Name:")
          label.pack(pady=5)
          entry = ttk.Entry(name_window)
          entry.pack(pady=5)
          entries.append(entry)

        def submit():
          names = [entry.get().strip() or f"Player {i+1}" for i, entry in enumerate(entries)]
          name_window.destroy()
          on_submit(names)

        submit_button = ttk.Button(name_window, text="Start Game", command=submit)
        submit_button.pack(pady=10)    


'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()

