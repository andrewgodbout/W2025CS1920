class Token:
    """Simple Token class for player piece selection."""

    AVAILABLE_TOKENS = ["Car", "Hat", "Dog", "Iron", "Shoe", "Thimble", "Battleship", "Wheelbarrow"]

    def __init__(self, name):
        if name not in Token.AVAILABLE_TOKENS:
            raise ValueError("Invalid token name.")
        self.__name = name

    @property
    def name(self):
        return self.__name
