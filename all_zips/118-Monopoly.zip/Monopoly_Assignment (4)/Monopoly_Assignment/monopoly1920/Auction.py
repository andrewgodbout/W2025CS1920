class Auction:
    """Handles auctioning properties when a player declines to buy."""

    def __init__(self, property, players):
        self.property = property
        self.players = [p for p in players if not p.bankrupt_declared]
        self.bids = {p: 0 for p in self.players}

    def start(self):
        current_bid = 0
        highest_bidder = None

        for player in self.players:
            bid = self.get_player_bid(player, current_bid)
            if bid > current_bid and bid <= player.money:
                current_bid = bid
                highest_bidder = player

        if highest_bidder:
            highest_bidder.money -= current_bid
            highest_bidder.buy_property(self.property)

    def get_player_bid(self, player, current_bid):
        # Placeholder: all players bid current_bid + 10 if they can
        return current_bid + 10 if player.money > current_bid + 10 else 0
