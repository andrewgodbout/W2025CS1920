import random

class AIPlayer:
    """A simple AI that makes decisions for a computer player."""

    def __init__(self, player):
        self.player = player

    def decide_purchase(self, property):
        # Buy if affordable and unowned
        return self.player.money > property.price and property.owner is None

    def decide_mortgage(self):
        for p in self.player.properties:
            if not p.is_mortgaged:
                return p.name
        return None

    def decide_unmortgage(self):
        if self.player.money > 500:
            return True
        return False

    def take_turn(self, controller):
        controller._roll_action(None)
        if self.decide_purchase(controller._gameboard.get_square(self.player.position)):
            controller._buy_square(None)
        if self.decide_unmortgage():
            controller._unmortgage(None)
        controller._end_player_turn(lambda: None)
