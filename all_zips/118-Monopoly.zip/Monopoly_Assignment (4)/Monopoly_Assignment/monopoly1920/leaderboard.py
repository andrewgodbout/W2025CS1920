import json
import os

class Leaderboard:
    """Simple leaderboard that tracks player wins."""

    def __init__(self, filepath="leaderboard.json"):
        self.filepath = filepath
        self.scores = {}
        self._load()

    def _load(self):
        if os.path.exists(self.filepath):
            with open(self.filepath, "r") as f:
                self.scores = json.load(f)

    def save(self):
        with open(self.filepath, "w") as f:
            json.dump(self.scores, f, indent=4)

    def add_win(self, player_name):
        if player_name not in self.scores:
            self.scores[player_name] = 0
        self.scores[player_name] += 1
        self.save()

    def get_top_players(self, n=5):
        return sorted(self.scores.items(), key=lambda x: x[1], reverse=True)[:n]
