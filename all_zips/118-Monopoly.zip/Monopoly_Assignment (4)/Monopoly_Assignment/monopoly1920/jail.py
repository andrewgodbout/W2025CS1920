class Jail:
    """Handles jail logic: sending to jail, tracking turns, and release mechanisms."""

    def __init__(self):
        self._jail_turns = {}  # player -> turns remaining in jail

    def send_to_jail(self, player):
        self._jail_turns[player] = 3
        player.position = 10  # Jail square
        player.in_jail = True

    def is_in_jail(self, player):
        return self._jail_turns.get(player, 0) > 0

    def decrement_turn(self, player):
        if self.is_in_jail(player):
            self._jail_turns[player] -= 1
            if self._jail_turns[player] <= 0:
                player.in_jail = False
                del self._jail_turns[player]

    def pay_to_exit(self, player):
        if player.money >= 50:
            player.money -= 50
            player.in_jail = False
            if player in self._jail_turns:
                del self._jail_turns[player]
            return True
        return False
