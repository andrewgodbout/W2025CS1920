import json
import os
from player import Player
from gamesquare import GameSquare


class SaveLoadSystem:
    def __init__(self, board, filepath="savefile.json"):
        self.filepath = filepath
        self.board = board

    def save_game(self):
        data = {
            "players": [],
            "squares": []
        }

        current_player = self.board.get_current_player()
        data["current_player"] = current_player.name

        for player in [current_player] + self.board.remaining_players:
            data["players"].append({
                "name": player.name,
                "money": player.money,
                "position": player.position,
                "luck": player.luck,
                "doubles_count": player.doubles_count,
                "bankrupt": player.bankrupt_declared,
                "owned": player.deed_names
            })

        for square in self.board.get_all_squares():
            data["squares"].append({
                "name": square.name,
                "owner": square.owner.name if square.owner else None,
                "mortgaged": square.is_mortgaged
            })

        with open(self.filepath, "w") as f:
            json.dump(data, f, indent=4)

    def load_game(self):
        if not os.path.exists(self.filepath):
            return None

        with open(self.filepath, "r") as f:
            data = json.load(f)

        name_to_player = {}
        players = []

        for p in data["players"]:
            player = Player(p["name"], p["money"])
            player.move(p["position"] - player.position)
            player.luck = p["luck"]
            player.doubles_count = p["doubles_count"]
            if p["bankrupt"]:
                player.declare_bankrupt()
            name_to_player[p["name"]] = player
            players.append(player)

        self.board.set_players(players)

        for square in self.board.get_all_squares():
            for s in data["squares"]:
                if square.name == s["name"]:
                    if s["owner"]:
                        square.owner = name_to_player[s["owner"]]
                        name_to_player[s["owner"]].buy_property(square)
                    square._GameSquare__is_mortgaged = s["mortgaged"]

        self.board.set_current_player(name_to_player[data["current_player"]])
