import random

class Card:
    """Chance and Community Chest card handling."""

    def __init__(self, description, effect):
        self.description = description
        self.effect = effect  # a function to execute

    def apply(self, player, gameboard):
        self.effect(player, gameboard)

class CardDeck:
    """Deck of cards (Chance or Community Chest)"""

    def __init__(self, cards):
        self.cards = cards[:]
        random.shuffle(self.cards)

    def draw(self):
        card = self.cards.pop(0)
        self.cards.append(card)
        return card

# Sample cards for demonstration purposes
def get_chance_deck():
    return CardDeck([
        Card("Advance to GO", lambda p, g: p.move(40 - p.position)),
        Card("Pay poor tax of $15", lambda p, g: setattr(p, "money", p.money - 15)),
        Card("Go to Jail", lambda p, g: g.jail.send_to_jail(p))
    ])

def get_chest_deck():
    return CardDeck([
        Card("Collect $50", lambda p, g: setattr(p, "money", p.money + 50)),
        Card("Pay hospital fees of $100", lambda p, g: setattr(p, "money", p.money - 100)),
        Card("Go to Jail", lambda p, g: g.jail.send_to_jail(p))
    ])
