import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import ai_player
import time  # Needed for timestamp functions
import datetime
import game_serializer

class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)
        self._root = root
        
        # Initialize game state variables but don't start the game yet
        # The game will be started when the user clicks "New Game" in the main menu
        self.__dice_rolled = False
        self.__roll_count = 0
        
        # Network manager reference (will be set if multiplayer is enabled)
        self._network_mgr = None
        self._multiplayer_mode = False
        self._is_host = False
        self._local_player_name = None
        
        # Observe the start_game event from the view
        self.observe("start_game", self._initialize_game)
    
    def _initialize_game(self, game_settings=None):
        """Initialize the game when the user clicks New Game"""
        csv_path = os.path.join("resources", "data", "board.csv")
        
        # Ensure we have valid settings
        if game_settings is None or not isinstance(game_settings, dict):
            print("Using default game settings")
            game_settings = {
                'player_count': 2,
                'ai_difficulty': 'medium',
                'multiplayer': False
            }
        
        print(f"Initializing game with settings: {game_settings}")
        
        # Store game settings for reference
        self._game_settings = game_settings
        
        # Check if this is a multiplayer game
        self._multiplayer_mode = game_settings.get('multiplayer', False)
        
        if self._multiplayer_mode:
            # Set up network manager if this is multiplayer mode
            self._setup_multiplayer()
            
            # Create players differently for multiplayer
            players = self._create_multiplayer_players()
        else:
            # Create players for single player mode
            player_count = game_settings.get('player_count', 2)
            ai_difficulty = game_settings.get('ai_difficulty', 'medium')
            players = self._create_players(player_count, ai_difficulty)
        
        # Create the game board
        self._gameboard = gameboard.GameBoard(csv_path, players)
        
        # Whether current player is AI
        self._current_player_is_ai = False

        # Add standard game event listeners
        self._add_listeners()
        
        # Add network-specific listeners if in multiplayer mode
        if self._multiplayer_mode:
            self._add_network_listeners()
        
        # Set references to gameboard in view for position lookup
        if hasattr(self._view, '_gameboard'):
            self._view._gameboard = self._gameboard
        
        # Update player info in UI
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(self._gameboard.get_current_player())

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))

        # Calculate expected value for current player
        self._set_expected_val()
        
        # If host in multiplayer mode, send initial game state to all clients
        if self._multiplayer_mode and self._is_host:
            self._send_game_state()
        
        # Check if the first player is AI (single player mode)
        if not self._multiplayer_mode:
            self._check_and_handle_ai_turn()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        
        # Add save/load game listeners
        self.observe("save_game", self._save_game)
        self.observe("load_game", self._load_game)
        self.observe("get_save_list", self._get_save_list)
        self.observe("get_save_details", self._get_save_details)
        self.observe("check_external_save", self._check_external_save)
        self.observe("return_to_menu", self._return_to_menu)
        
        # Initialize game serializer
        self._game_serializer = game_serializer.GameSerializer()
        
        # Set up autosave timer (5 minutes)
        self._setup_autosave_timer()

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players, ai_difficulty):
        """Create players including AI players based on settings
        
        Args:
            num_players (int): Total number of players (2 or 4)
            ai_difficulty (str): AI difficulty level (easy, medium, hard)
            
        Returns:
            list: List of Player and AIPlayer objects
        """
        players = []
        
        # Player 0 is always human
        human_player = plr.Player("Player 0", 1500)
        players.append(human_player)
        
        # Rest are AI
        for i in range(1, num_players):
            ai = ai_player.AIPlayer(f"Player {i}", 1500, ai_difficulty)
            players.append(ai)
            
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        
        # Update the dice history
        if hasattr(self._view, 'add_dice_roll'):
            self._view.add_dice_roll(dice1, dice2)
            
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
            
        # In multiplayer mode, validate if it's the local player's turn
        if self._multiplayer_mode:
            is_local_player_turn = self._is_local_player_turn()
            if not is_local_player_turn:
                observer.Event("update_state", "Not your turn")
                return
                
            # Send end turn action over the network
            self._network_mgr.send_game_action("end_turn", {})
            
            # In multiplayer client mode, don't process the action locally
            # Wait for the host to process and send back the game state
            if not self._is_host:
                observer.Event("update_state", "End turn sent to host...")
                return
        
        # Process end turn locally
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        
        # Increment turn counter
        if hasattr(self._view, 'increment_turn_count'):
            self._view.increment_turn_count()
        
        # Update player info in UI
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(self._gameboard.get_current_player())

        self._set_expected_val()
        
        # Check if the next player is AI and handle AI turn if so
        self._check_and_handle_ai_turn()
        
        # If host in multiplayer mode, send updated game state
        if self._multiplayer_mode and self._is_host:
            self._send_game_state()

    def _is_local_player_turn(self):
        """Check if it's the local player's turn in multiplayer mode"""
        if not self._multiplayer_mode or not hasattr(self, '_gameboard'):
            return True  # In single player, it's always the local player's turn
            
        current_player = self._gameboard.get_current_player()
        current_player_index = self._gameboard.current_player_index
        
        if self._is_host:
            # Host is always player 0
            return current_player_index == 0
        else:
            # Client player - look for player with local name
            return current_player.name == self._local_player_name
    
    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
            
        # In multiplayer mode, validate if it's the local player's turn
        if self._multiplayer_mode:
            is_local_player_turn = self._is_local_player_turn()
            if not is_local_player_turn:
                observer.Event("update_state", "Not your turn")
                return
                
            # Send purchase action over the network
            self._network_mgr.send_game_action("purchase", {})
            
            # In multiplayer client mode, don't process the action locally
            # Wait for the host to process and send back the game state
            if not self._is_host:
                observer.Event("update_state", "Purchase request sent to host...")
                return
        
        # Process purchase locally
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))
        
        # If host in multiplayer mode, send updated game state
        if self._multiplayer_mode and self._is_host:
            self._send_game_state()

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        # In multiplayer mode, validate if it's the local player's turn
        if self._multiplayer_mode:
            is_local_player_turn = self._is_local_player_turn()
            if not is_local_player_turn:
                observer.Event("update_state", "Not your turn")
                return
                
            # Send mortgage action over the network
            self._network_mgr.send_game_action("mortgage", {"deed_name": deed_name})
            
            # In multiplayer client mode, don't process the action locally
            # Wait for the host to process and send back the game state
            if not self._is_host:
                observer.Event("update_state", "Mortgage request sent to host...")
                return
        
        # Process mortgage locally
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")
            
        # If host in multiplayer mode, send updated game state
        if self._multiplayer_mode and self._is_host:
            self._send_game_state()

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        # In multiplayer mode, validate if it's the local player's turn
        if self._multiplayer_mode:
            is_local_player_turn = self._is_local_player_turn()
            if not is_local_player_turn:
                observer.Event("update_state", "Not your turn")
                return
                
            # Send unmortgage action over the network
            self._network_mgr.send_game_action("unmortgage", {})
            
            # In multiplayer client mode, don't process the action locally
            # Wait for the host to process and send back the game state
            if not self._is_host:
                observer.Event("update_state", "Unmortgage request sent to host...")
                return
        
        # Process unmortgage locally
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))
            
            # If host in multiplayer mode, send updated game state
            if self._multiplayer_mode and self._is_host:
                self._send_game_state()


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()
        
        # In multiplayer mode, validate if it's the local player's turn
        if self._multiplayer_mode:
            is_local_player_turn = self._is_local_player_turn()
            if not is_local_player_turn:
                observer.Event("update_state", "Not your turn")
                return
            
            # Send roll action over the network if this is a multiplayer game
            # and it's the local player's turn
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            roll_data = {
                'dice1': dice1,
                'dice2': dice2
            }
            self._network_mgr.send_game_action("roll", roll_data)
            
            # In multiplayer client mode, don't process the action locally
            # Wait for the host to process and send back the game state
            if not self._is_host:
                observer.Event("update_state", "Roll sent to host...")
                return

        # Process the roll action
        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
        
        # Update player info in UI
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(player)
            
        # If current player is AI, handle property buying decision
        if hasattr(player, 'is_ai') and player.is_ai:
            self._handle_ai_property_decision(player, square)
            
        # If host in multiplayer mode, send updated game state
        if self._multiplayer_mode and self._is_host:
            self._send_game_state()
            
    def _check_and_handle_ai_turn(self):
        """Check if current player is AI and handle their turn if so"""
        current_player = self._gameboard.get_current_player()
        
        # Debug info with better visibility
        print(f"====== AI TURN CHECK ======")
        print(f"Current player: {current_player.name}")
        print(f"Player has is_ai attribute: {hasattr(current_player, 'is_ai')}")
        if hasattr(current_player, 'is_ai'):
            print(f"Player is_ai value: {current_player.is_ai}")
            # Even more explicit check for the instance type
            print(f"Player is instance of AIPlayer: {isinstance(current_player, ai_player.AIPlayer)}")
        
        # First check if the player is an instance of AIPlayer
        if isinstance(current_player, ai_player.AIPlayer):
            print(f"Player {current_player.name} is an AIPlayer instance, handling AI turn")
            self._current_player_is_ai = True
            # Schedule AI action with a slight delay for better UX
            self._root.after(1000, self._handle_ai_turn)
            return
            
        # If not a direct instance, check the is_ai flag
        if hasattr(current_player, 'is_ai') and current_player.is_ai:
            print(f"Player {current_player.name} has is_ai=True, handling AI turn")
            self._current_player_is_ai = True
            # Schedule AI action with a slight delay for better UX
            self._root.after(1000, self._handle_ai_turn)
            return
        
        # If we get here, it's not an AI player
        self._current_player_is_ai = False
        print(f"Player {current_player.name} is not AI, waiting for human input")
    
    def _handle_ai_turn(self):
        """Handle the turn for an AI player"""
        player = self._gameboard.get_current_player()
        
        # Debug info
        print(f"AI turn handler for player: {player.name}")
        
        # Ensure this is an AI player
        if not hasattr(player, 'is_ai') or not player.is_ai:
            print(f"WARNING: _handle_ai_turn called for non-AI player {player.name}")
            return
            
        # Play dice roll sound for AI turn
        if hasattr(self._view, 'sound_mgr'):
            self._view.sound_mgr.play_sound("dice_roll")
            
        print(f"AI player {player.name} is rolling dice")
        
        # Roll dice
        self._roll_action(None)
        
        # Add a delay before ending turn for better UX
        print(f"Scheduling AI turn end in 2 seconds")
        self._root.after(2000, self._end_ai_turn)
    
    def _end_ai_turn(self):
        """End the AI player's turn after actions are taken"""
        player = self._gameboard.get_current_player()
        
        print(f"AI turn ending for player: {player.name}")
        
        # Ensure this is an AI player
        if not hasattr(player, 'is_ai') or not player.is_ai:
            print(f"WARNING: _end_ai_turn called for non-AI player {player.name}")
            return
            
        # Check if AI decides to end turn
        print(f"AI {player.name} deciding whether to end turn...")
        should_end = player.decide_end_turn()
        print(f"AI {player.name} decided to end turn: {should_end}")
        
        if should_end:
            # Play end turn sound
            if hasattr(self._view, 'sound_mgr'):
                self._view.sound_mgr.play_sound("end_turn")
                
            print(f"AI {player.name} ending turn")
            self._end_player_turn(self._clear_text)
        else:
            print(f"AI {player.name} not ending turn yet")
    
    def _handle_ai_property_decision(self, ai_player, square):
        """Handle AI decision on purchasing property"""
        print(f"Handling AI property decision for {ai_player.name} on {square.name if hasattr(square, 'name') else 'unnamed square'}")
        
        # Check if property can be purchased
        if not hasattr(square, 'can_be_purchased'):
            print(f"Square does not have can_be_purchased method")
            return
            
        try:
            can_purchase = square.can_be_purchased()
            print(f"Square can be purchased: {can_purchase}")
            if not can_purchase:
                return
        except Exception as e:
            print(f"Error checking if square can be purchased: {e}")
            return
            
        # AI decides whether to purchase
        print(f"AI {ai_player.name} deciding whether to buy {square.name if hasattr(square, 'name') else 'unnamed square'}")
        try:
            should_buy = ai_player.decide_buy_property(square, self._gameboard)
            print(f"AI decision to buy: {should_buy}")
            
            if should_buy:
                # Play buy property sound
                if hasattr(self._view, 'sound_mgr'):
                    self._view.sound_mgr.play_sound("buy_property")
                    
                print(f"AI {ai_player.name} purchasing {square.name if hasattr(square, 'name') else 'unnamed square'}")
                # Purchase property
                self._buy_square(None)
            else:
                print(f"AI {ai_player.name} decided not to buy {square.name if hasattr(square, 'name') else 'unnamed square'}")
        except Exception as e:
            print(f"Error in AI property buying decision: {e}")
        
        # Check if AI needs to mortgage properties
        if ai_player.money < 0:
            print(f"AI {ai_player.name} needs to mortgage properties (money: {ai_player.money})")
            self._handle_ai_mortgage(ai_player)
    
    def _handle_ai_mortgage(self, ai_player):
        """Handle AI mortgage decisions when low on money"""
        # Keep mortgaging until money is positive
        while ai_player.money < 0:
            property_to_mortgage = ai_player.decide_mortgage_property()
            
            if not property_to_mortgage:
                # No properties to mortgage, declare bankruptcy
                ai_player.declare_bankrupt()
                # Play bankruptcy sound
                if hasattr(self._view, 'sound_mgr'):
                    self._view.sound_mgr.play_sound("go_bankrupt")
                break
                
            # Play mortgage sound
            if hasattr(self._view, 'sound_mgr'):
                self._view.sound_mgr.play_sound("mortgage")
                
            # Mortgage the property
            ai_player.mortgage_property(property_to_mortgage)
    
    def _clear_text(self):
        """Clear text in view's text box"""
        if hasattr(self._view, '_clear_text'):
            self._view._clear_text()
            
    # ==========================================
    # Multiplayer-specific methods
    # ==========================================
    
    def _setup_multiplayer(self):
        """Initialize the multiplayer session"""
        # Get the network manager from the root (set by the view)
        if hasattr(self._root, 'network_manager'):
            self._network_mgr = self._root.network_manager
            
            # Determine if we're host or client
            self._is_host = self._network_mgr.host_mode
            self._local_player_name = self._network_mgr.player_name
            
            # Initialize state sync timestamp
            self._last_state_sync = time.time()
            
            print(f"Multiplayer mode initialized as {'Host' if self._is_host else 'Client'}")
            observer.Event("update_state", f"Multiplayer game started as {'Host' if self._is_host else 'Client'}")
        else:
            print("Error: Network manager not found")
            observer.Event("update_state", "Error: Network manager not found")
            self._multiplayer_mode = False
    
    def _create_multiplayer_players(self):
        """Create players for a multiplayer game"""
        players = []
        
        if self._is_host:
            # Host creates all players and manages game state
            # Host is always Player 0
            host_player = plr.Player(f"Host ({self._local_player_name})", 1500)
            host_player.is_ai = False  # Explicitly set is_ai flag for host
            players.append(host_player)
            
            # Create players for each connected client
            for i, client in enumerate(self._network_mgr.clients, 1):
                client_player = plr.Player(client['player_name'], 1500)
                client_player.is_ai = False  # Explicitly set is_ai flag for clients
                players.append(client_player)
                
            # If less than 2 players, add AI players to fill
            if len(players) < 2:
                ai_difficulty = self._game_settings.get('ai_difficulty', 'medium')
                for i in range(len(players), 2):
                    ai = ai_player.AIPlayer(f"AI Player {i}", 1500, ai_difficulty)
                    # AIPlayer constructor sets is_ai=True, but let's make sure
                    ai.is_ai = True
                    print(f"Created AI player: {ai.name} with is_ai={ai.is_ai}")
                    players.append(ai)
        else:
            # Client just creates placeholder players
            # The real game state will be synchronized from the host
            # The order of players must match the host's order
            
            # Create host player (always index 0)
            host_player = plr.Player("Host", 1500)
            players.append(host_player)
            
            # Create local player (client player)
            client_player = plr.Player(self._local_player_name, 1500)
            players.append(client_player)
            
            # Create placeholder players for any additional players
            # The actual names will be updated via network sync
            for i in range(2, 4):
                placeholder = plr.Player(f"Player {i}", 1500)
                players.append(placeholder)
        
        return players
    
    def _add_network_listeners(self):
        """Add network-specific event observers"""
        self.observe("network_action", self._handle_network_action)
        self.observe("network_game_state", self._handle_network_game_state)
        self.observe("network_chat", self._handle_network_chat)
        self.observe("player_connected", self._handle_player_connected)
        self.observe("player_disconnected", self._handle_player_disconnected)
        
        # Start message processing timer
        self._root.after(100, self._process_network_messages)
    
    def _process_network_messages(self):
        """Process any pending network messages"""
        if self._multiplayer_mode and self._network_mgr:
            # Process any messages in the queue
            messages = self._network_mgr.process_messages()
            
            # If host, broadcast game state periodically
            if self._is_host and hasattr(self, '_last_state_sync'):
                current_time = time.time()
                if current_time - self._last_state_sync > 5:  # Sync every 5 seconds
                    self._send_game_state()
                    self._last_state_sync = current_time
            
            # Schedule next processing
            self._root.after(100, self._process_network_messages)
    
    def _send_game_state(self):
        """Send the current game state to all clients (host only)"""
        if not self._multiplayer_mode or not self._is_host or not self._network_mgr:
            return
            
        # Create a serializable game state
        game_state = self._create_serializable_game_state()
        
        # Send game state to all clients
        self._network_mgr.send_game_state(game_state)
        self._last_state_sync = time.time()
    
    def _create_serializable_game_state(self):
        """Create a serializable version of the game state"""
        # Extract relevant data from game objects
        players_data = []
        for p in self._gameboard.players:
            player_data = {
                'name': p.name,
                'money': p.money,
                'position': p.position,
                'properties': [{'name': prop.name, 'is_mortgaged': prop.is_mortgaged} for prop in getattr(p, 'properties', [])]
            }
            players_data.append(player_data)
        
        # Create the game state dictionary
        game_state = {
            'current_player_index': self._gameboard.current_player_index,
            'players': players_data,
            'dice_rolled': self.__dice_rolled,
            'roll_count': self.__roll_count,
            'timestamp': time.time()
        }
        
        return game_state
    
    def _handle_network_action(self, data):
        """Handle a game action received from another player"""
        action_type, action_data, player_name = data
        
        print(f"Received network action: {action_type} from {player_name}")
        
        # Handle different action types
        if action_type == "roll":
            # Remote player rolled dice
            if self._is_host:
                # Only the host processes the action
                # Find the player
                player_index = self._find_player_index_by_name(player_name)
                if player_index >= 0 and player_index == self._gameboard.current_player_index:
                    # Valid player and it's their turn
                    self._handle_remote_roll(player_index, action_data)
        
        elif action_type == "purchase":
            # Remote player is purchasing property
            if self._is_host:
                player_index = self._find_player_index_by_name(player_name)
                if player_index >= 0 and player_index == self._gameboard.current_player_index:
                    self._handle_remote_purchase(player_index)
        
        elif action_type == "mortgage":
            # Remote player is mortgaging a property
            if self._is_host:
                player_index = self._find_player_index_by_name(player_name)
                if player_index >= 0 and player_index == self._gameboard.current_player_index:
                    deed_name = action_data.get('deed_name', '')
                    self._handle_remote_mortgage(player_index, deed_name)
                    
        elif action_type == "unmortgage":
            # Remote player is unmortgaging a property
            if self._is_host:
                player_index = self._find_player_index_by_name(player_name)
                if player_index >= 0 and player_index == self._gameboard.current_player_index:
                    self._handle_remote_unmortgage(player_index)
        
        elif action_type == "end_turn":
            # Remote player is ending their turn
            if self._is_host:
                player_index = self._find_player_index_by_name(player_name)
                if player_index >= 0 and player_index == self._gameboard.current_player_index:
                    self._handle_remote_end_turn(player_index)
        
        # After processing network action, send updated game state
        if self._is_host:
            self._send_game_state()
    
    def _handle_network_game_state(self, game_state):
        """Handle a game state update from the host"""
        if self._is_host:
            # Host doesn't need to process game state updates
            return
            
        # Update local game state based on received data
        
        # Update players
        for i, player_data in enumerate(game_state['players']):
            if i < len(self._gameboard.players):
                player = self._gameboard.players[i]
                
                # Update player properties
                player.name = player_data['name']
                player.money = player_data['money']
                player.position = player_data['position']
                
                # Update properties (simplified, would need more logic for real implementation)
                # This is just a placeholder for the actual property synchronization
        
        # Update game state
        self._gameboard.current_player_index = game_state['current_player_index']
        self.__dice_rolled = game_state['dice_rolled']
        self.__roll_count = game_state['roll_count']
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        
        # Update player info in UI
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(self._gameboard.get_current_player())
    
    def _handle_network_chat(self, data):
        """Handle a chat message from another player"""
        text, player_name = data
        observer.Event("update_state", f"[CHAT] {player_name}: {text}")
    
    def _handle_player_connected(self, player_name):
        """Handle a player connecting to the game"""
        if self._is_host:
            observer.Event("update_state", f"Player {player_name} connected")
            
            # If game hasn't started yet, add the player
            if hasattr(self, '_gameboard'):
                # Game already started, can't add new player
                pass
            else:
                # Game hasn't started yet, player will be added when game initializes
                pass
    
    def _handle_player_disconnected(self, player_name):
        """Handle a player disconnecting from the game"""
        observer.Event("update_state", f"Player {player_name} disconnected")
        
        # If host, mark player as AI if game is in progress
        if self._is_host and hasattr(self, '_gameboard'):
            player_index = self._find_player_index_by_name(player_name)
            if player_index > 0:  # Don't convert host to AI
                # Convert to AI player
                player = self._gameboard.players[player_index]
                difficulty = self._game_settings.get('ai_difficulty', 'medium')
                
                # Replace with AI player keeping same properties and money
                ai = ai_player.AIPlayer(f"AI (was {player_name})", player.money, difficulty)
                
                # Copy properties (simplified, would need more implementation)
                # ai.properties = player.properties
                
                # Replace player in the game board
                self._gameboard.players[player_index] = ai
                
                # Notify other players
                observer.Event("update_state", f"Player {player_name} replaced by AI")
                
                # Send updated game state
                self._send_game_state()
    
    def _find_player_index_by_name(self, player_name):
        """Find the index of a player by name"""
        if not hasattr(self, '_gameboard'):
            return -1
            
        for i, player in enumerate(self._gameboard.players):
            if player.name == player_name:
                return i
        return -1
    
    def _handle_remote_roll(self, player_index, roll_data):
        """Handle a remote player's dice roll"""
        # In a real implementation, we would use the actual dice values from roll_data
        # For now, we'll just simulate a roll
        
        player = self._gameboard.players[player_index]
        
        # Use provided dice values if available, otherwise simulate
        if isinstance(roll_data, dict) and 'dice1' in roll_data and 'dice2' in roll_data:
            dice1 = roll_data['dice1']
            dice2 = roll_data['dice2']
        else:
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
        
        dice_sum = dice1 + dice2
        
        # Update UI for roll
        observer.Event("update_state", f"{player.name} rolled: {dice1} + {dice2} = {dice_sum}")
        
        # Update dice history
        if hasattr(self._view, 'add_dice_roll'):
            self._view.add_dice_roll(dice1, dice2)
        
        # Move player
        player.move(dice_sum)
        
        # Simulate landing on square
        position = player.position
        square = self._gameboard.get_square(position)
        
        # Check for rent
        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            observer.Event("update_state", f"{player.name} paid ${rent} rent")
        
        # Update UI
        observer.Event("update_state", f"{player.name} landed on {square}")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)
        
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(player)
    
    def _handle_remote_purchase(self, player_index):
        """Handle a remote player purchasing property"""
        player = self._gameboard.players[player_index]
        position = player.position
        square = self._gameboard.get_square(position)
        
        # Attempt purchase
        buy = player.buy_property(square)
        if buy:
            observer.Event("update_state", f"{player.name} bought {square}")
        else:
            observer.Event("update_state", f"{player.name} could not buy {square}")
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
    
    def _handle_remote_mortgage(self, player_index, deed_name):
        """Handle a remote player mortgaging a property"""
        player = self._gameboard.players[player_index]
        
        # Attempt mortgage operation
        res = player.mortgage_property(deed_name)
        if res:
            observer.Event("update_state", f"{player.name} mortgaged {deed_name}")
        else:
            observer.Event("update_state", f"{player.name} could not mortgage {deed_name}")
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
        
    def _handle_remote_unmortgage(self, player_index):
        """Handle a remote player unmortgaging a property"""
        player = self._gameboard.players[player_index]
        
        # Attempt unmortgage operation
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"{player.name} unmortgaged {deed_name}")
        else:
            observer.Event("update_state", f"{player.name} could not unmortgage any property")
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
    
    def _handle_remote_end_turn(self, player_index):
        """Handle a remote player ending their turn"""
        # End the current turn
        self.__dice_rolled = False
        self.__roll_count = 0
        
        # Move to next player
        player_name = self._gameboard.next_turn()
        
        # Update UI
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        observer.Event("update_state", f"{player_name}'s turn")
        
        # Update turn counter
        if hasattr(self._view, 'increment_turn_count'):
            self._view.increment_turn_count()
        
        # Update player info
        if hasattr(self._view, 'update_player_info'):
            self._view.update_player_info(self._gameboard.get_current_player())
        
        # Calculate expected value
        self._set_expected_val()
        
        # If next player is AI, handle AI turn
        self._check_and_handle_ai_turn()
        
    # ==========================================
    # Save/Load Game Methods
    # ==========================================
    
    def _setup_autosave_timer(self):
        """Set up a timer for auto-saving the game"""
        # Auto-save every 5 minutes (300000 ms)
        self._autosave_interval = 300000
        self._root.after(self._autosave_interval, self._autosave_game)
    
    def _autosave_game(self):
        """Automatically save the game periodically"""
        if hasattr(self, '_gameboard'):
            # Only autosave if game is in progress
            print("Auto-saving game...")
            try:
                self._game_serializer.save_game(self, is_autosave=True)
                
                # Show a notification
                if hasattr(self._view, 'show_autosave_notification'):
                    self._view.show_autosave_notification()
            except Exception as e:
                print(f"Error during autosave: {e}")
        
        # Schedule next autosave
        self._root.after(self._autosave_interval, self._autosave_game)
    
    def _save_game(self, custom_name):
        """Save the current game state to a file
        
        Args:
            custom_name: Custom name for the save file
        """
        print(f"Saving game with name: {custom_name}")
        try:
            save_path = self._game_serializer.save_game(self, custom_name)
            observer.Event("update_state", f"Game saved to {save_path}")
            print(f"Game saved successfully to {save_path}")
        except Exception as e:
            observer.Event("update_state", f"Error saving game: {e}")
            print(f"Error saving game: {e}")
    
    def _load_game(self, file_path):
        """Load a game from a save file
        
        Args:
            file_path: Path to the save file
        """
        print(f"Loading game from: {file_path}")
        
        try:
            # Load the game data
            game_data = self._game_serializer.load_game(file_path)
            if not game_data:
                observer.Event("update_state", "Failed to load game: Invalid save file")
                return
            
            # Extract data
            gameboard_data = game_data.get("gameboard", {})
            players_data = game_data.get("players", [])
            properties_data = game_data.get("properties", [])
            
            # Create new players from saved data
            players = []
            for player_data in players_data:
                is_ai = player_data.get("is_ai", False)
                
                if is_ai:
                    # Create AI player
                    difficulty = player_data.get("ai_difficulty", "medium")
                    new_player = ai_player.AIPlayer(
                        player_data.get("name", "AI Player"),
                        player_data.get("money", 1500),
                        difficulty
                    )
                else:
                    # Create human player
                    new_player = plr.Player(
                        player_data.get("name", "Player"),
                        player_data.get("money", 1500)
                    )
                    new_player.is_ai = False
                
                # Set player position
                new_player._Player__board_position = player_data.get("position", 0)
                
                # Set bankrupt status
                if player_data.get("bankrupt_declared", False):
                    new_player.declare_bankrupt()
                
                # Set luck value if available
                if "luck" in player_data:
                    new_player.luck = player_data["luck"]
                
                players.append(new_player)
            
            # Create a new game board with loaded players
            csv_path = os.path.join("resources", "data", "board.csv")
            self._gameboard = gameboard.GameBoard(csv_path, players)
            
            # Set current player index
            current_player_index = gameboard_data.get("current_player_index", 0)
            self._gameboard._GameBoard__current_player_index = current_player_index
            
            # Set dice rolled state
            self.__dice_rolled = gameboard_data.get("dice_rolled", False)
            self.__roll_count = gameboard_data.get("roll_count", 0)
            
            # Assign properties to players
            for player_idx, player_data in enumerate(players_data):
                player = players[player_idx]
                
                # Add properties to player
                for prop_data in player_data.get("property_indices", []):
                    prop_index = prop_data.get("index")
                    is_mortgaged = prop_data.get("is_mortgaged", False)
                    
                    if prop_index is not None and 0 <= prop_index < len(self._gameboard.get_all_squares()):
                        board_square = self._gameboard.get_square(prop_index)
                        
                        # Set owner
                        board_square.owner = player
                        
                        # Add to player's properties
                        player._Player__properties.append(board_square)
                        
                        # Set mortgage status
                        if is_mortgaged and hasattr(board_square, 'is_mortgaged'):
                            board_square.is_mortgaged = True
            
            # Update UI with loaded game state
            if hasattr(self._view, 'update_player_info'):
                self._view.update_player_info(self._gameboard.get_current_player())
                
            observer.Event("update_state", f"Game loaded from {file_path}")
            observer.Event("update_state_box", str(self._gameboard))
            observer.Event("update_card", self._gameboard.get_current_player().position)
            
            # If view has a turn counter, update it
            if hasattr(self._view, 'turn_count_label'):
                turn_count = game_data.get("metadata", {}).get("turn_count", 1)
                self._view.turn_count = turn_count
                self._view.turn_count_label.config(text=f"Turn: {turn_count}")
            
            # If this is an AI player, handle their turn
            self._check_and_handle_ai_turn()
            
        except Exception as e:
            observer.Event("update_state", f"Error loading game: {e}")
            print(f"Error loading game: {e}")
    
    def _get_save_list(self, data):
        """Get list of available saved games and update the listbox
        
        Args:
            data: Either a listbox widget or a tuple of (listbox, include_autosaves)
        """
        include_autosaves = True
        
        if isinstance(data, tuple):
            # Unpack the tuple
            listbox, include_autosaves = data
        else:
            # Assume it's just the listbox
            listbox = data
        
        try:
            # Clear the listbox
            listbox.delete(0, tk.END)
            
            # Get saves from the serializer
            saves = self._game_serializer.get_save_list(include_autosaves=include_autosaves)
            
            # Add save entries to listbox
            for save in saves:
                is_auto = save.get("is_autosave", False)
                display_name = save.get("display_name", "Unknown Save")
                timestamp = save.get("timestamp", "Unknown Date")
                
                # Format timestamp nicely
                if timestamp != "Unknown Date":
                    try:
                        dt = datetime.datetime.fromisoformat(timestamp)
                        formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        formatted_time = timestamp
                else:
                    formatted_time = timestamp
                
                # Add prefix for autosaves
                if is_auto:
                    display_name = f"[Auto] {display_name}"
                
                # Add to listbox with format "path | display_name (timestamp)"
                listbox.insert(tk.END, f"{save['file_path']} | {display_name} ({formatted_time})")
        except Exception as e:
            print(f"Error getting save list: {e}")
    
    def _get_save_details(self, data):
        """Get details about a specific save file
        
        Args:
            data: Tuple of (save_path, details_widget)
        """
        save_path, details_widget = data
        
        try:
            # Load save file metadata
            game_data = self._game_serializer.load_game(save_path)
            
            if not game_data:
                details_widget.config(state=tk.NORMAL)
                details_widget.delete(1.0, tk.END)
                details_widget.insert(tk.END, "Error: Could not load save file")
                details_widget.config(state=tk.DISABLED)
                return
            
            # Extract metadata
            metadata = game_data.get("metadata", {})
            players_data = game_data.get("players", [])
            
            # Format details
            details = []
            details.append(f"Save Name: {metadata.get('custom_name') or 'Unnamed Save'}")
            details.append(f"Date: {metadata.get('timestamp', 'Unknown')}")
            details.append(f"Players: {len(players_data)}")
            details.append(f"Turn #: {metadata.get('turn_count', 0)}")
            
            # Add player info
            details.append("\nPlayers:")
            for i, player in enumerate(players_data):
                player_type = "AI" if player.get("is_ai", False) else "Human"
                player_status = "Bankrupt" if player.get("bankrupt_declared", False) else "Active"
                details.append(f"  {player.get('name', f'Player {i}')}: ${player.get('money', 0)} ({player_type}, {player_status})")
            
            # Update the details widget
            details_widget.config(state=tk.NORMAL)
            details_widget.delete(1.0, tk.END)
            details_widget.insert(tk.END, "\n".join(details))
            details_widget.config(state=tk.DISABLED)
        except Exception as e:
            print(f"Error getting save details: {e}")
            details_widget.config(state=tk.NORMAL)
            details_widget.delete(1.0, tk.END)
            details_widget.insert(tk.END, f"Error loading save details: {e}")
            details_widget.config(state=tk.DISABLED)
    
    def _check_external_save(self, data):
        """Check if an external file is a valid save file and add it to the list
        
        Args:
            data: Tuple of (file_path, listbox)
        """
        file_path, listbox = data
        
        try:
            # Check if file exists and is valid
            game_data = self._game_serializer.load_game(file_path)
            
            if not game_data:
                observer.Event("update_state", "Error: Invalid save file")
                return
            
            # Get the file's metadata
            metadata = game_data.get("metadata", {})
            display_name = metadata.get("custom_name", "External Save")
            timestamp = metadata.get("timestamp", "Unknown Date")
            
            # Format timestamp nicely
            if timestamp != "Unknown Date":
                try:
                    dt = datetime.datetime.fromisoformat(timestamp)
                    formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    formatted_time = timestamp
            else:
                formatted_time = timestamp
            
            # Add to listbox with format "path | display_name (timestamp)"
            listbox.insert(0, f"{file_path} | [External] {display_name} ({formatted_time})")
            
            # Select the new item
            listbox.selection_clear(0, tk.END)
            listbox.selection_set(0)
            listbox.activate(0)
            listbox.see(0)
            
            # Trigger selection event to update details
            listbox.event_generate("<<ListboxSelect>>")
            
        except Exception as e:
            print(f"Error checking external save: {e}")
            observer.Event("update_state", f"Error: Not a valid save file ({e})")
    
    def _return_to_menu(self, data=None):
        """Handle the return to main menu event"""
        # Clean up current game state
        self.__dice_rolled = False
        self.__roll_count = 0
        
        # Set up a minimal state in case listeners try to access it
        if hasattr(self, '_gameboard'):
            del self._gameboard
            
        # Reset network mode if active
        self._multiplayer_mode = False
        self._is_host = False
        self._local_player_name = None
        
        if hasattr(self, '_network_mgr') and self._network_mgr:
            self._network_mgr.stop()
            self._network_mgr = None
        
        print("Returned to main menu")
