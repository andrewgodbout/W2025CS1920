import tkinter as tk
import os
import math
import random
import time
import datetime
from tkinter import ttk
import controller
import observer
import sound_manager
import styles
import network_manager


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class MainMenu:
    """Class to create the main menu for the Monopoly game"""
    
    def __init__(self, root, start_game_callback, sound_mgr, show_load_dialog_callback):
        self.root = root
        self.start_game_callback = start_game_callback
        self.sound_mgr = sound_mgr
        self.show_load_dialog = show_load_dialog_callback # Store the callback
        self.frame = ttk.Frame(root, padding=10)
        
        # Game settings
        self.player_count = tk.IntVar(value=2)  # Default to 2 players
        self.ai_difficulty = tk.StringVar(value="medium")  # Default to medium difficulty
        
        # Start playing background music
        self.sound_mgr.play_music("menu")
        
        # Load and display the logo
        logo_image = tk.PhotoImage(file=os.path.join("resources", "images", "monopoly_logo.png"))
        logo = ttk.Label(self.frame, image=logo_image)
        logo.image = logo_image  # Keep a reference
        logo.pack(side='top', anchor='n', pady=20)
        
        # Create buttons with keyboard shortcuts
        button_frame = ttk.Frame(self.frame, padding=10)
        
        new_game_button = ttk.Button(button_frame, text="New Game [N]", command=self.start_game)
        new_game_button.pack(side='top', pady=10, padx=20, fill='x')
        
        multiplayer_button = ttk.Button(button_frame, text="Multiplayer [M]", command=self.show_multiplayer_menu)
        multiplayer_button.pack(side='top', pady=10, padx=20, fill='x')
        
        load_game_button = ttk.Button(button_frame, text="Load Game [L]", command=self.show_load_dialog)
        load_game_button.pack(side='top', pady=10, padx=20, fill='x')
        
        options_button = ttk.Button(button_frame, text="Options [O]", command=self.show_options)
        options_button.pack(side='top', pady=10, padx=20, fill='x')
        
        quit_button = ttk.Button(button_frame, text="Quit [Q]", command=root.destroy)
        quit_button.pack(side='top', pady=10, padx=20, fill='x')
        
        button_frame.pack(side='top', pady=20)
        
        # Display the frame
        self.frame.pack(fill=tk.BOTH, expand=True)
        
    def start_game(self, multiplayer=False):
        """Start the game"""
        self.frame.pack_forget()  # Hide the menu
        # Switch to game music
        self.sound_mgr.play_music("game")
        # Emit the start_game event with game settings
        game_settings = {
            'player_count': self.player_count.get(),
            'ai_difficulty': self.ai_difficulty.get(),
            'multiplayer': multiplayer
        }
        observer.Event("start_game", game_settings)
        self.start_game_callback()  # Call the callback to start the game
        
    def show_multiplayer_menu(self):
        """Show multiplayer menu with host/join options"""
        multiplayer_window = tk.Toplevel(self.root)
        multiplayer_window.title("Multiplayer")
        multiplayer_window.geometry("400x300")
        multiplayer_window.resizable(True, True)
        multiplayer_window.minsize(400, 300)
        multiplayer_window.transient(self.root)  # Make window modal
        multiplayer_window.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(multiplayer_window, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Multiplayer Options", font=("Arial", 14, "bold"))
        title_label.pack(anchor='center', pady=(0, 20))
        
        # Host game button
        host_button = ttk.Button(main_frame, text="Host a Game", 
                               command=lambda: self._show_host_game_dialog(multiplayer_window))
        host_button.pack(side='top', pady=10, padx=20, fill='x')
        
        # Join game button
        join_button = ttk.Button(main_frame, text="Join a Game", 
                              command=lambda: self._show_join_game_dialog(multiplayer_window))
        join_button.pack(side='top', pady=10, padx=20, fill='x')
        
        # Back button
        back_button = ttk.Button(main_frame, text="Back to Main Menu", command=multiplayer_window.destroy)
        back_button.pack(side='bottom', pady=20)
    
    def _show_host_game_dialog(self, parent_window):
        """Show dialog for hosting a multiplayer game"""
        host_window = tk.Toplevel(parent_window)
        host_window.title("Host Game")
        host_window.geometry("400x350")
        host_window.resizable(True, True)
        host_window.minsize(400, 350)
        host_window.transient(parent_window)  # Make window modal
        host_window.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(host_window, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Host a Multiplayer Game", font=("Arial", 14, "bold"))
        title_label.pack(anchor='center', pady=(0, 20))
        
        # Create the network manager
        net_mgr = network_manager.NetworkManager()
        
        # Get local IP
        local_ip = net_mgr.get_local_ip()
        
        # Connection information
        info_frame = ttk.LabelFrame(main_frame, text="Connection Information", padding=10)
        info_frame.pack(fill='x', expand=True, pady=10)
        
        ttk.Label(info_frame, text="Your Local IP:").grid(row=0, column=0, sticky='w', pady=5)
        ip_label = ttk.Label(info_frame, text=local_ip, font=("Arial", 10, "bold"))
        ip_label.grid(row=0, column=1, sticky='w', pady=5)
        
        ttk.Label(info_frame, text="Port:").grid(row=1, column=0, sticky='w', pady=5)
        
        # Port entry with default
        port_var = tk.StringVar(value="5555")
        port_entry = ttk.Entry(info_frame, textvariable=port_var, width=10)
        port_entry.grid(row=1, column=1, sticky='w', pady=5)
        
        # Player name
        ttk.Label(info_frame, text="Your Name:").grid(row=2, column=0, sticky='w', pady=5)
        name_var = tk.StringVar(value=f"Host_{random.randint(100, 999)}")
        name_entry = ttk.Entry(info_frame, textvariable=name_var, width=20)
        name_entry.grid(row=2, column=1, sticky='w', pady=5)
        
        # Status area
        status_frame = ttk.LabelFrame(main_frame, text="Status", padding=10)
        status_frame.pack(fill='x', expand=True, pady=10)
        
        status_var = tk.StringVar(value="Ready to host")
        status_label = ttk.Label(status_frame, textvariable=status_var, foreground="blue")
        status_label.pack(anchor='w', pady=5)
        
        # Players list (initially empty)
        players_frame = ttk.LabelFrame(main_frame, text="Connected Players", padding=10)
        players_frame.pack(fill='x', expand=True, pady=10)
        
        players_list = tk.Listbox(players_frame, height=3)
        players_list.pack(fill='x', expand=True)
        players_list.insert(tk.END, f"{name_var.get()} (Host)")
        
        # Action buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', expand=True, pady=10)
        
        # Start hosting button
        host_button = ttk.Button(button_frame, text="Start Hosting", 
                               command=lambda: self._start_hosting(
                                   net_mgr, 
                                   int(port_var.get()), 
                                   name_var.get(),
                                   status_var,
                                   start_button,
                                   host_button))
        host_button.pack(side='left', padx=5)
        
        # Start game button (initially disabled)
        start_button = ttk.Button(button_frame, text="Start Game", 
                               command=lambda: self._start_multiplayer_game(host_window, parent_window, net_mgr),
                               state='disabled')
        start_button.pack(side='left', padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Cancel", 
                                command=lambda: self._cancel_hosting(host_window, net_mgr))
        cancel_button.pack(side='right', padx=5)
        
        # Set up observer for player connections
        def update_player_list(player_list):
            players_list.delete(0, tk.END)
            for player in player_list:
                name = player['name']
                players_list.insert(tk.END, name)
                
        def on_player_connected(player_name):
            status_var.set(f"Player {player_name} connected")
            # Enable start button once at least one player joins
            start_button.state(['!disabled'])
        
        # Create observer instances and store them
        player_list_observer = observer.Observer()
        player_list_observer.observe("update_player_list", update_player_list)
        host_window.player_list_observer = player_list_observer
        
        player_connected_observer = observer.Observer()
        player_connected_observer.observe("player_connected", on_player_connected)
        host_window.player_connected_observer = player_connected_observer
        
        # Clean up when window closes
        def on_close():
            if host_window.player_list_observer in observer.Observer._observers:
                observer.Observer._observers.remove(host_window.player_list_observer)
            if host_window.player_connected_observer in observer.Observer._observers:
                observer.Observer._observers.remove(host_window.player_connected_observer)
            net_mgr.stop()
            host_window.destroy()
            
        host_window.protocol("WM_DELETE_WINDOW", on_close)
    
    def _start_hosting(self, net_mgr, port, player_name, status_var, start_button, host_button):
        """Start hosting a multiplayer game"""
        net_mgr.player_name = player_name
        if net_mgr.start_host(port):
            status_var.set(f"Hosting game on port {port}. Waiting for players...")
            host_button.state(['disabled'])
            # Start button remains disabled until a player connects
        else:
            status_var.set(f"Failed to host game. Try a different port.")
    
    def _start_multiplayer_game(self, host_window, parent_window, net_mgr):
        """Start the multiplayer game as host"""
        # Store the network manager for later use
        self.root.network_manager = net_mgr
        
        # Close dialogs
        host_window.destroy()
        parent_window.destroy()
        
        # Start game with multiplayer flag
        self.start_game(multiplayer=True)
    
    def _cancel_hosting(self, host_window, net_mgr):
        """Cancel hosting and close dialog"""
        net_mgr.stop()
        host_window.destroy()
    
    def _show_join_game_dialog(self, parent_window):
        """Show dialog for joining a multiplayer game"""
        join_window = tk.Toplevel(parent_window)
        join_window.title("Join Game")
        join_window.geometry("400x300")
        join_window.resizable(True, True)
        join_window.minsize(400, 300)
        join_window.transient(parent_window)  # Make window modal
        join_window.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(join_window, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Join a Multiplayer Game", font=("Arial", 14, "bold"))
        title_label.pack(anchor='center', pady=(0, 20))
        
        # Create the network manager
        net_mgr = network_manager.NetworkManager()
        
        # Connection information
        info_frame = ttk.LabelFrame(main_frame, text="Connection Information", padding=10)
        info_frame.pack(fill='x', expand=True, pady=10)
        
        ttk.Label(info_frame, text="Host IP:").grid(row=0, column=0, sticky='w', pady=5)
        
        # IP entry
        ip_var = tk.StringVar(value="127.0.0.1")
        ip_entry = ttk.Entry(info_frame, textvariable=ip_var, width=15)
        ip_entry.grid(row=0, column=1, sticky='w', pady=5)
        
        ttk.Label(info_frame, text="Port:").grid(row=1, column=0, sticky='w', pady=5)
        
        # Port entry with default
        port_var = tk.StringVar(value="5555")
        port_entry = ttk.Entry(info_frame, textvariable=port_var, width=10)
        port_entry.grid(row=1, column=1, sticky='w', pady=5)
        
        # Player name
        ttk.Label(info_frame, text="Your Name:").grid(row=2, column=0, sticky='w', pady=5)
        name_var = tk.StringVar(value=f"Player_{random.randint(100, 999)}")
        name_entry = ttk.Entry(info_frame, textvariable=name_var, width=20)
        name_entry.grid(row=2, column=1, sticky='w', pady=5)
        
        # Status area
        status_frame = ttk.LabelFrame(main_frame, text="Status", padding=10)
        status_frame.pack(fill='x', expand=True, pady=10)
        
        status_var = tk.StringVar(value="Enter host information")
        status_label = ttk.Label(status_frame, textvariable=status_var, foreground="blue")
        status_label.pack(anchor='w', pady=5)
        
        # Action buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', expand=True, pady=10)
        
        # Join button
        join_button = ttk.Button(button_frame, text="Join Game", 
                              command=lambda: self._join_game(
                                  net_mgr, 
                                  ip_var.get(), 
                                  int(port_var.get()), 
                                  name_var.get(),
                                  status_var,
                                  join_window,
                                  parent_window))
        join_button.pack(side='left', padx=5)
        
        # Cancel button
        cancel_button = ttk.Button(button_frame, text="Cancel", 
                                command=lambda: self._cancel_joining(join_window, net_mgr))
        cancel_button.pack(side='right', padx=5)
        
        # Handle network status updates
        def on_network_status(status):
            status_var.set(status)
            # If connected, automatically proceed to game
            if "Connected to game" in status:
                # Wait a moment before starting game to ensure initial sync
                join_window.after(1000, lambda: self._join_multiplayer_game(join_window, parent_window, net_mgr))
        
        def on_network_error(error):
            status_var.set(f"Error: {error}")
        
        # Create observer instances
        status_observer = observer.Observer()
        status_observer.observe("network_status", on_network_status)
        join_window.status_observer = status_observer
        
        error_observer = observer.Observer()
        error_observer.observe("network_error", on_network_error)
        join_window.error_observer = error_observer
        
        # Clean up when window closes
        def on_close():
            if join_window.status_observer in observer.Observer._observers:
                observer.Observer._observers.remove(join_window.status_observer)
            if join_window.error_observer in observer.Observer._observers:
                observer.Observer._observers.remove(join_window.error_observer)
            net_mgr.stop()
            join_window.destroy()
            
        join_window.protocol("WM_DELETE_WINDOW", on_close)
    
    def _join_game(self, net_mgr, host, port, player_name, status_var, join_window, parent_window):
        """Join a multiplayer game"""
        net_mgr.player_name = player_name
        status_var.set(f"Connecting to {host}:{port}...")
        if not net_mgr.join_game(host, port):
            status_var.set(f"Failed to connect. Check address and port.")
    
    def _join_multiplayer_game(self, join_window, parent_window, net_mgr):
        """Start the multiplayer game as client"""
        # Store the network manager for later use
        self.root.network_manager = net_mgr
        
        # Close dialogs
        join_window.destroy()
        parent_window.destroy()
        
        # Start game with multiplayer flag
        self.start_game(multiplayer=True)
    
    def _cancel_joining(self, join_window, net_mgr):
        """Cancel joining and close dialog"""
        net_mgr.stop()
        join_window.destroy()
    
    def show_options(self):
        """Show enhanced options dialog with tabbed interface and volume controls"""
        options_window = tk.Toplevel(self.root)
        options_window.title("Options")
        options_window.geometry("400x300")
        options_window.resizable(True, True)
        options_window.minsize(400, 300)
        
        # Create a notebook (tabbed interface)
        notebook = ttk.Notebook(options_window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create the Audio tab
        audio_tab = ttk.Frame(notebook, padding=10)
        notebook.add(audio_tab, text="Audio")
        
        # Create the General tab (placeholder for future settings)
        general_tab = ttk.Frame(notebook, padding=10)
        notebook.add(general_tab, text="General")
        
        # Add title to Audio tab
        ttk.Label(audio_tab, text="Volume Settings", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=3, pady=(0, 10), sticky="w")
        
        # Music Volume Controls
        ttk.Label(audio_tab, text="Music Volume:", font=("Arial", 10)).grid(row=1, column=0, sticky="w", pady=5)
        
        # Music volume variables
        self.music_vol_var = tk.DoubleVar(value=self.sound_mgr.music_volume)
        self.music_mute_var = tk.BooleanVar(value=self.sound_mgr.music_muted)
        
        # Create music volume slider
        music_slider = ttk.Scale(audio_tab, from_=0.0, to=1.0, orient="horizontal", 
                               variable=self.music_vol_var, length=200,
                               command=self._on_music_volume_change)
        music_slider.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        # Create music mute checkbox
        music_mute = ttk.Checkbutton(audio_tab, text="Mute", 
                                  variable=self.music_mute_var, 
                                  command=self._on_music_mute_toggle)
        music_mute.grid(row=1, column=2, padx=5, pady=5, sticky="w")
        
        # Sound Effects Volume Controls
        ttk.Label(audio_tab, text="Sound Effects:", font=("Arial", 10)).grid(row=2, column=0, sticky="w", pady=5)
        
        # SFX volume variables
        self.sfx_vol_var = tk.DoubleVar(value=self.sound_mgr.sfx_volume)
        self.sfx_mute_var = tk.BooleanVar(value=self.sound_mgr.sfx_muted)
        
        # Create SFX volume slider
        sfx_slider = ttk.Scale(audio_tab, from_=0.0, to=1.0, orient="horizontal", 
                             variable=self.sfx_vol_var, length=200,
                             command=self._on_sfx_volume_change)
        sfx_slider.grid(row=2, column=1, padx=5, pady=5, sticky="w")
        
        # Create SFX mute checkbox
        sfx_mute = ttk.Checkbutton(audio_tab, text="Mute", 
                                variable=self.sfx_mute_var, 
                                command=self._on_sfx_mute_toggle)
        sfx_mute.grid(row=2, column=2, padx=5, pady=5, sticky="w")
        
        # Volume indicators (percentage labels)
        self.music_pct_label = ttk.Label(audio_tab, text=f"{int(self.music_vol_var.get() * 100)}%")
        self.music_pct_label.grid(row=1, column=3, padx=5, pady=5, sticky="w")
        
        self.sfx_pct_label = ttk.Label(audio_tab, text=f"{int(self.sfx_vol_var.get() * 100)}%")
        self.sfx_pct_label.grid(row=2, column=3, padx=5, pady=5, sticky="w")
        
        # Add some space for visual clarity
        ttk.Separator(audio_tab, orient='horizontal').grid(row=3, column=0, columnspan=4, sticky='ew', pady=15)
        
        # Test Sound Buttons
        ttk.Label(audio_tab, text="Test Audio:", font=("Arial", 10, "bold")).grid(row=4, column=0, sticky="w", pady=5)
        
        test_music_btn = ttk.Button(audio_tab, text="Test Music", 
                                  command=lambda: self.sound_mgr.play_music("menu"))
        test_music_btn.grid(row=4, column=1, padx=5, pady=5, sticky="w")
        
        test_sfx_btn = ttk.Button(audio_tab, text="Test Sound", 
                                command=lambda: self.sound_mgr.play_sound("dice_roll"))
        test_sfx_btn.grid(row=4, column=2, padx=5, pady=5, sticky="w")
        
        # Add Game Settings to the General tab
        ttk.Label(general_tab, text="Game Settings", font=("Arial", 12, "bold")).pack(pady=(0, 10), anchor='w')
        
        # Player count settings
        player_count_frame = ttk.LabelFrame(general_tab, text="Number of Players", padding=5)
        player_count_frame.pack(fill='x', expand=True, pady=5, anchor='w')
        
        ttk.Radiobutton(player_count_frame, text="2 Players", variable=self.player_count, value=2).pack(anchor='w', pady=2)
        ttk.Radiobutton(player_count_frame, text="4 Players", variable=self.player_count, value=4).pack(anchor='w', pady=2)
        
        # AI difficulty settings
        ai_difficulty_frame = ttk.LabelFrame(general_tab, text="AI Difficulty", padding=5)
        ai_difficulty_frame.pack(fill='x', expand=True, pady=5, anchor='w')
        
        ttk.Radiobutton(ai_difficulty_frame, text="Easy", variable=self.ai_difficulty, value="easy").pack(anchor='w', pady=2)
        ttk.Radiobutton(ai_difficulty_frame, text="Medium", variable=self.ai_difficulty, value="medium").pack(anchor='w', pady=2)
        ttk.Radiobutton(ai_difficulty_frame, text="Hard", variable=self.ai_difficulty, value="hard").pack(anchor='w', pady=2)
        
        # Description text
        description_frame = ttk.Frame(general_tab, padding=5)
        description_frame.pack(fill='x', expand=True, pady=5)
        
        description_text = "Game will include 1 human player and the rest will be AI opponents."
        ttk.Label(description_frame, text=description_text, wraplength=250).pack(pady=5)
        
        # Create Save and Close buttons at the bottom
        button_frame = ttk.Frame(options_window)
        button_frame.pack(side='bottom', fill='x', padx=10, pady=10)
        
        # Define save and close function
        save_and_close = lambda: [self.sound_mgr._save_preferences(), options_window.destroy()]
        
        save_btn = ttk.Button(button_frame, text="Save [S]", command=save_and_close)
        save_btn.pack(side='right', padx=5)
        
        close_btn = ttk.Button(button_frame, text="Close", command=options_window.destroy)
        close_btn.pack(side='right', padx=5)
        
        # Add the 'S' keyboard binding to save options
        options_window.bind('<s>', lambda e: save_and_close())
    
    def _on_music_volume_change(self, value):
        """Handle music volume slider change"""
        volume = float(value)
        self.sound_mgr.set_music_volume(volume)
        self.music_pct_label.config(text=f"{int(volume * 100)}%")
        
        # Update mute checkbox if volume is adjusted while muted
        if volume > 0 and self.music_mute_var.get():
            self.music_mute_var.set(False)
            self.sound_mgr.music_muted = False
    
    def _on_sfx_volume_change(self, value):
        """Handle sound effects volume slider change"""
        volume = float(value)
        self.sound_mgr.set_sfx_volume(volume)
        self.sfx_pct_label.config(text=f"{int(volume * 100)}%")
        
        # Update mute checkbox if volume is adjusted while muted
        if volume > 0 and self.sfx_mute_var.get():
            self.sfx_mute_var.set(False)
            self.sound_mgr.sfx_muted = False
    
    def _on_music_mute_toggle(self):
        """Handle music mute checkbox toggle"""
        is_muted = self.sound_mgr.toggle_music_mute()
        self.music_mute_var.set(is_muted)
    
    def _on_sfx_mute_toggle(self):
        """Handle sound effects mute checkbox toggle"""
        is_muted = self.sound_mgr.toggle_sfx_mute()
        self.sfx_mute_var.set(is_muted)

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720
    
    # Define player colors for visual indicators
    PLAYER_COLORS = ["#FF0000", "#0000FF", "#00CC00", "#FFCC00"]  # Red, Blue, Green, Yellow
    
    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")
        
        root.geometry(f'{self.width}x{self.height}')
        root.resizable(True, True)
        
        # Set minimum window size to prevent UI elements from becoming too small
        root.minsize(800, 600)
        
        # Initialize sound manager
        self.sound_mgr = sound_manager.SoundManager()
        
        # Reference to gameboard (will be set by controller)
        self._gameboard = None
        
        # Track if we're in the main menu or game
        self.in_game = False
        
        # Pass the load dialog method to the MainMenu
        self.main_menu = MainMenu(root, self.start_game, self.sound_mgr, self._show_load_dialog)
        
        # Set up keyboard shortcuts
        self._setup_keyboard_shortcuts()
        
        # Start music event processing
        self._start_music_event_processing()
    
    def _start_music_event_processing(self):
        """Start processing music events for track rotation"""
        # Process music events (checks if music has ended, starts next track)
        if hasattr(self, 'sound_mgr'):
            self.sound_mgr.process_events()
            
            # For game music, check if a track's duration has elapsed
            # This is a fallback mechanism in case get_busy() doesn't detect the end accurately
            if hasattr(self.sound_mgr, 'current_track_start_time') and self.sound_mgr.current_music == "game":
                # Most audio tracks are 2-3 minutes; check after 2.5 minutes just to be sure
                # This is a safety net in case the track ending isn't detected
                if time.time() - self.sound_mgr.current_track_start_time > 150:  # 150 seconds = 2.5 minutes
                    self.sound_mgr._play_next_game_track()
                    self.sound_mgr.current_track_start_time = time.time()
        
        # Schedule the next event processing at a higher frequency (50ms instead of 100ms)
        # This ensures more responsive music transitions
        self.root.after(50, self._start_music_event_processing)
        
    def _setup_keyboard_shortcuts(self):
        """Set up keyboard shortcuts for the game"""
        # Main menu shortcuts
        self.root.bind('<n>', lambda e: self._key_shortcut('new_game'))
        self.root.bind('<m>', lambda e: self._key_shortcut('multiplayer')) # Added Multiplayer shortcut
        self.root.bind('<l>', lambda e: self._key_shortcut('load_game'))   # Added Load Game shortcut
        self.root.bind('<o>', lambda e: self._key_shortcut('options'))
        self.root.bind('<q>', lambda e: self._key_shortcut('quit'))
        
        # Game shortcuts
        self.root.bind('<r>', lambda e: self._key_shortcut('roll'))
        self.root.bind('<p>', lambda e: self._key_shortcut('purchase'))
        # Changed mortgage shortcut key from 'm' to avoid conflict with main menu multiplayer
        self.root.bind('<Control-m>', lambda e: self._key_shortcut('mortgage')) 
        self.root.bind('<u>', lambda e: self._key_shortcut('unmortgage'))
        self.root.bind('<b>', lambda e: self._key_shortcut('bankrupt'))
        self.root.bind('<e>', lambda e: self._key_shortcut('end_turn'))
        self.root.bind('<space>', lambda e: self._key_shortcut('end_turn'))
        
        # Help shortcut
        self.root.bind('<F1>', lambda e: self._key_shortcut('help'))
        self.root.bind('<h>', lambda e: self._key_shortcut('help'))
        
    def _key_shortcut(self, action):
        """Process keyboard shortcuts based on current game state"""
        print(f"Keyboard shortcut: {action}")
        
        # Handle main menu shortcuts if not in game
        if not self.in_game:
            if action == 'new_game' and hasattr(self.main_menu, 'start_game'):
                self.main_menu.start_game()
            elif action == 'multiplayer' and hasattr(self.main_menu, 'show_multiplayer_menu'):
                self.main_menu.show_multiplayer_menu()
            elif action == 'load_game' and hasattr(self.main_menu, 'show_load_dialog'):
                self.main_menu.show_load_dialog()
            elif action == 'options' and hasattr(self.main_menu, 'show_options'):
                self.main_menu.show_options()
            elif action == 'quit':
                self.root.destroy()
            return
                
        # Handle in-game shortcuts
        if action == 'roll':
            self._action_taken('roll')
        elif action == 'purchase':
            self._action_taken('purchase')
        elif action == 'mortgage':
            self._action_taken('mortgage')
        elif action == 'unmortgage':
            self._action_taken('unmortgage')
        elif action == 'bankrupt':
            self._action_taken('bankrupt')
        elif action == 'end_turn':
            self._action_taken('end_turn')
        elif action == 'help':
            self._show_keyboard_help()
        
    def start_game(self):
        """Start the game after menu selection"""
        # Create the main game frame
        self.main_frame = ttk.Frame(self.root, padding=10, relief='groove')
        
        # Create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()
        
        # Pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()
        
        # Mark that we're now in the game (for keyboard shortcuts)
        self.in_game = True

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        self.observe("ai_decision", self._display_ai_decision)
        
        # Initialize game timer and turn counter
        self.game_seconds = 0
        self.turn_count = 1
        self._start_game_timer()

    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        
        # Load the board image and scale it down (original is 2928x2928)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        # Scale down to approximately 1/6 of original size to fix UI cutoff issues
        scaled_board_image = board_image.subsample(6, 6)  # Scale down by factor of 6
        
        board = ttk.Label(middle_frame, image=scaled_board_image)
        board.pack(side='left', anchor='n', padx=50)  # Reduce padding to fit better
        board.image = scaled_board_image  # Keep a reference

        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        # Create info panel
        info_frame = ttk.Frame(middle_frame, padding=10, relief='raised', borderwidth=2)
        info_frame.pack(side='right', anchor='n', padx=20, pady=20)
        
        # Player info section
        player_info_frame = ttk.LabelFrame(info_frame, text="Player Information", padding=5)
        player_info_frame.pack(fill='x', expand=True, pady=5)
        
        self.current_player_label = ttk.Label(player_info_frame, text="Current Player: Player 0")
        self.current_player_label.pack(anchor='w', pady=2)
        
        self.player_money_label = ttk.Label(player_info_frame, text="Money: $1500")
        self.player_money_label.pack(anchor='w', pady=2)
        
        self.player_position_label = ttk.Label(player_info_frame, text="Position: Go")
        self.player_position_label.pack(anchor='w', pady=2)
        
        # Properties section
        properties_frame = ttk.LabelFrame(info_frame, text="Owned Properties", padding=5)
        properties_frame.pack(fill='x', expand=True, pady=5)
        
        self.properties_list = tk.Listbox(properties_frame, height=5, width=25)
        self.properties_list.pack(fill='both', expand=True)
        
        # Dice history section
        dice_frame = ttk.LabelFrame(info_frame, text="Last Dice Rolls", padding=5)
        dice_frame.pack(fill='x', expand=True, pady=5)
        
        self.dice_history = tk.Listbox(dice_frame, height=3, width=25)
        self.dice_history.pack(fill='both', expand=True)
        
        # Game statistics
        stats_frame = ttk.LabelFrame(info_frame, text="Game Statistics", padding=5)
        stats_frame.pack(fill='x', expand=True, pady=5)
        
        self.turn_count_label = ttk.Label(stats_frame, text="Turn: 1")
        self.turn_count_label.pack(anchor='w', pady=2)
        
        self.game_time_label = ttk.Label(stats_frame, text="Game Time: 00:00")
        self.game_time_label.pack(anchor='w', pady=2)
        
        # AI Decision Log section
        ai_log_frame = ttk.LabelFrame(info_frame, text="AI Actions", padding=5)
        ai_log_frame.pack(fill='x', expand=True, pady=5)
        
        self.ai_log = tk.Text(ai_log_frame, height=4, width=25, wrap=tk.WORD)
        self.ai_log.pack(fill='both', expand=True)
        
        # Make the AI log text readonly but allow copying
        self.ai_log.config(state=tk.DISABLED)

        button_frame = ttk.Frame(middle_frame, padding=10)

        #create buttons with keyboard shortcut indicators
        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice [R]", command=lambda: self._action_taken("roll"))
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase [P]", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        # Updated mortgage button text to reflect new shortcut
        self.mortgage_button = ttk.Button(button_frame, text="Mortgage [Ctrl+M]", command=lambda: self._action_taken("mortgage")) 
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage [U]", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt [B]", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn [E/Space]", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)
        
        # Add help button
        self.help_button = ttk.Button(button_frame, text="Help [F1]", command=lambda: self._show_keyboard_help())
        self.help_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.help_button)
        
        # Add Return to Main Menu button
        self.menu_button = ttk.Button(button_frame, text="Main Menu", command=lambda: self._show_return_to_menu_dialog())
        self.menu_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.menu_button)
        
        # Add Save/Load Game buttons
        self.save_button = ttk.Button(button_frame, text="Save Game", command=lambda: self._show_save_dialog())
        self.save_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.save_button)
        
        self.load_button = ttk.Button(button_frame, text="Load Game", command=lambda: self._show_load_dialog())
        self.load_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.load_button)

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        return middle_frame

    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

        # Reduce width and height slightly to ensure it fits well
        self.state_box = tk.Text(msg_frame, width=50, height=8, background='black', foreground='white')
        self.state_box.pack(side='left', padx=(50,20))

        self.text_box = tk.Text(msg_frame, width=50, height=8, background='black', foreground='white')
        self.text_box.pack(side='left', padx=(20,50))

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action):
        """Handle button click actions with sound effects"""
        
        if action == "roll":
            # Play dice roll sound
            self.sound_mgr.play_sound("dice_roll")
            # Tell the controller roll was clicked
            observer.Event("roll", None)

        elif action == "purchase":
            # Play purchase sound
            self.sound_mgr.play_sound("buy_property")
            observer.Event("purchase", None)

        elif action == "mortgage":
            # Play mortgage sound
            self.sound_mgr.play_sound("mortgage")
            observer.Event("mortgage", None)

        elif action == "unmortgage":
            # Play unmortgage sound
            self.sound_mgr.play_sound("mortgage")
            observer.Event("unmortgage", None)

        elif action == "mortgage_specific":
            # Play mortgage sound
            self.sound_mgr.play_sound("mortgage")
            observer.Event("mortgage_specific", 0)

        elif action == "bankrupt":
            # Play bankrupt sound
            self.sound_mgr.play_sound("go_bankrupt")
            observer.Event("bankrupt", None)

        elif action == "end_turn":
            # Play end turn sound
            self.sound_mgr.play_sound("end_turn")
            observer.Event("end_turn", self._clear_text)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        #good idea disable all buttons

        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                        command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)

    def _start_game_timer(self):
        """Start the game timer that updates every second"""
        self.game_seconds += 1
        minutes = self.game_seconds // 60
        seconds = self.game_seconds % 60
        self.game_time_label.config(text=f"Game Time: {minutes:02d}:{seconds:02d}")
        # Schedule the next timer update
        self.root.after(1000, self._start_game_timer)
    
    def update_player_info(self, player):
        """Update player information in the UI with color indicators"""
        try:
            if not hasattr(self, 'current_player_label'):
                print("Warning: current_player_label not found")
                return
                
            # Check if the label's master still exists
            try:
                self.current_player_label.master.winfo_exists()
            except Exception as e:
                print(f"Warning: current_player_label.master doesn't exist: {e}")
                return
            
            # Get player index for color (player 0 = red, player 1 = blue, etc.)
            player_index = 0
            try:
                # Try to extract player index from name (e.g., "Player 1" -> index 1)
                if player.name.startswith("Player "):
                    player_index = int(player.name.split(" ")[1]) % len(self.PLAYER_COLORS)
            except:
                player_index = 0
                
            player_color = self.PLAYER_COLORS[player_index]
            
            # Update player name with colored indicator
            colored_square = "■"  # Unicode square symbol
            
            # Safely handle player indicator frame
            try:
                # Create a temporary frame to hold colored elements
                if hasattr(self, 'player_indicator_frame') and self.player_indicator_frame.winfo_exists():
                    self.player_indicator_frame.destroy()
                
                self.player_indicator_frame = ttk.Frame(self.current_player_label.master)
                self.player_indicator_frame.pack(anchor='w', pady=2)
                
                # Remove the old label if it exists
                if hasattr(self, 'current_player_label') and self.current_player_label.winfo_exists():
                    self.current_player_label.destroy()
                
                # Create new player label with colored indicator
                player_label = ttk.Label(self.player_indicator_frame, text="Current Player: ")
                player_label.pack(side='left')
                
                # Colored square indicator
                player_color_indicator = ttk.Label(self.player_indicator_frame, 
                                             text=colored_square,
                                             foreground=player_color)
                player_color_indicator.pack(side='left')
                
                # Player name
                player_name_label = ttk.Label(self.player_indicator_frame, 
                                         text=f" {player.name}")
                player_name_label.pack(side='left')
                
                # Store reference to main label
                self.current_player_label = player_label
            except Exception as e:
                print(f"Error updating player indicator: {e}")
            
            # Update money
            self.player_money_label.config(text=f"Money: ${player.money}")
            
            # Get position name from the square
            position_name = "Unknown"
            old_position = getattr(self, '_last_position', 0)
            
            try:
                square = self._gameboard.get_square(player.position)
                position_name = square.name
            except:
                position_name = f"Position {player.position}"
            
            # Create colored position indicator with player color
            colored_square = "■"  # Unicode square symbol
            
            # Create a temporary frame to hold colored elements
            try:
                if hasattr(self, 'position_indicator_frame') and self.position_indicator_frame.winfo_exists():
                    self.position_indicator_frame.destroy()
                
                self.position_indicator_frame = ttk.Frame(self.player_position_label.master)
                self.position_indicator_frame.pack(anchor='w', pady=2)
                
                # Remove the old label if it exists
                if hasattr(self, 'player_position_label') and self.player_position_label.winfo_exists():
                    self.player_position_label.destroy()
            except Exception as e:
                print(f"Error updating position indicator: {e}")
                return
            
            # Create new position label with colored indicator
            position_label = ttk.Label(self.position_indicator_frame, text="Position: ")
            position_label.pack(side='left')
            
            # Colored square indicator
            color_indicator = ttk.Label(self.position_indicator_frame, 
                                     text=colored_square,
                                     foreground=player_color)
            color_indicator.pack(side='left')
            
            # Position name
            position_name_label = ttk.Label(self.position_indicator_frame, 
                                         text=f" {position_name}")
            position_name_label.pack(side='left')
            
            # Store reference to main label
            self.player_position_label = position_label
            
            # Store current position for next update
            self._last_position = player.position
            
            # Add movement text to text box if position changed
            if hasattr(self, '_last_position') and old_position != player.position:
                try:
                    old_square = self._gameboard.get_square(old_position)
                    new_square = self._gameboard.get_square(player.position)
                    self._update_text(f"{player.name} moved from {old_square.name} to {new_square.name}")
                except:
                    pass
            
            # Update properties list with ownership colors
            self.update_properties_list(player, player_color)
        except Exception as e:
            print(f"Error updating player info: {e}")
    
    def update_properties_list(self, player, player_color="#000000"):
        """Update the properties listbox with player's owned properties and color indicators"""
        if hasattr(self, 'properties_list'):
            self.properties_list.delete(0, tk.END)
            
            if hasattr(player, 'deed_names') and player.deed_names:
                # Create a colored listbox with property names
                colored_square = "■"  # Unicode square symbol
                
                for prop in player.deed_names:
                    prop_text = f"{colored_square} {prop}"
                    self.properties_list.insert(tk.END, prop_text)
                    
                    # Set the color for this item (tag each line with a unique tag)
                    tag_name = f"prop_{self.properties_list.size()-1}"
                    self.properties_list.itemconfig(tk.END, foreground=player_color)
            else:
                self.properties_list.insert(tk.END, "No properties owned")
    
    def add_dice_roll(self, dice1, dice2):
        """Add a dice roll to the history with colored indicator for player"""
        if hasattr(self, 'dice_history'):
            # Keep only the last 3 rolls
            if self.dice_history.size() >= 3:
                self.dice_history.delete(0)
            
            # Get player index for color
            player_index = 0
            try:
                if hasattr(self, '_gameboard') and self._gameboard:
                    current_player = self._gameboard.get_current_player()
                    if current_player.name.startswith("Player "):
                        player_index = int(current_player.name.split(" ")[1]) % len(self.PLAYER_COLORS)
            except:
                player_index = 0
            
            # Get player color
            player_color = self.PLAYER_COLORS[player_index]
            
            # Add colored square to the roll text
            colored_square = "■"  # Unicode square symbol
            roll_text = f"{colored_square} Roll: {dice1} + {dice2} = {dice1 + dice2}"
            if dice1 == dice2:
                roll_text += " (Doubles!)"
            
            # Add the roll with player color
            self.dice_history.insert(tk.END, roll_text)
            self.dice_history.itemconfig(tk.END, foreground=player_color)
    
    def increment_turn_count(self):
        """Increment the turn counter"""
        if hasattr(self, 'turn_count_label'):
            self.turn_count += 1
            self.turn_count_label.config(text=f"Turn: {self.turn_count}")
    
    def _display_ai_decision(self, data):
        """Display AI decision in the AI log with enhanced visual feedback
        data: Tuple of (decision_text, reason)
        """
        if hasattr(self, 'ai_log'):
            try:
                # Make sure we have valid data
                if not data or not isinstance(data, tuple) or len(data) < 2:
                    print(f"Invalid AI decision data: {data}")
                    return
                
                decision_text, reason = data
                
                # Get player index for color from the decision text (e.g., "Player 2 will...")
                player_index = 0
                for i in range(len(self.PLAYER_COLORS)):
                    if f"Player {i}" in decision_text:
                        player_index = i
                        break
                
                player_color = self.PLAYER_COLORS[player_index]
                print(f"Displaying AI decision: {decision_text} - {reason}")
                
                # Enable text editing temporarily
                self.ai_log.config(state=tk.NORMAL)
                
                # Clear log if it's getting too long (keep last 10 lines)
                lines = self.ai_log.get('1.0', tk.END).split('\n')
                if len(lines) > 12:  # 10 lines + potential empty lines
                    self.ai_log.delete('1.0', tk.END)
                
                # Insert separator for better visual separation between entries
                if lines and len(lines) > 1 and lines[0].strip():
                    self.ai_log.insert(tk.END, "───────────────────────\n", "separator")
                
                # Insert new decision with timestamp
                minutes = self.game_seconds // 60
                seconds = self.game_seconds % 60
                timestamp = f"[{minutes:02d}:{seconds:02d}] "
                
                # Determine action type icon
                action_icon = "⚫ "  # Default - Generic action
                if "purchase" in decision_text.lower():
                    action_icon = "💰 "  # Money/purchase action
                elif "mortgage" in decision_text.lower():
                    action_icon = "🏦 "  # Bank/mortgage action
                elif "cannot afford" in decision_text.lower() or "cannot purchase" in decision_text.lower():
                    action_icon = "❌ "  # Cannot do something
                elif "move" in decision_text.lower() or "roll" in decision_text.lower():
                    action_icon = "🎲 "  # Dice/movement
                elif "turn" in decision_text.lower() or "end" in decision_text.lower():
                    action_icon = "⏩ "  # Next/end turn
                
                # Insert text with enhanced formatting
                self.ai_log.insert(tk.END, timestamp, "timestamp")
                self.ai_log.insert(tk.END, action_icon + decision_text + "\n", "decision")
                
                # Insert reason with improved styling
                if reason:
                    self.ai_log.insert(tk.END, "   ↪ " + reason + "\n", "reason")
                
                # Configure tags for styling
                self.ai_log.tag_configure("separator", foreground="#999999")
                self.ai_log.tag_configure("timestamp", foreground="gray")
                self.ai_log.tag_configure("decision", foreground=player_color, font=("Arial", 9, "bold"))
                self.ai_log.tag_configure("reason", foreground="#555555", font=("Arial", 8, "italic"))
                
                # Configure background color for latest entry to make it stand out
                self.ai_log.tag_add("latest", f"end-{3 if reason else 2} lines", "end-1c")
                bg_color = self._lighten_color(player_color, 0.85)  # Create a light background based on player color
                self.ai_log.tag_configure("latest", background=bg_color)
                
                # Scroll to the end
                self.ai_log.see(tk.END)
                
                # Disable editing again
                self.ai_log.config(state=tk.DISABLED)
                
                # Also add to main text box for visibility with the same icons
                self._update_text(action_icon + decision_text)
                if reason:
                    self._update_text(f"   ↪ {reason}")
            except Exception as e:
                print(f"Error in AI decision display: {e}")
                # Try to log the error to the AI log itself
                try:
                    self.ai_log.config(state=tk.NORMAL)
                    self.ai_log.insert(tk.END, f"[Error displaying AI decision: {e}]\n", "error")
                    self.ai_log.tag_configure("error", foreground="red")
                    self.ai_log.config(state=tk.DISABLED)
                except:
                    pass
    
    def _lighten_color(self, hex_color, factor=0.7):
        """Create a lighter version of the given color for backgrounds
        hex_color: Color in format #RRGGBB
        factor: How much to lighten (0-1, higher is lighter)
        Returns: New color in #RRGGBB format
        """
        # Remove # if present
        hex_color = hex_color.lstrip('#')
        
        # Convert to RGB
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        
        # Lighten
        r = min(255, int(r + (255 - r) * factor))
        g = min(255, int(g + (255 - g) * factor))
        b = min(255, int(b + (255 - b) * factor))
        
        # Convert back to hex
        return f"#{r:02x}{g:02x}{b:02x}"

    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

    def _show_keyboard_help(self):
        """Display a help dialog with keyboard shortcuts"""
        help_window = tk.Toplevel(self.root)
        help_window.title("Keyboard Shortcuts")
        help_window.geometry("400x500")
        help_window.resizable(True, True)
        help_window.minsize(400, 400)
        
        # Main frame
        main_frame = ttk.Frame(help_window, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Keyboard Shortcuts", font=("Arial", 14, "bold"))
        title_label.pack(anchor='center', pady=(0, 20))
        
        # Game shortcuts
        game_frame = ttk.LabelFrame(main_frame, text="Game Controls", padding=10)
        game_frame.pack(fill='x', expand=True, pady=5)
        
        game_shortcuts = [
            ("R", "Roll Dice"),
            ("P", "Purchase Property"),
            ("Ctrl+M", "Mortgage Properties"), # Updated shortcut display
            ("U", "Unmortgage Properties"),
            ("B", "Go Bankrupt"),
            ("E or Space", "End Turn"),
            ("F1 or H", "Show This Help")
        ]
        
        for i, (key, desc) in enumerate(game_shortcuts):
            ttk.Label(game_frame, text=key, font=("Arial", 10, "bold")).grid(row=i, column=0, sticky='w', padx=(5, 20), pady=3)
            ttk.Label(game_frame, text=desc).grid(row=i, column=1, sticky='w', pady=3)
        
        # Menu shortcuts
        menu_frame = ttk.LabelFrame(main_frame, text="Menu Controls", padding=10)
        menu_frame.pack(fill='x', expand=True, pady=10)
        
        menu_shortcuts = [
            ("N", "New Game"),
            ("M", "Multiplayer"), # Added shortcut display
            ("L", "Load Game"),   # Added shortcut display
            ("O", "Options"),
            ("Q", "Quit Game")
        ]
        
        for i, (key, desc) in enumerate(menu_shortcuts):
            ttk.Label(menu_frame, text=key, font=("Arial", 10, "bold")).grid(row=i, column=0, sticky='w', padx=(5, 20), pady=3)
            ttk.Label(menu_frame, text=desc).grid(row=i, column=1, sticky='w', pady=3)
        
        # Close button
        close_button = ttk.Button(main_frame, text="Close", command=help_window.destroy)
        close_button.pack(side='bottom', pady=20)
        
    def _show_return_to_menu_dialog(self):
        """Show a confirmation dialog for returning to the main menu"""
        # Create a dialog window
        dialog = tk.Toplevel(self.root)
        dialog.title("Return to Main Menu")
        dialog.geometry("400x250")
        dialog.resizable(False, False)
        dialog.transient(self.root)  # Make window modal
        dialog.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Warning icon
        warning_label = ttk.Label(main_frame, text="⚠️", font=("Arial", 32))
        warning_label.pack(pady=(0, 10))
        
        # Title
        title_label = ttk.Label(main_frame, text="Return to Main Menu?", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Warning message
        message = "Any unsaved progress will be lost. Would you like to save your game before returning to the main menu?"
        message_label = ttk.Label(main_frame, text=message, wraplength=350, justify='center')
        message_label.pack(pady=(0, 20))
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', expand=True)
        
        # Pass the _return_to_main_menu method as a callback to be executed after saving
        save_return_btn = ttk.Button(button_frame, text="Save and Return", 
                                   command=lambda: self._show_save_dialog(parent_window=dialog, on_save_callback=self._return_to_main_menu))
        save_return_btn.pack(side='left', padx=5, expand=True, fill='x')
        
        return_btn = ttk.Button(button_frame, text="Return without Saving", 
                             command=lambda: [dialog.destroy(), self._return_to_main_menu()])
        return_btn.pack(side='left', padx=5, expand=True, fill='x')
        
        cancel_btn = ttk.Button(button_frame, text="Cancel", 
                            command=dialog.destroy)
        cancel_btn.pack(side='left', padx=5, expand=True, fill='x')
    
    def _return_to_main_menu(self):
        """Return to the main menu"""
        # Hide the game UI
        if hasattr(self, 'main_frame') and self.main_frame:
            self.main_frame.pack_forget()
        
        # Reset game state indicators
        self.in_game = False
        
        # Stop in-game music and play menu music
        self.sound_mgr.play_music("menu")
        
        # Create a new main menu (passing the load dialog callback)
        self.main_menu = MainMenu(self.root, self.start_game, self.sound_mgr, self._show_load_dialog)
        
        # Fire an event to notify the controller
        observer.Event("return_to_menu", None)
    
    def _show_save_dialog(self, parent_window=None, on_save_callback=None):
        """Show a dialog for saving the game
        
        Args:
            parent_window: Optional parent window (for closing after save)
            on_save_callback: Optional function to call after successful save
        """
        if parent_window is None:
            parent_window = self.root
            
        # Create a dialog window
        save_dialog = tk.Toplevel(parent_window)
        save_dialog.title("Save Game")
        save_dialog.geometry("400x200")
        save_dialog.resizable(False, False)
        save_dialog.transient(parent_window)  # Make window modal
        save_dialog.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(save_dialog, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Create timestamp for display
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Label
        title_label = ttk.Label(main_frame, text="Save Game", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Save name entry
        name_frame = ttk.Frame(main_frame)
        name_frame.pack(fill='x', expand=True, pady=10)
        
        ttk.Label(name_frame, text="Save Name:").pack(side='left', padx=(0, 10))
        
        # Default save name with date
        default_name = f"Monopoly Game {datetime.datetime.now().strftime('%Y-%m-%d')}"
        name_var = tk.StringVar(value=default_name)
        name_entry = ttk.Entry(name_frame, textvariable=name_var, width=30)
        name_entry.pack(side='left', fill='x', expand=True)
        
        # Timestamp display
        timestamp_frame = ttk.Frame(main_frame)
        timestamp_frame.pack(fill='x', expand=True, pady=5)
        
        ttk.Label(timestamp_frame, text="Date & Time:").pack(side='left', padx=(0, 10))
        ttk.Label(timestamp_frame, text=timestamp).pack(side='left')
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', expand=True, pady=(20, 0))
        
        # Define the save action, including the optional callback
        def save_action():
            self._save_game(name_var.get())
            save_dialog.destroy()
            self._show_save_success_notification()
            if on_save_callback:
                on_save_callback() # Execute the callback if provided

        save_btn = ttk.Button(button_frame, text="Save", command=save_action)
        save_btn.pack(side='left', padx=5, expand=True, fill='x')
        
        cancel_btn = ttk.Button(button_frame, text="Cancel", 
                             command=save_dialog.destroy)
        cancel_btn.pack(side='left', padx=5, expand=True, fill='x')
        
    def _save_game(self, custom_name):
        """Save the game with the given name
        
        Args:
            custom_name: Custom name for the save file
        """
        # Emit an event for the controller to handle
        observer.Event("save_game", custom_name)
    
    def _show_save_success_notification(self):
        """Show a small notification that the game was saved successfully"""
        # Create a small window that automatically closes after a few seconds
        notification = tk.Toplevel(self.root)
        notification.title("")
        notification.geometry("300x100")
        notification.resizable(False, False)
        notification.overrideredirect(True)  # No window decoration
        
        # Position near the bottom right of the main window
        x = self.root.winfo_x() + self.root.winfo_width() - 320
        y = self.root.winfo_y() + self.root.winfo_height() - 120
        notification.geometry(f"+{x}+{y}")
        
        # Main frame with border
        main_frame = ttk.Frame(notification, padding=10, relief='raised', borderwidth=2)
        main_frame.pack(fill='both', expand=True)
        
        # Success message
        ttk.Label(main_frame, text="✅ Game Saved Successfully", 
               font=("Arial", 12, "bold")).pack(pady=(10, 5))
        
        # Set a timer to close the notification
        notification.after(3000, notification.destroy)
    
    def _show_load_dialog(self):
        """Show a dialog for loading a saved game"""
        # Create a dialog window
        load_dialog = tk.Toplevel(self.root)
        load_dialog.title("Load Game")
        load_dialog.geometry("500x400")
        load_dialog.resizable(True, True)
        load_dialog.minsize(500, 400)
        load_dialog.transient(self.root)  # Make window modal
        load_dialog.grab_set()  # Make window modal
        
        # Main frame
        main_frame = ttk.Frame(load_dialog, padding=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text="Load Game", font=("Arial", 14, "bold"))
        title_label.pack(anchor='center', pady=(0, 20))
        
        # Create a frame for the save files list
        list_frame = ttk.LabelFrame(main_frame, text="Saved Games", padding=10)
        list_frame.pack(fill='both', expand=True, pady=10)
        
        # Scrolled list of save files
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        save_listbox = tk.Listbox(list_frame, height=10, width=50, 
                                 font=("Arial", 10),
                                 yscrollcommand=scrollbar.set)
        save_listbox.pack(fill='both', expand=True, pady=5)
        scrollbar.config(command=save_listbox.yview)
        
        # Select the first item by default if any exist
        def on_load_dialog_shown():
            # Populate the listbox with saved games
            observer.Event("get_save_list", save_listbox)
            if save_listbox.size() > 0:
                save_listbox.select_set(0)
        
        # Call after the dialog is shown
        load_dialog.after(100, on_load_dialog_shown)
        
        # Details section
        details_frame = ttk.LabelFrame(main_frame, text="Details", padding=10)
        details_frame.pack(fill='x', expand=True, pady=10)
        
        details_text = tk.Text(details_frame, height=4, width=50, wrap=tk.WORD, state='disabled')
        details_text.pack(fill='both', expand=True)
        
        # Update details when selection changes
        def on_save_selected(event):
            # Get selected index
            selected_indices = save_listbox.curselection()
            if not selected_indices:
                return
                
            selected_index = selected_indices[0]
            selected_path = save_listbox.get(selected_index).split(" | ")[0]  # Assume format "path | display_name"
            
            # Request details for the selected save
            observer.Event("get_save_details", (selected_path, details_text))
        
        save_listbox.bind('<<ListboxSelect>>', on_save_selected)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', expand=True, pady=10)
        
        load_btn = ttk.Button(button_frame, text="Load Game", 
                           command=lambda: self._load_selected_game(save_listbox, load_dialog))
        load_btn.pack(side='left', padx=5)
        
        browse_btn = ttk.Button(button_frame, text="Browse...", 
                             command=lambda: self._browse_for_save(save_listbox))
        browse_btn.pack(side='left', padx=5)
        
        # Include autosaves checkbox
        autosave_var = tk.BooleanVar(value=True)
        autosave_check = ttk.Checkbutton(button_frame, text="Include Autosaves", 
                                       variable=autosave_var,
                                       command=lambda: observer.Event("get_save_list", 
                                                                  (save_listbox, autosave_var.get())))
        autosave_check.pack(side='left', padx=20)
        
        cancel_btn = ttk.Button(button_frame, text="Cancel", 
                             command=load_dialog.destroy)
        cancel_btn.pack(side='right', padx=5)
    
    def _load_selected_game(self, listbox, dialog):
        """Load the selected game from the listbox
        
        Args:
            listbox: The listbox with saved games
            dialog: The dialog window to close
        """
        selected_indices = listbox.curselection()
        if not selected_indices:
            return
            
        selected_index = selected_indices[0]
        selected_path = listbox.get(selected_index).split(" | ")[0]  # Assume format "path | display_name"
        
        # Close the dialog
        dialog.destroy()
        
        # Emit an event for the controller to handle
        observer.Event("load_game", selected_path)
    
    def _browse_for_save(self, listbox):
        """Browse for a save file
        
        Args:
            listbox: The listbox to update with the selected file
        """
        from tkinter import filedialog
        
        # Open file dialog
        file_path = filedialog.askopenfilename(
            title="Load Saved Game",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")],
            initialdir=os.path.join(os.getcwd(), "saves")
        )
        
        if file_path:
            # Emit an event to check and add the file to the list
            observer.Event("check_external_save", (file_path, listbox))
    
    def show_autosave_notification(self):
        """Show a small notification that the game was autosaved"""
        # Create a small window that automatically closes after a few seconds
        notification = tk.Toplevel(self.root)
        notification.title("")
        notification.geometry("300x80")
        notification.resizable(False, False)
        notification.overrideredirect(True)  # No window decoration
        notification.attributes('-topmost', True)  # Keep on top
        
        # Position near the bottom right of the main window
        x = self.root.winfo_x() + self.root.winfo_width() - 320
        y = self.root.winfo_y() + self.root.winfo_height() - 100
        notification.geometry(f"+{x}+{y}")
        
        # Main frame with border
        main_frame = ttk.Frame(notification, padding=10, relief='raised', borderwidth=1)
        main_frame.pack(fill='both', expand=True)
        
        # Success message
        ttk.Label(main_frame, text="🕒 Game Autosaved", 
               font=("Arial", 10)).pack(pady=(5, 0))
        
        # Set a timer to close the notification
        notification.after(2000, notification.destroy)

'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()
