"""
Styles module for the Monopoly game
Contains color definitions, fonts, and other UI styling constants
"""

# Color Scheme
PRIMARY_COLOR = "#006400"  # Dark green - money/Monopoly theme
SECONDARY_COLOR = "#F5F5DC"  # Beige - for backgrounds
ACCENT_COLOR_1 = "#B22222"  # Red - for highlighting/buttons
ACCENT_COLOR_2 = "#1E3F66"  # Blue - for highlighting/buttons
TEXT_COLOR = "#333333"  # Dark gray for regular text
HEADING_COLOR = "#000000"  # Black for headings

# Panel styles
PANEL_BG = "#FFFFFF"  # White
PANEL_BORDER = "#CCCCCC"  # Light gray
PANEL_RELIEF = "groove"
PANEL_BORDERWIDTH = 1

# Button styles
BUTTON_BG = PRIMARY_COLOR
BUTTON_FG = "#FFFFFF"  # White text on buttons
BUTTON_ACTIVE_BG = "#008800"  # Slightly lighter green when active
BUTTON_PADDING_X = 10
BUTTON_PADDING_Y = 5
BUTTON_FONT = ("Arial", 10, "bold")
BUTTON_WIDTH = 15

# Text styles
HEADING_FONT = ("Arial", 16, "bold")
SUBHEADING_FONT = ("Arial", 12, "bold")
LABEL_FONT = ("Arial", 10)
TEXT_FONT = ("Arial", 9)

# Info panel styles
INFO_PANEL_BG = "#F8F8F8"  # Very light gray
INFO_PANEL_BORDER = "#E0E0E0"  # Light gray
INFO_PANEL_TITLE_BG = PRIMARY_COLOR
INFO_PANEL_TITLE_FG = "#FFFFFF"  # White

# Message box styles
MSG_BOX_BG = "#000000"  # Black
MSG_BOX_FG = "#FFFFFF"  # White
MSG_BOX_FONT = ("Courier New", 10)

# List box styles
LIST_BOX_BG = "#FFFFFF"  # White
LIST_BOX_FG = TEXT_COLOR
LIST_BOX_SELECT_BG = PRIMARY_COLOR
LIST_BOX_SELECT_FG = "#FFFFFF"  # White
