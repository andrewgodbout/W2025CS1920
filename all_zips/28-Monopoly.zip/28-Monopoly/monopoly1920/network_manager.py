import socket
import threading
import json
import time
import queue
import random
import observer

class NetworkManager:
    """Handles peer-to-peer networking for multiplayer games"""
    
    # Message types
    MSG_CONNECT = 'connect'
    MSG_DISCONNECT = 'disconnect'
    MSG_GAME_STATE = 'game_state'
    MSG_ACTION = 'action'
    MSG_CHAT = 'chat'
    MSG_PING = 'ping'
    
    def __init__(self):
        """Initialize the network manager"""
        self.socket = None
        self.host_mode = False
        self.clients = []  # List of connected clients (for host)
        self.host_address = None  # Host address (for client)
        self.server_thread = None
        self.receive_thread = None
        self.running = False
        self.player_name = f"Player_{random.randint(1000, 9999)}"
        self.message_queue = queue.Queue()
        self.last_ping_time = 0
        self.ping_interval = 5  # Seconds between ping messages
        
    def start_host(self, port=5555):
        """Start hosting a game on the specified port"""
        if self.running:
            print("Network already running")
            return False
            
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Bind to all interfaces
            self.socket.bind(('0.0.0.0', port))
            self.socket.listen(5)
            
            self.host_mode = True
            self.running = True
            
            # Start server thread to accept connections
            self.server_thread = threading.Thread(target=self._accept_connections)
            self.server_thread.daemon = True
            self.server_thread.start()
            
            # Notify UI that hosting started
            observer.Event("network_status", f"Hosting game on port {port}")
            
            print(f"Game hosted on port {port}")
            return True
            
        except Exception as e:
            print(f"Error starting host: {e}")
            observer.Event("network_error", f"Failed to host game: {e}")
            return False
    
    def join_game(self, host, port=5555):
        """Join a game hosted at the specified address and port"""
        if self.running:
            print("Network already running")
            return False
            
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
            
            self.host_address = (host, port)
            self.host_mode = False
            self.running = True
            
            # Start receive thread
            self.receive_thread = threading.Thread(target=self._receive_messages)
            self.receive_thread.daemon = True
            self.receive_thread.start()
            
            # Send connection message
            self._send_message({
                'type': self.MSG_CONNECT,
                'player_name': self.player_name,
                'timestamp': time.time()
            })
            
            # Notify UI that connection succeeded
            observer.Event("network_status", f"Connected to game at {host}:{port}")
            
            print(f"Connected to game at {host}:{port}")
            return True
            
        except Exception as e:
            print(f"Error joining game: {e}")
            observer.Event("network_error", f"Failed to join game: {e}")
            return False
    
    def stop(self):
        """Stop the network manager and close all connections"""
        if not self.running:
            return
            
        # Send disconnect message if we're a client
        if not self.host_mode and self.socket:
            try:
                self._send_message({
                    'type': self.MSG_DISCONNECT,
                    'player_name': self.player_name,
                    'timestamp': time.time()
                })
            except:
                pass
                
        # Close all client connections if we're a host
        if self.host_mode:
            for client in self.clients:
                try:
                    client['socket'].close()
                except:
                    pass
                    
        # Set running flag to false to stop threads
        self.running = False
        
        # Close main socket
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
                
        self.socket = None
        self.clients = []
        self.host_address = None
        print("Network stopped")
        observer.Event("network_status", "Disconnected")
    
    def send_game_action(self, action_type, action_data):
        """Send a game action to all other players"""
        if not self.running:
            return False
            
        message = {
            'type': self.MSG_ACTION,
            'action_type': action_type,
            'action_data': action_data,
            'player_name': self.player_name,
            'timestamp': time.time()
        }
        
        if self.host_mode:
            # Host sends to all clients
            return self._broadcast_message(message)
        else:
            # Client sends to host
            return self._send_message(message)
    
    def send_game_state(self, game_state):
        """Send the full game state to all clients (host only)"""
        if not self.running or not self.host_mode:
            return False
            
        message = {
            'type': self.MSG_GAME_STATE,
            'game_state': game_state,
            'timestamp': time.time()
        }
        
        return self._broadcast_message(message)
    
    def send_chat_message(self, text):
        """Send a chat message to all other players"""
        if not self.running:
            return False
            
        message = {
            'type': self.MSG_CHAT,
            'text': text,
            'player_name': self.player_name,
            'timestamp': time.time()
        }
        
        if self.host_mode:
            # Host broadcasts to all clients
            return self._broadcast_message(message)
        else:
            # Client sends to host
            return self._send_message(message)
    
    def process_messages(self):
        """Process any received messages in the queue
        Call this periodically from the main game loop
        Returns list of processed messages
        """
        processed = []
        
        # Send ping if needed
        current_time = time.time()
        if current_time - self.last_ping_time > self.ping_interval:
            self._send_ping()
            self.last_ping_time = current_time
        
        # Process all available messages
        while not self.message_queue.empty():
            try:
                message = self.message_queue.get_nowait()
                self._handle_message(message)
                processed.append(message)
            except queue.Empty:
                break
        
        return processed
    
    def _accept_connections(self):
        """Thread function to accept client connections (host only)"""
        print("Accepting connections...")
        
        while self.running:
            try:
                client_socket, address = self.socket.accept()
                print(f"Connection from {address}")
                
                # Add client to list
                client = {
                    'socket': client_socket,
                    'address': address,
                    'player_name': None
                }
                self.clients.append(client)
                
                # Start a thread to receive messages from this client
                client_thread = threading.Thread(target=self._receive_client_messages, 
                                                args=(client,))
                client_thread.daemon = True
                client_thread.start()
                
            except:
                # Socket was closed or other error
                if not self.running:
                    break
                time.sleep(0.1)
    
    def _receive_client_messages(self, client):
        """Thread function to receive messages from a client (host only)"""
        client_socket = client['socket']
        
        while self.running:
            try:
                # Receive data size (4 bytes)
                size_data = client_socket.recv(4)
                if not size_data:
                    break
                
                # Convert size bytes to integer
                message_size = int.from_bytes(size_data, byteorder='big')
                
                # Receive the actual message
                data = b''
                while len(data) < message_size:
                    chunk = client_socket.recv(min(1024, message_size - len(data)))
                    if not chunk:
                        raise ConnectionError("Connection closed while receiving message")
                    data += chunk
                
                # Decode message
                message = json.loads(data.decode('utf-8'))
                message['client'] = client  # Add client reference
                
                # Handle connection message immediately
                if message['type'] == self.MSG_CONNECT:
                    client['player_name'] = message['player_name']
                    print(f"Player {message['player_name']} connected")
                    observer.Event("player_connected", message['player_name'])
                    
                    # Send updated player list to all clients
                    self._broadcast_player_list()
                    
                # Add message to queue for processing
                self.message_queue.put(message)
                
            except ConnectionError:
                break
            except Exception as e:
                print(f"Error receiving from client: {e}")
                break
        
        # Client disconnected
        if client in self.clients:
            self.clients.remove(client)
            print(f"Client {client['address']} disconnected")
            
            # Broadcast updated player list
            if client['player_name']:
                observer.Event("player_disconnected", client['player_name'])
                self._broadcast_player_list()
    
    def _receive_messages(self):
        """Thread function to receive messages from host (client only)"""
        while self.running:
            try:
                # Receive data size (4 bytes)
                size_data = self.socket.recv(4)
                if not size_data:
                    break
                
                # Convert size bytes to integer
                message_size = int.from_bytes(size_data, byteorder='big')
                
                # Receive the actual message
                data = b''
                while len(data) < message_size:
                    chunk = self.socket.recv(min(1024, message_size - len(data)))
                    if not chunk:
                        raise ConnectionError("Connection closed while receiving message")
                    data += chunk
                
                # Decode message
                message = json.loads(data.decode('utf-8'))
                
                # Add message to queue for processing
                self.message_queue.put(message)
                
            except ConnectionError:
                break
            except Exception as e:
                print(f"Error receiving from host: {e}")
                break
        
        # Connection to host lost
        if self.running:
            print("Connection to host lost")
            observer.Event("network_error", "Connection to host lost")
            self.stop()
    
    def _handle_message(self, message):
        """Handle a received message based on its type"""
        message_type = message.get('type')
        
        if message_type == self.MSG_GAME_STATE:
            # Received full game state update (client only)
            observer.Event("network_game_state", message['game_state'])
            
        elif message_type == self.MSG_ACTION:
            # Game action from another player
            observer.Event("network_action", (
                message['action_type'], 
                message['action_data'],
                message['player_name']
            ))
            
        elif message_type == self.MSG_CHAT:
            # Chat message from another player
            observer.Event("network_chat", (
                message['text'],
                message['player_name']
            ))
            
        elif message_type == self.MSG_DISCONNECT:
            # Player disconnecting
            if self.host_mode and 'client' in message:
                client = message['client']
                if client in self.clients:
                    print(f"Player {client['player_name']} disconnected")
                    self.clients.remove(client)
                    observer.Event("player_disconnected", client['player_name'])
                    self._broadcast_player_list()
            
        elif message_type == self.MSG_PING:
            # Ping message - send response
            if self.host_mode and 'client' in message:
                self._send_message_to_client({
                    'type': self.MSG_PING,
                    'response': True,
                    'timestamp': time.time()
                }, message['client'])
    
    def _send_message(self, message):
        """Send a message to the connected host (client only)"""
        if not self.running or not self.socket:
            return False
            
        try:
            # Encode message to JSON
            message_json = json.dumps(message)
            message_bytes = message_json.encode('utf-8')
            
            # Send size followed by the message
            size_bytes = len(message_bytes).to_bytes(4, byteorder='big')
            self.socket.sendall(size_bytes + message_bytes)
            return True
            
        except Exception as e:
            print(f"Error sending message: {e}")
            return False
    
    def _send_message_to_client(self, message, client):
        """Send a message to a specific client (host only)"""
        if not self.running or not client['socket']:
            return False
            
        try:
            # Encode message to JSON
            message_json = json.dumps(message)
            message_bytes = message_json.encode('utf-8')
            
            # Send size followed by the message
            size_bytes = len(message_bytes).to_bytes(4, byteorder='big')
            client['socket'].sendall(size_bytes + message_bytes)
            return True
            
        except Exception as e:
            print(f"Error sending message to client: {e}")
            return False
    
    def _broadcast_message(self, message):
        """Send a message to all connected clients (host only)"""
        if not self.running or not self.host_mode:
            return False
            
        success = True
        for client in self.clients:
            if not self._send_message_to_client(message, client):
                success = False
                
        return success
    
    def _broadcast_player_list(self):
        """Send updated player list to all clients (host only)"""
        if not self.running or not self.host_mode:
            return
            
        player_list = [{
            'name': 'Host (You)' if self.host_mode else 'Host',
            'is_host': True
        }]
        
        for client in self.clients:
            if client['player_name']:
                player_list.append({
                    'name': client['player_name'],
                    'is_host': False
                })
        
        message = {
            'type': 'player_list',
            'players': player_list,
            'timestamp': time.time()
        }
        
        self._broadcast_message(message)
        
        # Also notify local UI
        observer.Event("update_player_list", player_list)
    
    def _send_ping(self):
        """Send a ping message to check connection status"""
        if not self.running:
            return
            
        if self.host_mode:
            # Host pings all clients
            for client in self.clients:
                self._send_message_to_client({
                    'type': self.MSG_PING,
                    'timestamp': time.time()
                }, client)
        else:
            # Client pings host
            self._send_message({
                'type': self.MSG_PING,
                'timestamp': time.time()
            })
    
    def get_local_ip(self):
        """Get the local IP address to share for connections"""
        try:
            # Create a temporary socket to determine local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Doesn't need to be reachable
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"  # Fallback to localhost
