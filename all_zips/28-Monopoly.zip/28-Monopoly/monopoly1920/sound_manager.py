import os
import pygame
import json
import random
import time

class SoundManager:
    """Class to manage all game sounds and music using PyGame"""
    
    def __init__(self):
        """Initialize the sound manager and load all sounds"""
        # Initialize pygame mixer
        pygame.mixer.init()
        
        # Default volume levels
        self.default_music_volume = 0.5
        self.default_sfx_volume = 0.7
        
        # Current volume levels
        self.music_volume = self.default_music_volume
        self.sfx_volume = self.default_sfx_volume
        
        # Mute states
        self.music_muted = False
        self.sfx_muted = False
        
        # Previous volume levels (for unmuting)
        self.prev_music_volume = self.music_volume
        self.prev_sfx_volume = self.sfx_volume
        
        # Load saved preferences if available
        self._load_preferences()
        
        # Dictionary to store loaded sound effects
        self.sounds = {}
        
        # Load all sound files
        self._load_sounds()
        
        # Track if music is playing
        self.music_playing = False
        self.current_music = None
        
        # Setup for music playlist system
        self.last_played_game_track = None
        self.game_music_playlist = []
        
        # Track when we last checked music playing status
        self.last_music_check = time.time()
        self.music_just_ended = False
    
    def process_events(self):
        """Check if music has ended and play the next track if needed
        This should be called periodically from the main loop"""
        # Only check for game music transitions
        if self.current_music == "game" and self.music_playing:
            # If music is not playing but should be
            if not pygame.mixer.music.get_busy():
                # Avoid rapid firing when music first ends
                current_time = time.time()
                if current_time - self.last_music_check > 0.5:  # Check every 0.5 sec
                    self._play_next_game_track()
                    self.last_music_check = current_time
                    return True
            
            # Update the last check time
            self.last_music_check = time.time()
        return False
    
    def _load_sounds(self):
        """Load all sound files from resources directory"""
        sound_dir = os.path.join("resources", "sound")
        
        # Define sound effects with their filenames
        sound_files = {
            "dice_roll": "dice roll.ogg",
            "buy_property": "buy property.ogg",
            "end_turn": "end turn.ogg",
            "game_lost": "game lost.ogg",
            "game_won": "game won.mp3",
            "go_bankrupt": "go_bankrupt.ogg",
            "mortgage": "mortgage - unmortgage.ogg",
        }
        
        # Define music tracks
        self.music_files = {
            "menu": os.path.join(sound_dir, "main menu loop.ogg"),
            "win": os.path.join(sound_dir, "winfantasia-6912.ogg")
        }
        
        # Setup game music playlist with all three background tracks
        self.game_music_tracks = [
            os.path.join(sound_dir, "background music loop.ogg"),
            os.path.join(sound_dir, "background music loop 2.ogg"),
            os.path.join(sound_dir, "background music loop 3.ogg")
        ]
        
        # Load each sound effect
        for sound_name, filename in sound_files.items():
            file_path = os.path.join(sound_dir, filename)
            try:
                self.sounds[sound_name] = pygame.mixer.Sound(file_path)
                self.sounds[sound_name].set_volume(self.sfx_volume)
            except Exception as e:
                print(f"Error loading sound {sound_name} from {file_path}: {e}")
    
    def play_sound(self, sound_name):
        """Play a sound effect by name"""
        if sound_name in self.sounds:
            try:
                self.sounds[sound_name].play()
            except Exception as e:
                print(f"Error playing sound {sound_name}: {e}")
        else:
            print(f"Sound not found: {sound_name}")
    
    def _get_next_game_track(self):
        """Get the next game track ensuring no consecutive repeats"""
        # Get available tracks (all except the last played one)
        available_tracks = [track for track in self.game_music_tracks 
                          if track != self.last_played_game_track]
        
        # If somehow all tracks were played, reset
        if not available_tracks:
            available_tracks = self.game_music_tracks.copy()
        
        # Choose a random track from available tracks
        next_track = random.choice(available_tracks)
        
        # Remember this track to avoid repeating it next time
        self.last_played_game_track = next_track
        
        return next_track
    
    def _play_next_game_track(self):
        """Play the next track in the game music playlist"""
        if not self.music_playing or self.current_music != "game":
            return
            
        # Get the next track to play
        next_track = self._get_next_game_track()
        
        try:
            # Stop current music
            pygame.mixer.music.stop()
            
            # Load and play the new track
            pygame.mixer.music.load(next_track)
            pygame.mixer.music.set_volume(self.music_volume if not self.music_muted else 0.0)
            
            # Play once (will trigger the end event when complete)
            pygame.mixer.music.play(0)
            
            # Remember when we started playing
            self.current_track_start_time = time.time()
            
            print(f"Now playing game track: {os.path.basename(next_track)}")
        except Exception as e:
            print(f"Error playing next game track: {e}")
    
    def play_music(self, music_name, loop=True):
        """Play background music"""
        # Special handling for game music - use our playlist system
        if music_name == "game":
            self.current_music = "game"
            self.music_playing = True
            self._play_next_game_track()
            return
            
        # Regular music handling for menu and other tracks
        if music_name in self.music_files:
            try:
                # Stop any currently playing music
                pygame.mixer.music.stop()
                
                # Load and play the new music
                pygame.mixer.music.load(self.music_files[music_name])
                pygame.mixer.music.set_volume(self.music_volume)
                
                if loop:
                    pygame.mixer.music.play(-1)  # -1 means loop indefinitely
                else:
                    pygame.mixer.music.play()
                
                self.music_playing = True
                self.current_music = music_name
            except Exception as e:
                print(f"Error playing music {music_name}: {e}")
        else:
            print(f"Music not found: {music_name}")
    
    def stop_music(self):
        """Stop the currently playing music"""
        pygame.mixer.music.stop()
        self.music_playing = False
    
    def set_music_volume(self, volume):
        """Set music volume (0.0 to 1.0)"""
        self.music_volume = max(0.0, min(1.0, volume))
        if not self.music_muted:
            pygame.mixer.music.set_volume(self.music_volume)
        self.prev_music_volume = self.music_volume
        self._save_preferences()
    
    def set_sfx_volume(self, volume):
        """Set sound effects volume (0.0 to 1.0)"""
        self.sfx_volume = max(0.0, min(1.0, volume))
        if not self.sfx_muted:
            for sound in self.sounds.values():
                sound.set_volume(self.sfx_volume)
        self.prev_sfx_volume = self.sfx_volume
        self._save_preferences()
    
    def toggle_music_mute(self):
        """Toggle music mute on/off"""
        self.music_muted = not self.music_muted
        if self.music_muted:
            pygame.mixer.music.set_volume(0.0)
        else:
            pygame.mixer.music.set_volume(self.music_volume)
        self._save_preferences()
        return self.music_muted
    
    def toggle_sfx_mute(self):
        """Toggle sound effects mute on/off"""
        self.sfx_muted = not self.sfx_muted
        for sound in self.sounds.values():
            sound.set_volume(0.0 if self.sfx_muted else self.sfx_volume)
        self._save_preferences()
        return self.sfx_muted
    
    def _save_preferences(self):
        """Save sound preferences to a file"""
        preferences = {
            'music_volume': self.music_volume,
            'sfx_volume': self.sfx_volume,
            'music_muted': self.music_muted,
            'sfx_muted': self.sfx_muted
        }
        
        try:
            with open('sound_preferences.json', 'w') as f:
                json.dump(preferences, f)
        except Exception as e:
            print(f"Error saving sound preferences: {e}")
    
    def _load_preferences(self):
        """Load sound preferences from a file"""
        try:
            if os.path.exists('sound_preferences.json'):
                with open('sound_preferences.json', 'r') as f:
                    preferences = json.load(f)
                
                self.music_volume = preferences.get('music_volume', self.default_music_volume)
                self.sfx_volume = preferences.get('sfx_volume', self.default_sfx_volume)
                self.music_muted = preferences.get('music_muted', False)
                self.sfx_muted = preferences.get('sfx_muted', False)
                
                self.prev_music_volume = self.music_volume
                self.prev_sfx_volume = self.sfx_volume
                
                # Apply loaded settings
                if self.music_muted:
                    pygame.mixer.music.set_volume(0.0)
                else:
                    pygame.mixer.music.set_volume(self.music_volume)
        except Exception as e:
            print(f"Error loading sound preferences: {e}")
