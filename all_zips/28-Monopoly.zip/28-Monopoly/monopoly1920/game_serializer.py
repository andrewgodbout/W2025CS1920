import json
import os
import time
import datetime

class GameSerializer:
    """Class to handle saving and loading game states"""
    
    def __init__(self):
        """Constructor for the GameSerializer class"""
        # Create save directories if they don't exist
        self.saves_dir = os.path.join(os.getcwd(), "saves")
        self.manual_dir = os.path.join(self.saves_dir, "manual")
        self.autosave_dir = os.path.join(self.saves_dir, "autosaves")
        
        self._create_directories()
        
        # Maximum number of autosaves to keep
        self.max_autosaves = 5
        
    def _create_directories(self):
        """Create the directories for saves if they don't exist"""
        os.makedirs(self.manual_dir, exist_ok=True)
        os.makedirs(self.autosave_dir, exist_ok=True)
    
    def serialize_game(self, controller):
        """Serialize the game state to a dictionary
        
        Args:
            controller: The game controller with references to game objects
            
        Returns:
            dict: A dictionary representing the game state
        """
        # Get references to key game objects
        gameboard = controller._gameboard
        players = gameboard.players
        current_player_index = gameboard.current_player_index
        
        # Create a timestamp
        timestamp = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        
        # Create metadata
        metadata = {
            "version": "1.0",
            "timestamp": timestamp,
            "custom_name": "",  # Will be set when saving
            "turn_count": controller._view.turn_count if hasattr(controller._view, 'turn_count') else 1,
            "player_count": len(players)
        }
        
        # Serialize gameboard
        gameboard_data = {
            "current_player_index": current_player_index,
            "total_turns": getattr(gameboard, '_GameBoard__total_turns', 0),
            "dice_rolled": controller.__dice_rolled,
            "roll_count": controller.__roll_count
        }
        
        # Serialize players
        players_data = []
        for i, player in enumerate(players):
            # Get player's properties indices
            property_indices = []
            for prop in player.properties:
                prop_index = None
                # Find property index in the board
                for j, board_prop in enumerate(gameboard.get_all_squares()):
                    if board_prop == prop:
                        prop_index = j
                        break
                
                if prop_index is not None:
                    property_indices.append({
                        "index": prop_index,
                        "is_mortgaged": prop.is_mortgaged
                    })
            
            player_data = {
                "name": player.name,
                "money": player.money,
                "position": player.position,
                "is_ai": True if hasattr(player, 'is_ai') and player.is_ai else False,
                "ai_difficulty": getattr(player, 'difficulty', 'medium') if hasattr(player, 'is_ai') and player.is_ai else None,
                "bankrupt_declared": player.bankrupt_declared,
                "luck": getattr(player, 'luck', 0),
                "railroad_count": getattr(player, 'railroad_count', 0),
                "property_indices": property_indices
            }
            players_data.append(player_data)
        
        # Serialize properties (only the state that can change)
        properties_data = []
        for i, prop in enumerate(gameboard.get_all_squares()):
            # Only include properties that can be owned
            if hasattr(prop, 'can_be_purchased') and prop.can_be_purchased():
                # Find the owner index
                owner_index = None
                if hasattr(prop, 'owner') and prop.owner:
                    for j, player in enumerate(players):
                        if player == prop.owner:
                            owner_index = j
                            break
                
                property_data = {
                    "index": i,
                    "owner_player_index": owner_index,
                    "is_mortgaged": getattr(prop, 'is_mortgaged', False)
                }
                properties_data.append(property_data)
        
        # Combine all data
        game_data = {
            "metadata": metadata,
            "gameboard": gameboard_data,
            "players": players_data,
            "properties": properties_data
        }
        
        return game_data
    
    def save_game(self, controller, custom_name=None, is_autosave=False):
        """Save the game state to a file
        
        Args:
            controller: The game controller
            custom_name: Optional custom name for the save file
            is_autosave: Whether this is an autosave
            
        Returns:
            str: The path to the saved file
        """
        # Serialize the game state
        game_data = self.serialize_game(controller)
        
        # Create filename with timestamp
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        
        if is_autosave:
            save_dir = self.autosave_dir
            filename = f"autosave_{timestamp}.json"
            
            # Rotate autosaves if needed
            self._rotate_autosaves()
        else:
            save_dir = self.manual_dir
            
            # Use custom name if provided
            if custom_name:
                # Clean up custom name to be filename-safe
                custom_name = ''.join(c for c in custom_name if c.isalnum() or c in '._- ')
                game_data["metadata"]["custom_name"] = custom_name
                filename = f"{custom_name}_{timestamp}.json"
            else:
                filename = f"save_{timestamp}.json"
        
        # Full path to save file
        save_path = os.path.join(save_dir, filename)
        
        # Save to file
        with open(save_path, 'w') as f:
            json.dump(game_data, f, indent=2)
        
        return save_path
    
    def _rotate_autosaves(self):
        """Keep only the most recent autosaves according to max_autosaves setting"""
        try:
            # List all files in autosave directory
            files = [os.path.join(self.autosave_dir, f) for f in os.listdir(self.autosave_dir) 
                     if f.startswith("autosave_") and f.endswith(".json")]
            
            # Sort by modification time (oldest first)
            files.sort(key=lambda x: os.path.getmtime(x))
            
            # Remove oldest files if we have too many
            while len(files) >= self.max_autosaves:
                oldest = files.pop(0)
                os.remove(oldest)
        except Exception as e:
            print(f"Error rotating autosaves: {e}")
    
    def load_game(self, file_path):
        """Load a game state from a file
        
        Args:
            file_path: Path to the save file
            
        Returns:
            dict: The loaded game state or None if loading failed
        """
        try:
            with open(file_path, 'r') as f:
                game_data = json.load(f)
            
            # Validate the game data structure
            if not all(key in game_data for key in ["metadata", "gameboard", "players", "properties"]):
                print("Save file is missing required sections")
                return None
            
            return game_data
        except Exception as e:
            print(f"Error loading game: {e}")
            return None
    
    def get_save_list(self, include_autosaves=True):
        """Get a list of available save files
        
        Args:
            include_autosaves: Whether to include autosaves in the list
            
        Returns:
            list: List of dictionaries with save file info
        """
        save_list = []
        
        # Get manual saves
        try:
            for filename in os.listdir(self.manual_dir):
                if filename.endswith(".json"):
                    file_path = os.path.join(self.manual_dir, filename)
                    save_info = self._get_save_info(file_path)
                    if save_info:
                        save_info["is_autosave"] = False
                        save_list.append(save_info)
        except Exception as e:
            print(f"Error reading manual saves: {e}")
        
        # Get autosaves if requested
        if include_autosaves:
            try:
                for filename in os.listdir(self.autosave_dir):
                    if filename.endswith(".json"):
                        file_path = os.path.join(self.autosave_dir, filename)
                        save_info = self._get_save_info(file_path)
                        if save_info:
                            save_info["is_autosave"] = True
                            save_list.append(save_info)
            except Exception as e:
                print(f"Error reading autosaves: {e}")
        
        # Sort by timestamp (newest first)
        save_list.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return save_list
    
    def _get_save_info(self, file_path):
        """Get basic information about a save file
        
        Args:
            file_path: Path to the save file
            
        Returns:
            dict: Dictionary with save file info or None if reading failed
        """
        try:
            with open(file_path, 'r') as f:
                game_data = json.load(f)
            
            metadata = game_data.get("metadata", {})
            
            # Extract relevant info
            return {
                "file_path": file_path,
                "filename": os.path.basename(file_path),
                "timestamp": metadata.get("timestamp", "Unknown"),
                "custom_name": metadata.get("custom_name", ""),
                "turn_count": metadata.get("turn_count", 0),
                "player_count": metadata.get("player_count", 0),
                "display_name": metadata.get("custom_name") or os.path.basename(file_path)
            }
        except Exception as e:
            print(f"Error reading save file {file_path}: {e}")
            return None
