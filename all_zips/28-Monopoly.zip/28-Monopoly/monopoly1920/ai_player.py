import random
import observer
from player import Player

class AIPlayer(Player):
    """AI Player class that extends Player with AI decision-making abilities"""
    
    DIFFICULTY_EASY = "easy"
    DIFFICULTY_MEDIUM = "medium"
    DIFFICULTY_HARD = "hard"
    
    def __init__(self, name, money, difficulty):
        """Constructor for the AIPlayer class"""
        super().__init__(name, money)
        self.difficulty = difficulty  # 'easy', 'medium', or 'hard'
        self.is_ai = True
        
    def decide_buy_property(self, square, gameboard):
        """Decide whether to buy a property based on AI difficulty
        Returns: True if AI wants to buy, False otherwise
        """
        # Log decision process for UI feedback
        decision_reason = ""
        
        # Safely check if property can be purchased
        try:
            if not hasattr(square, 'can_be_purchased') or not square.can_be_purchased():
                square_name = getattr(square, 'name', 'Unknown property')
                decision_reason = f"Property {square_name} cannot be purchased"
                observer.Event("ai_decision", (f"{self.name} cannot purchase {square_name}", decision_reason))
                return False
        except Exception as e:
            print(f"Error checking if property can be purchased: {e}")
            decision_reason = "Error evaluating property"
            observer.Event("ai_decision", (f"{self.name} cannot purchase property", decision_reason))
            return False
        
        # Safely check price
        square_price = getattr(square, 'price', 0)
        square_name = getattr(square, 'name', 'Unknown property')
        
        if self.money < square_price:
            decision_reason = f"Not enough money to buy {square_name}"
            observer.Event("ai_decision", (f"{self.name} cannot afford {square_name}", decision_reason))
            return False
        
        # Decision logic based on difficulty
        try:
            if self.difficulty == self.DIFFICULTY_EASY:
                # Easy AI: Buy with 50% probability if they can afford it
                decision = random.random() > 0.5
                decision_reason = "Randomly decided to purchase" if decision else "Randomly decided not to purchase"
        
            elif self.difficulty == self.DIFFICULTY_MEDIUM:
                # Medium AI: Buy based on property value and current money
                # More likely to buy properties that are part of a color group they already own
                value_ratio = getattr(square, 'price', 100) / 400  # Normalize price (0.0 - 1.0)
                money_ratio = self.money / 1500  # Normalize money (0.0 - 1.0+)
                
                # Check if AI already owns properties in this color group
                owns_in_group = False
                square_color = getattr(square, 'color', None)
                if square_color is not None:
                    for prop in self.properties:
                        if hasattr(prop, 'color') and prop.color == square_color:
                            owns_in_group = True
                            break
                
                # Bonus for properties in a group the AI already owns properties in
                group_bonus = 0.3 if owns_in_group else 0
                
                # Bonus for utilities and railroads
                is_railroad = getattr(square, 'is_railroad', False)
                is_utility = getattr(square, 'is_utility', False)
                special_bonus = 0.2 if is_railroad or is_utility else 0
            
                # Calculate purchase probability
                purchase_prob = 0.5 - value_ratio + (money_ratio * 0.5) + group_bonus + special_bonus
                purchase_prob = max(0.1, min(purchase_prob, 0.9))  # Ensure reasonable bounds
                decision = random.random() < purchase_prob
                
                if owns_in_group:
                    decision_reason = f"Property is in a color group I already own"
                elif money_ratio < 0.3:
                    decision_reason = f"I'm low on cash (${self.money}), being cautious"
                elif is_railroad:
                    decision_reason = f"Railroads provide consistent income"
                elif is_utility:
                    decision_reason = f"Utilities can provide good income"
                else:
                    decision_reason = f"Property seems like a good value for the price"
        
            elif self.difficulty == self.DIFFICULTY_HARD:
                # Hard AI: Sophisticated decision making
                try:
                    # Calculate expected ROI and make strategic decisions
                    expected_income = self._calculate_expected_income(square, gameboard)
                    square_price = getattr(square, 'price', 100)
                    price_to_income_ratio = square_price / max(expected_income, 1)
                    
                    # Check if AI already owns properties in this color group
                    color_group_count = 0
                    total_in_group = 0
                    square_color = getattr(square, 'color', None)
                    
                    if square_color is not None:
                        for prop in self.properties:
                            if hasattr(prop, 'color') and prop.color == square_color:
                                color_group_count += 1
                        
                        # Count total properties in this color group
                        try:
                            for i in range(40):
                                sq = gameboard.get_square(i)
                                if hasattr(sq, 'color') and sq.color == square_color:
                                    total_in_group += 1
                        except Exception:
                            # If we can't count properties, assume a default
                            total_in_group = 3  # Reasonable default
                    
                    # Check if this would complete a monopoly
                    would_complete_monopoly = (color_group_count + 1 == total_in_group) and (total_in_group > 0)
                    
                    # Strategic factors
                    monopoly_bonus = 0.5 if would_complete_monopoly else 0
                    is_railroad = getattr(square, 'is_railroad', False)
                    is_utility = getattr(square, 'is_utility', False)
                    railroad_factor = min(self.railroad_count * 0.15, 0.4) if is_railroad else 0
                    utility_factor = min(self.railroad_count * 0.2, 0.3) if is_utility else 0
                    
                    # Strategic cash reserve - don't spend below certain threshold
                    cash_reserve_factor = -0.8 if self.money - square_price < 200 else 0
                    
                    # Calculate purchase probability
                    purchase_prob = (
                        0.6 +                              # Base probability
                        min(1500 / price_to_income_ratio, 0.3) +  # Expected income factor
                        monopoly_bonus +                   # Monopoly completion bonus
                        railroad_factor +                  # Railroad ownership factor
                        utility_factor +                   # Utility ownership factor
                        cash_reserve_factor                # Cash reserve factor
                    )
                    
                    # Ensure probability is within reasonable bounds
                    purchase_prob = max(0.1, min(purchase_prob, 0.9))
                    decision = random.random() < purchase_prob
                    
                    if would_complete_monopoly:
                        decision_reason = f"This completes a color group monopoly!"
                    elif self.money - square_price < 200:
                        decision_reason = f"Need to maintain cash reserves for upcoming expenses"
                    elif railroad_factor > 0:
                        decision_reason = f"Owning multiple railroads increases their value"
                    elif expected_income > square_price / 10:
                        decision_reason = f"Expected income makes this a good investment"
                    else:
                        decision_reason = f"Strategic decision based on board analysis"
                except Exception as e:
                    print(f"Error in hard AI decision making: {e}")
                    # Fallback to simpler logic if complex logic fails
                    decision = self.money > 400
                    decision_reason = "Using fallback logic due to calculation error"
        
            else:
                # Default fallback
                decision = True
                decision_reason = "Default decision to purchase"
        except Exception as e:
            print(f"Error in AI purchase decision: {e}")
            # Safe fallback if anything goes wrong
            decision = False
            decision_reason = "Encountered error in decision logic, being cautious"
        
        # Log AI decision for UI feedback
        try:
            square_name = getattr(square, 'name', 'this property')
            action = "will purchase" if decision else "declines to purchase" 
            observer.Event("ai_decision", (f"{self.name} {action} {square_name}", decision_reason))
        except Exception as e:
            print(f"Error firing AI decision event: {e}")
        
        return decision
    
    def decide_mortgage_property(self, needed_money=0):
        """Decide which property to mortgage based on AI difficulty
        Returns: Name of property to mortgage, or None if no property should be mortgaged
        """
        # Check if there are any unmortgaged properties
        mortgage_candidates = [p for p in self.properties if not p.is_mortgaged]
        
        if not mortgage_candidates:
            observer.Event("ai_decision", (f"{self.name} has no properties to mortgage", "No unmortgaged properties available"))
            return None
        
        decision_reason = ""
        chosen_property = None
        
        if self.difficulty == self.DIFFICULTY_EASY:
            # Easy AI: Choose a random property
            chosen_property = random.choice(mortgage_candidates)
            decision_reason = "Random selection"
            
        elif self.difficulty == self.DIFFICULTY_MEDIUM:
            # Medium AI: Prefer to mortgage properties not in a color group
            # and lower value properties
            
            # Sort by whether they're part of a color group the AI owns multiple properties in
            color_groups = {}
            for prop in self.properties:
                if hasattr(prop, 'color'):
                    color = prop.color
                    if color not in color_groups:
                        color_groups[color] = 0
                    color_groups[color] += 1
            
            # First mortgage properties that aren't part of a color group the AI owns multiple of
            singles = [p for p in mortgage_candidates if not hasattr(p, 'color') or color_groups.get(p.color, 0) <= 1]
            
            if singles:
                # Sort by value (mortgage lowest value first)
                singles.sort(key=lambda p: p.price)
                chosen_property = singles[0]
                decision_reason = "Mortgaging a property that isn't part of a monopoly strategy"
            else:
                # Sort all candidates by value if no singles
                mortgage_candidates.sort(key=lambda p: p.price)
                chosen_property = mortgage_candidates[0]
                decision_reason = "Mortgaging lowest valued property"
                
        elif self.difficulty == self.DIFFICULTY_HARD:
            # Hard AI: Sophisticated mortgage strategy
            # Calculate ROI for each property and mortgage the one with lowest ROI
            
            # Avoid mortgaging properties in monopolies
            color_groups = {}
            for prop in self.properties:
                if hasattr(prop, 'color'):
                    color = prop.color
                    if color not in color_groups:
                        color_groups[color] = 0
                    color_groups[color] += 1
            
            # Score each property (higher score = keep it)
            property_scores = {}
            for prop in mortgage_candidates:
                base_score = prop.price / 100  # Base on property value
                
                # Bonus for properties in a color group the AI has multiple properties in
                monopoly_bonus = 0
                if hasattr(prop, 'color') and color_groups.get(prop.color, 0) > 1:
                    # Higher bonus if the AI has more properties in this group
                    monopoly_bonus = color_groups[prop.color] * 4
                
                # Railroad and utility strategies
                strategic_bonus = 0
                if prop.is_railroad and self.railroad_count > 1:
                    strategic_bonus = self.railroad_count * 2
                elif prop.is_utility:
                    strategic_bonus = 2
                
                # Calculate final score
                property_scores[prop] = base_score + monopoly_bonus + strategic_bonus
            
            # Sort by score (lowest first)
            mortgage_candidates.sort(key=lambda p: property_scores[p])
            chosen_property = mortgage_candidates[0]
            
            # Generate reason
            if hasattr(chosen_property, 'color') and color_groups.get(chosen_property.color, 0) > 1:
                decision_reason = "Strategically mortgaging despite being in a valuable color group"
            elif chosen_property.is_railroad:
                decision_reason = "Mortgaging a railroad, but trying to maintain strategic advantage"
            else:
                decision_reason = "Mortgaging property with lowest strategic value"
        
        # Log AI decision and return property name, with error handling
        try:
            property_name = getattr(chosen_property, 'name', 'unknown property')
            observer.Event("ai_decision", (f"{self.name} will mortgage {property_name}", decision_reason))
            return property_name
        except Exception as e:
            print(f"Error preparing mortgage decision: {e}")
            observer.Event("ai_decision", (f"{self.name} encountered an error while deciding what to mortgage", "Error in mortgage logic"))
            return None
    
    def decide_end_turn(self):
        """Decide if the AI should end its turn
        Returns: True if AI wants to end turn, False otherwise
        """
        # For now, AI always ends turn when possible
        # This could be expanded with more complex logic in the future
        observer.Event("ai_decision", (f"{self.name} ends their turn", "No more actions to take"))
        return True
    
    def _calculate_expected_income(self, square, gameboard):
        """Calculate expected income from a property for Hard AI
        Returns an estimate of income per circuit around the board
        """
        try:
            # Base expected income on rent values
            if not hasattr(square, 'rent'):
                return 10  # Default for non-rental properties
            
            # Basic rent calculation
            base_rent = square.rent
            
            # Calculate probability that other players will land on this square
            # This is a simplified model - for complex simulation, we'd need to model
            # the entire game state and player positions
            
            # Estimate based on position (properties between 5-15 spaces after GO, Jail, etc
            # are landed on more frequently)
            position_factor = 1.0
            
            # Get position safely
            square_position = getattr(square, 'position', 0)
            
            # Check proximity to frequently visited squares (simplified)
            for common_square in [0, 10, 20, 30]:  # GO, Jail, Free Parking, Go To Jail
                try:
                    distance = min((square_position - common_square) % 40, 
                                  (common_square - square_position) % 40)
                    
                    # Squares 5-9 spaces after common squares get higher factor
                    if 5 <= distance <= 9:
                        position_factor = 1.3
                        break
                except:
                    # Continue if there's an error with one calculation
                    continue
            
            # Combine factors for final expected income
            expected_income = base_rent * position_factor * 0.2  # 0.2 = approximate landing probability per circuit
            
            return expected_income
        except Exception as e:
            print(f"Error calculating expected income: {e}")
            return 10  # Safe default
