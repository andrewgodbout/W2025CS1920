import sys
from player import Player
from ai_player import AIPlayer

def test_player_classes():
    """Test that Player and AIPlayer properly handle the is_ai flag"""
    human = Player("Human Player", 1500)
    ai = AIPlayer("AI Player", 1500, "medium")
    
    print(f"Human player is_ai: {human.is_ai}")
    print(f"AI player is_ai: {ai.is_ai}")
    
    # Test setting the flag
    human.is_ai = True
    print(f"Human player is_ai after setting to True: {human.is_ai}")
    
    ai.is_ai = False
    print(f"AI player is_ai after setting to False: {ai.is_ai}")
    
    # Test that AIPlayer constructor sets is_ai to True
    ai2 = AIPlayer("AI Player 2", 1500, "hard")
    print(f"New AI player is_ai: {ai2.is_ai}")
    
    return human.is_ai and not ai.is_ai and ai2.is_ai

if __name__ == "__main__":
    result = test_player_classes()
    print(f"\nTest {'PASSED' if result else 'FAILED'}")
    sys.exit(0 if result else 1)
