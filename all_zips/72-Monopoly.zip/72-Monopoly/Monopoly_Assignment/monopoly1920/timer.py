import pygame
import time
import threading


class GameTimer:
    def __init__(self, duration=60, callback=None):
        self.duration = duration
        self.remaining = duration
        self.running = False
        self.callback = callback
        self.thread = None

        # Initialize Pygame for the timer display
        pygame.init()
        self.screen = pygame.display.set_mode((200, 100))
        pygame.display.set_caption("Monopoly Timer")
        self.font = pygame.font.SysFont('Arial', 30)

    def start(self):
        if not self.running:
            self.running = True
            self.remaining = self.duration
            self.thread = threading.Thread(target=self._run_timer)
            self.thread.daemon = True
            self.thread.start()

    def stop(self):
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join()

    def _run_timer(self):
        start_time = time.time()

        while self.running and self.remaining > 0:
            # Update display
            self._update_display()

            # Calculate remaining time
            elapsed = time.time() - start_time
            self.remaining = max(0, self.duration - elapsed)

            # Check for Pygame events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            time.sleep(0.1)

        if self.remaining <= 0 and self.callback:
            self.callback()

    def _update_display(self):
        self.screen.fill((255, 255, 255))
        minutes = int(self.remaining // 60)
        seconds = int(self.remaining % 60)
        time_text = f"{minutes:02d}:{seconds:02d}"

        # Change color based on remaining time
        if self.remaining < 10:
            color = (255, 0, 0)  # Red when less than 10 seconds
        elif self.remaining < 30:
            color = (255, 165, 0)  # Orange when less than 30 seconds
        else:
            color = (0, 0, 0)  # Black otherwise

        text = self.font.render(time_text, True, color)
        text_rect = text.get_rect(center=(100, 50))
        self.screen.blit(text, text_rect)
        pygame.display.flip()