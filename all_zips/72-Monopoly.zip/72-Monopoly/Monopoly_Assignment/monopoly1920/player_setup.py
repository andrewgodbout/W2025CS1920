import tkinter as tk
from tkinter import ttk


class PlayerSetup:
    def __init__(self, root, on_complete):
        self.root = root
        self.on_complete = on_complete
        self.player_names = []

        self.setup_window = tk.Toplevel(root)
        self.setup_window.title("Player Setup")
        self.setup_window.geometry("400x300")

        self._create_widgets()

    def _create_widgets(self):
        main_frame = ttk.Frame(self.setup_window, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main_frame, text="Enter Player Names", font=('Helvetica', 14)).pack(pady=10)

        self.entry_frame = ttk.Frame(main_frame)
        self.entry_frame.pack(fill=tk.X, pady=10)

        # Default to 4 players, but allow adding more
        for i in range(4):
            self._add_player_entry(i + 1)

        # Add/remove player buttons
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        ttk.Button(btn_frame, text="Add Player", command=self._add_player).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Remove Player", command=self._remove_player).pack(side=tk.LEFT, padx=5)

        # Start game button
        ttk.Button(btn_frame, text="Start Game", command=self._start_game).pack(side=tk.LEFT,padx=10)

    def _add_player_entry(self, player_num):
        frame = ttk.Frame(self.entry_frame)
        frame.pack(fill=tk.X, pady=5)

        ttk.Label(frame, text=f"Player {player_num}:").pack(side=tk.LEFT, padx=5)
        entry = ttk.Entry(frame)
        entry.pack(side=tk.LEFT, expand=True, fill=tk.X)
        entry.insert(0, f"Player {player_num}")  # Default name

    def _add_player(self):
        player_num = len(self.entry_frame.winfo_children()) + 1
        self._add_player_entry(player_num)

    def _remove_player(self):
        if len(self.entry_frame.winfo_children()) > 2:  # Keep at least 2 players
            self.entry_frame.winfo_children()[-1].destroy()

    def _start_game(self):
        self.player_names = []
        for entry_frame in self.entry_frame.winfo_children():
            entry = entry_frame.winfo_children()[1]  # Get the Entry widget
            name = entry.get().strip()
            if not name:
                name = entry_frame.winfo_children()[0].cget("text").replace(":", "")  # Default to "Player X"
            self.player_names.append(name)

        self.setup_window.destroy()
        self.on_complete(self.player_names)