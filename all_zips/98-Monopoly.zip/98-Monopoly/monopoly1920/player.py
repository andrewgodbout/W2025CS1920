class Player:
    def __init__(self, name, money):
        self.railroad_count = 0
        self.properties = []
        self.luck = 0
        self.name = name
        self.position = 0
        self.money = money
        self.in_jail = False
        self.jail_turns = 0
        self.bankrupt_declared = False

    def go_to_jail(self):
        self.position = 10
        self.in_jail = True
        self.jail_turns = 0
        print(f"{self.name} has been sent to jail!")

    def in_jail_status(self):
        return self.in_jail

    def try_to_escape_jail(self, die1, die2):
        if die1 == die2:
            self.in_jail = False
            self.jail_turns = 0
            print(f"{self.name} rolled doubles and gets out of jail!")
            return True
        else:
            self.jail_turns += 1
            if self.jail_turns >= 3:
                if self.money >= 50:
                    self.money -= 50
                    self.in_jail = False
                    self.jail_turns = 0
                    print(f"{self.name} paid $50 to get out of jail after 3 failed attempts.")
                    return True
                else:
                    print(f"{self.name} cannot afford to pay $50 and stays in jail.")
            else:
                print(f"{self.name} did not roll doubles and remains in jail.")
        return False

    def go_bankrupt(self):
        self.money = 0
        self.bankrupt_declared = True
        for prop in self.properties:
            prop.owner = None
        self.properties.clear()

    def move(self, steps):
        self.position = (self.position + steps) % 40
    
    def pay_rent(self, square, dice_sum):
        rent_amount = getattr(square, 'rent', 0)
        if callable(rent_amount):
            rent_amount = rent_amount(dice_sum)

        if self.money >= rent_amount:
            self.money -= rent_amount
            if square.owner:
                square.owner.money += rent_amount
            return rent_amount
        else:
            self.bankrupt_declared = True
            return 0
    
    def buy_property(self, square):
        if self.money >= square.price:
            self.money -= square.price
            square.owner = self
            self.properties.append(square)
            return True
        return False
    
    def mortgage_property(self, deed_name):
        for prop in self.properties:
            if getattr(prop, 'name', '') == deed_name and not getattr(prop, 'mortgaged', False):
                prop.mortgaged = True
                self.money += prop.price // 2
                return True
        return False
    
    def unmortgage_property(self):
        for prop in self.properties:
            if getattr(prop, 'mortgaged', False):
                cost = prop.price // 2
                if self.money >= cost:
                    self.money -= cost
                    prop.mortgaged = False
                    return prop.name
        return None
    