#######################
import random
import copy 

class Card:
    def __init__(self, description, action):
        self.description = description
        self.action = action

class Deck:
    def __init__(self, cards):
        self.cards = cards
        self.originalcards=cards.copy()
        random.shuffle(self.cards)

    def draw(self):
        if not self.cards:
            self.cards=self.originalcards.copy()
            random.shuffle(self.cards)
             # Re-shuffle
        return self.cards.pop()