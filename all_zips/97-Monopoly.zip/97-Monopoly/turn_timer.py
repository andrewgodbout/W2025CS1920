import threading
import time

class TurnTimer:
    def __init__(self, timeout=30):
        self.timeout = timeout
        self.timer = None
        self.active = False
        self.remaining = timeout
        self.callback = None

    def start(self, callback):
        """Start the timer with a callback function"""
        self.active = True
        self.remaining = self.timeout
        self.callback = callback
        self.timer = threading.Timer(self.timeout, self._timeout_handler)
        self.timer.start()

    def stop(self):
        """Stop the timer prematurely"""
        if self.active:
            self.timer.cancel()
            self.active = False

    def _timeout_handler(self):
        """Internal timeout handler"""
        self.active = False
        if self.callback:
            self.callback()

    def get_remaining_time(self):
        """Get remaining time in seconds"""
        if self.active:
            elapsed = time.time() - self.start_time
            return max(self.timeout - int(elapsed), 0)
        return self.remaining