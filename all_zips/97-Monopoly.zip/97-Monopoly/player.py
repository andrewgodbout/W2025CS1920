import gameboard
import gamesquare
import observer
import random

class Player:
    """Player class to represent a player in the game"""

    def __init__(self, name, money):
        """Constructor for the Player class"""
        self.__name = name
        self.__money = money
        self.__properties = []
        self.__board_position = 0
        self.__doubles_count = 0
        self.__bankrupt_declared = False
        self.__utility_count = 0
        self.__railroad_count = 0

        ######
        self.in_jail = False
        self.jail_turns = 0
        self.get_out_of_jail_free = False
        ######

        #big numbers are lucky, negative numbers are unlucky
        self.__luck = 0

        #add a Data structure to track mortgaging order
        self.__mortgaging_order = []

    def __str__(self):
        """String representation of the player"""
        return f"{self.__name} - {self.money} - {self.net_worth()} luck:{self.__luck:.1f}"

    def buy_property(self, board_property):
        """Function to attempt to buy a property"""
        if not board_property.can_be_purchased():
            return False

        self.__properties.append(board_property)
        self.__money -= board_property.price
        board_property.owner = self
        if board_property.is_utility:
            self.__utility_count += 1
        if board_property.is_railroad:
            self.__railroad_count += 1

        return True

    def pay_rent(self, square, dice_sum):
     """Pay rent or tax for landing on a square."""
    # Handle Tax squares (no owner)
     if square.space in ["Tax", "Income Tax", "Luxury Tax"]:
        tax = square.calculate_rent_or_tax(dice_sum)
        self.__money -= tax
        observer.Event("update_state", f"Paid {square.space}: ${tax}")
        return tax

    # No rent for unowned, own properties, or special squares
     if (square.owner is None or 
        square.owner == self or 
        square.space in ["Chance", "Chest", "Go", "Jail", "Free Parking", "GoToJail"]):
        return 0

    # Check if property is mortgaged
     if square.is_mortgaged:
        observer.Event("update_state", f"{square.name} is mortgaged. No rent!")
        return 0

    # Calculate rent once
     rent = square.calculate_rent_or_tax(dice_sum)
     if rent > 0:
        self.__money -= rent
        square.owner.money += rent  # Ensure owner's money is updated
        observer.Event("update_state", 
                      f"Paid ${rent} rent to {square.owner.name} for {square.name}")
     return rent

    def mortgage_property(self, deed_name):
        """Function to mortgage a property"""
        for p in self.__properties:
            if p.name == deed_name:
                res = p.mortgage()
                if res:
                    self.__mortgaging_order.append(p)
                return True
        return False

    def unmortgage_property(self):
        """Function to unmortgage a property
        return the name of the property that was unmortgaged
        or the empty string if no such property exists"""
        if len(self.__mortgaging_order) == 0:
            return ""
        p = self.__mortgaging_order.pop(0)
        res = p.unmortgage()
        if not res:
            return ""
        return p.name


    def net_worth(self):
        """Function to calculate the net worth of the player"""
        return self.money + sum(p.price for p in self.__properties)

    def collect(self, amount):
        """Function to collect money"""
        self.__money += amount
    def pay(self, amount):
        """Function to pay money"""
        self.__money -= amount
    

    
            #############
    
    def handle_jail_turn(self):
      if self.in_jail:
        self.jail_turns += 1
        if self.jail_turns >= 3:
            if self.money >= 50:
                self.money -= 50  # Replace pay(50) with direct deduction
                self.in_jail = False
                self.jail_turns = 0
            else:
                self.declare_bankrupt()
                
                ###########
    def roll_dice(self):
        if self.__in_jail:
            print(f"{self.__name} is in jail and cannot roll.")
            return

        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2
        print(f"{self.__name} rolled: {dice1}, {dice2} (Total: {dice_sum})")

        if dice1 == dice2:
            self.doubles_count += 1
            if self.doubles_count == 3:
                self.__in_jail = True  # Send player to jail
                self.jail_turns = 0  # Reset jail turn counter
                self.__board_position = 10  # Move to jail position
                observer.Event("update_state", f"{self.__name} rolled doubles three times and is sent to jail!")
                print(f"{self.__name} is now in jail!")
            else:
                print(f"{self.__name} rolled doubles! You get to roll again!")
                # Perform logic for moving the player
                self.move(dice_sum)
        else:
            self.doubles_count = 0  # Reset doubles count
            # Perform logic for moving the player
            self.move(dice_sum)

    def move(self, spaces):
     """Function to move the player on the board and handle passing 'Go'."""
     prior_position = self.__board_position  # Capture the player's position before moving
     self.__board_position += spaces  # Move the player forward by the number of spaces rolled

    # Wrap around the board if the player exceeds the last position
     if self.__board_position >= 40:
        self.__board_position -= 40  # Adjust position to ensure it wraps around the board
        observer.Event("update_state", f"{self.__name} passed Go and collects $200!")  # Notify that player passed Go
        self.collect(200)  # Collect $200 for passing Go

    # Optional: Handle board position boundary cases if you have specific rules
    # Ensure the player's position stays within the valid range, from 0 to 39
     if self.__board_position < 0:
        self.__board_position = 0  # Reset to the nearest valid position




    ####################
    @property
    def doubles_count(self):
        return self.__doubles_count

    @doubles_count.setter
    def doubles_count(self, doubles_count):
        self.__doubles_count = doubles_count

    @property
    def luck(self):
        return self.__luck

    @luck.setter
    def luck(self, luck):
        self.__luck = luck

    @property
    def money(self):
        return self.__money

    @money.setter
    def money(self, money):
        self.__money = money

    @property
    def name(self):
        return self.__name

    @property
    def position(self):
        return self.__board_position

    @property
    def bankrupt_declared(self):
        return self.__bankrupt_declared

    def declare_bankrupt(self):
        self.__bankrupt_declared = True

    @property
    def railroad_count(self):
        return len([p for p in self.properties if p.is_railroad])

    @property
    def properties(self):
        return self.__properties

    @property
    def deed_names(self):
        return [p.name for p in self.__properties]
    
    ##########
    @property
    def in_jail(self):
        return self.__in_jail
    
    @in_jail.setter
    def in_jail(self, value):
        self.__in_jail = value