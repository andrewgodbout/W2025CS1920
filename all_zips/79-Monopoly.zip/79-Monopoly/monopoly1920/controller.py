import os
import view
import random
import gameboard
import player as plr
import gamesquare
import observer
import tkinter as tk


class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):
        super().__init__()
        self.__root = root

        # Initialize timer first (before view)
        self.__timer_duration = 30
        self.__time_remaining = self.__timer_duration
        self.__timer_running = False
        self.__timer_id = None

        # Create timer label and pack it FIRST
        self.__timer_label = tk.Label(
            root,
            text=f"Time Left: {self.__time_remaining}s",
            font=("Arial", 14, "bold"),
            bg="lightgray",
            fg="black",
            relief=tk.RAISED,
            borderwidth=2
        )
        self.__timer_label.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)

        # Now initialize the view
        self._view = view.View(root)
        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()
        self.__dice_rolled = False
        self.__roll_count = 0

        # Pack view after timer
        self._view.main_frame.pack(fill=tk.BOTH, expand=True)

        # Initialize game state
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._set_expected_val()

        # Start first turn
        self.start_turn()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)

    def _create_players(self, num_players):
        """Prompt users for player names and create Player objects"""
        players = []
        for i in range(num_players):
            name = input(f"Enter name for Player {i + 1}: ")
            players.append(plr.Player(name, 1500))
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

    def _roll_dice(self):
        """Simulate rolling two dice"""
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Handle the roll dice button click event"""
        if self.__dice_rolled:
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        rent = player.pay_rent(square, dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        if player.money < 0:
            player.declare_bankrupt()

        return True

    # Timer Methods
    def start_turn(self):
        """Start a new turn with fresh timer"""
        if self.__timer_id:
            self.__root.after_cancel(self.__timer_id)

        self.__time_remaining = self.__timer_duration
        self.__timer_running = True
        self.__update_timer_display()
        self.__timer_id = self.__root.after(1000, self.__countdown)

    def __countdown(self):
        """Handle the timer countdown"""
        if not self.__timer_running:
            return

        self.__time_remaining -= 1
        self.__update_timer_display()

        if self.__time_remaining <= 0:
            self.__handle_timeout()
        else:
            self.__timer_id = self.__root.after(1000, self.__countdown)

    def __update_timer_display(self):
        """Update the timer label"""
        mins, secs = divmod(self.__time_remaining, 60)
        time_str = f"Time Left: {mins:02d}:{secs:02d}"

        if self.__time_remaining <= 10:
            color = "red"
        elif self.__time_remaining <= 20:
            color = "orange"
        else:
            color = "black"

        self.__timer_label.config(text=time_str, fg=color)

    def __handle_timeout(self):
        """Handle when time runs out"""
        self.__timer_running = False
        self.__timer_label.config(text="TIME'S UP!", fg="red")
        self.__root.after(1000, self.__force_end_turn)

    def __force_end_turn(self):
        """Forcefully end the current turn"""
        observer.Event("update_state", "Time expired! Ending turn...")
        self._end_turn(self.start_turn)

    def _end_turn(self, callback=None):
        """End the current turn and start next player's turn"""
        self.__timer_running = False
        if self.__timer_id:
            self.__root.after_cancel(self.__timer_id)
            self.__timer_id = None

        if not self.__dice_rolled:
            observer.Event("update_state", "Roll the dice first")
            return

        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()

        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)

        if callback:
            self.__root.after(2000, callback)

    # Game action methods
    def _buy_square(self, data):
        """Try to buy the current square"""
        if self.__roll_count == 0:
            observer.Event("update_state", "Roll the dice first")
            return

        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        if player.buy_property(square):
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Show mortgage options"""
        player = self._gameboard.get_current_player()
        observer.Event("choice", [d.name for d in player.properties if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        if player.mortgage_property(deed_name):
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"Failed to mortgage {deed_name}")

    def _unmortgage(self, data):
        """Unmortgage a property"""
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name:
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        """Handle button clicks"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        """Handle roll action"""
        player = self._gameboard.get_current_player()
        if not self._handle_roll_dice():
            return

        # Reset timer on successful roll
        self.__time_remaining = self.__timer_duration
        self.__update_timer_display()

        square = self._gameboard.get_square(player.position)
        observer.Event("update_state", f"{player.name} landed on {square}.")
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)