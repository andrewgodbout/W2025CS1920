import random

class Dice:
    def __init__(self):
        self.dice1 = 0
        self.dice2 = 0

    def roll(self):
        """Simulate the rolling of two dice and return the sum and whether it's a double."""
        self.dice1 = random.randint(1, 6)
        self.dice2 = random.randint(1, 6)
        dice_sum = self.dice1 + self.dice2
        is_double = self.dice1 == self.dice2
        return self.dice1, self.dice2, is_double  # dice1, dice2, is_double
