import tkinter as tk
import os
from logging import fatal
from tkinter import ttk
import controller
import observer

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 720
    height = 720

    def __init__(self,root,windowmode,message):
        self._root = root
        self.secondary_window = tk.Toplevel()
        self.secondary_window.title("Monopoly Start Up")
        self.secondary_window.config(width=self.width, height=self.height)
        self.secondary_window.geometry("600x400")
        self.secondary_window.resizable(False, False)
        self._playername1=tk.StringVar()
        self._playername2 = tk.StringVar()
        self._playername3 = tk.StringVar()
        self._playername4 = tk.StringVar()
        self._playercount = tk.StringVar()
        self._startcash = tk.StringVar()
        self._playername1.set("player 1")
        self._playername2.set("player 2")
        self._playername3.set("player 3")
        self._playername4.set("player 4")
        self._playercount.set(4)
        self._startcash.set(1500)
        # Create a button to close (destroy) this window.
        if windowmode == "startup":
            self._create_start_window()
        elif windowmode == "warning":
            self._create_warning_window(message)

    def _action_taken(self,action,ex):
        if action == "gamestart_stage1":
            print("gamestart_stage1 fired")
            observer.Event("updatename", str(0) + self._playername1.get())
            observer.Event("updatename", str(1) + self._playername2.get())
            observer.Event("updatename", str(2) + self._playername3.get())
            observer.Event("updatename", str(3) + self._playername4.get())
            observer.Event("updateplayercount", self._playercount.get())
            observer.Event("updatestartcash", self._startcash.get())
            observer.Event("gamestart_stage2",[False])
        if action == "startcheck":
            self._startcheck()
        if action == "closewindow":
            observer.Event("closewindow",self._closewindow(ex))
        if action == "loadgame":
            observer.Event("loadgame",'')
    def _create_start_window(self):
        button_close = ttk.Button(
            self.secondary_window,
            text="Start!",
            command=lambda: self._action_taken("startcheck",'')
        )
        button_load = ttk.Button(
            self.secondary_window,
            text="Load Game",
            command=lambda: self._action_taken("loadgame", '')
        )
        playername1_label = tk.Label(self.secondary_window, text='Player name 1', font=('calibre', 10, 'bold'))
        playername1_entry = tk.Entry(self.secondary_window, textvariable=self._playername1,
                                     font=('calibre', 10, 'normal'))
        playername2_label = tk.Label(self.secondary_window, text='Player name 2', font=('calibre', 10, 'bold'))
        playername2_entry = tk.Entry(self.secondary_window, textvariable=self._playername2,
                                     font=('calibre', 10, 'normal'))
        playername3_label = tk.Label(self.secondary_window, text='Player name 3', font=('calibre', 10, 'bold'))
        playername3_entry = tk.Entry(self.secondary_window, textvariable=self._playername3,
                                     font=('calibre', 10, 'normal'))
        playername4_label = tk.Label(self.secondary_window, text='Player name 4', font=('calibre', 10, 'bold'))
        playername4_entry = tk.Entry(self.secondary_window, textvariable=self._playername4,
                                     font=('calibre', 10, 'normal'))
        startmoney_label = tk.Label(self.secondary_window, text='Starting Fond', font=('calibre', 10, 'bold'))
        startmoney_entry = tk.Entry(self.secondary_window, textvariable=self._startcash,
                                     font=('calibre', 10, 'normal'))
        playercount_label = tk.Label(self.secondary_window, text='Player numbers', font=('calibre', 10, 'bold'))
        playercount_entry = tk.Entry(self.secondary_window, textvariable=self._playercount,
                                     font=('calibre', 10, 'normal'))
        playername1_label.grid(row=0, column=0)
        playername1_entry.grid(row=0, column=1)
        playername2_entry.grid(row=1, column=1)
        playername2_label.grid(row=1, column=0)
        playername3_entry.grid(row=2, column=1)
        playername3_label.grid(row=2, column=0)
        playername4_entry.grid(row=3, column=1)
        playername4_label.grid(row=3, column=0)
        playercount_entry.grid(row=4, column=1)
        playercount_label.grid(row=4, column=0)
        startmoney_label.grid(row=5, column=0)
        startmoney_entry.grid(row=5, column=1)
        button_close.grid(row=6, column=0)
        button_load.grid(row=7, column=0)
        #wip window with error message and close, lock other button?
    def _create_warning_window(self,message):
        warning_label = tk.Label(self.secondary_window, text=message, font=('calibre', 20, 'bold'),highlightcolor = 'red')
        button_close = ttk.Button(
            self.secondary_window,
            text="ok",
            command=lambda: self._action_taken("closewindow",self)
        )
        warning_label.grid(row=0, column=0)
        button_close.grid(row=0, column=1)
    def _startcheck(self):
        print("startcheck fired")
        passallcheck = True
        intlist = [self._playercount.get(),self._startcash.get()]
        print(intlist)
        for i in intlist:
            if not i.isnumeric():
                passallcheck = False
                errorwindow = View(self._root, "warning", "one of the field is not int")
                break
        print(passallcheck)
        playernamelist = [self._playername1.get(), self._playername2.get(), self._playername3.get(), self._playername4.get()]
        print(playernamelist)
        duplciatename = False
        nameset = set()
        if passallcheck:
            for i in range(0,int(self._playercount.get())):
                if playernamelist[i] in nameset:
                    duplciatename = True
                else:
                    nameset.add(playernamelist[i])
            if duplciatename:
                passallcheck = False
                errorwindow = View(self._root, "warning", "One or more player name is repeated")
        if passallcheck:
            if 1 > int(self._playercount.get()) > 4!= True:
                passallcheck = False
                errorwindow = View(self._root,"warning","Player Number should be 2-4")
            elif int(self._startcash.get())<0:
                passallcheck= False
                errorwindow = View(self._root, "warning", "Starting cash should be >0")
        if passallcheck:
            print('all check passed')
            self._closewindow(self)
            self._action_taken("gamestart_stage1", '')
    def _closewindow(self,win):
        if win == self:
            self.secondary_window.destroy()