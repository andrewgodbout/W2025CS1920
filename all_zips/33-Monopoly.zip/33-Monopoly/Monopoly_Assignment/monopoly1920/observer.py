import logging

logging.basicConfig(level=logging.INFO)

class Observer:
    """Observer class to represent an observer that can observe events."""
    _observers = []

    def __init__(self):
        """Constructor for the Observer class."""
        self._observers.append(self)
        self._observables = {}
        logging.info("Observer created and registered.")

    def observe(self, event_name, callback):
        """Function to observe an event.
        :param event_name: The name of the event to observe.
        :param callback: The function to call when the event occurs.
        """
        if event_name not in self._observables:
            self._observables[event_name] = []
        self._observables[event_name].append(callback)
        logging.info(f"Observer registered for event: {event_name}")

    def unobserve(self, event_name, callback):
        """Function to remove a specific observer from an event."""
        if event_name in self._observables:
            self._observables[event_name].remove(callback)
            if not self._observables[event_name]:
                del self._observables[event_name]
            logging.info(f"Observer unregistered from event: {event_name}")

    def clear_observables(self):
        """Function to clear all event listeners."""
        self._observables.clear()
        logging.info("All observables cleared.")

    @property
    def observables(self):
        return self._observables

    @staticmethod
    def get_observers():
        """Function to get all observers."""
        return Observer._observers

    @staticmethod
    def remove_observer(observer):
        """Function to remove an observer from the list."""
        if observer in Observer._observers:
            Observer._observers.remove(observer)
            logging.info("Observer removed.")


class Event:
    """Event class to represent an event that can be observed."""

    def __init__(self, event_name, data=None):
        """Constructor for the Event class."""
        self.__name = event_name
        self.__data = data
        logging.info(f"Event created: {self.__name}")
        self.notify()

    def notify(self):
        """Function to fire the event."""
        for observer in Observer.get_observers():
            if self.__name in observer.observables:
                for callback in observer.observables[self.__name]:
                    callback(self.__data)