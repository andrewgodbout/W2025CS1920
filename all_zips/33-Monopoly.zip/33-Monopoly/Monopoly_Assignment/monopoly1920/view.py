import tkinter as tk
import os
from tkinter import ttk
import controller
import observer


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

def get_token_images():
    """return a dictionary mapping player tokens to image file paths"""
    tokens = {
        "car": "resources/images/tokens/car.png",
        "hat": "resources/images/tokens/hat.png",
        "dog": "resources/images/tokens/dog.png",
        "shoe": "resources/images/tokens/shoe.png"
    }
    return tokens

class View(observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1280
    height = 720

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.token_images = {}  # Store player token images
        self.token_labels = {}  # Store token label references
        self.root = root
        root.title("Monopoly 1920")

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(False, False)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        # Create the frames
        logo_frame = self._create_logo_frame()  # Create the logo frame
        middle_frame = self._create_middle_frame()  # Create the middle frame
        msg_frame = self._create_msg_frame()  # Create the message frame

        # Pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)
        self.observe("move_token", self.update_token_position)

    def _create_logo_frame(self):
        """Create the logo frame for the GUI"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        logo_label = ttk.Label(logo_frame, text="Monopoly 1920", font=("Arial", 24))
        logo_label.pack()
        return logo_frame

    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # Preload tokens
        self._preload_tokens()

        card_image = self.images[0] if self.images else None
        if card_image:
            self.card = ttk.Label(middle_frame, image=card_image)
            self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
            self.card.image = card_image

        return middle_frame

    def _preload_tokens(self):
        """Load player token images"""
        token_paths = get_token_images()
        for token, path in token_paths.items():
            self.token_images[token] = tk.PhotoImage(file=path)

    def add_player_token(self, player_name, token_name, position):
        """Add a player's token to the board"""
        token_label = ttk.Label(self.main_frame, image=self.token_images[token_name])
        token_label.place(x=position[0], y=position[1])  # Position needs mapping to board
        self.token_labels[player_name] = token_label

    def update_token_position(self, player_name, new_position):
        """Move the player's token to a new position"""
        if player_name in self.token_labels:
            self.token_labels[player_name].place(x=new_position[0], y=new_position[1])

# Launch the GUI
if __name__ == '__main__':
    root = tk.Tk()
    controller = controller.Controller(root)
    root.mainloop()
