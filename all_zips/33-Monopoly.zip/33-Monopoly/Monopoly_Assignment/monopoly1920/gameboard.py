import player
import gamesquare
import random


class GameBoard:
    __boardCSV = {
        "name": 0,
        "space": 1,
        "color": 2,
        "position": 3,
        "price": 4,
        "build": 5,
        "rent": 6,
        "rent1": 7,
        "rent2": 8,
        "rent3": 9,
        "rent4": 10,
        "rent5": 11,
        "hotelcost": 12,
        "owner": 13,
        "houses": 14,
        "groupmembers": 15
    }

    CHANCE_CARDS = [
        "Advance to Go (Collect $200)",
        "Bank error in your favor. Collect $75",
        "Go to Jail. Go directly to jail, do not pass Go, do not collect $200",
        "Your building loan matures. Collect $150"
    ]

    COMMUNITY_CHEST_CARDS = [
        "Doctor's fees. Pay $50",
        "From sale of stock you get $50",
        "Get Out of Jail Free",
        "Pay hospital fees of $100"
    ]

    def __init__(self, properties_path, players):
        self.__properties = self._load_game_board(properties_path)
        self.__players = players
        self.__total_turns = 0
        self.__current_player = self.__players.pop(0)
        self.__jail = set()

    def next_turn(self):
        if not self.__current_player.bankrupt_declared:
            self.__players.append(self.__current_player)
        self.__total_turns += 1
        self.__current_player = self.__players.pop(0)
        return self.__current_player.name

    def send_to_jail(self, player):
        self.__jail.add(player)
        player.position = 10  # Jail position

    def draw_chance_card(self):
        return random.choice(self.CHANCE_CARDS)

    def draw_community_chest_card(self):
        return random.choice(self.COMMUNITY_CHEST_CARDS)

    def auction_property(self, property):
        highest_bid = 0
        highest_bidder = None
        for p in self.__players:
            if not p.bankrupt_declared:
                bid = random.randint(0, p.cash)  # Simulated bid
                if bid > highest_bid:
                    highest_bid = bid
                    highest_bidder = p
        if highest_bidder:
            highest_bidder.cash -= highest_bid
            property.owner = highest_bidder
        return highest_bidder, highest_bid

    def _load_game_board(self, csv_path):
        properties = []
        with open(csv_path, "r") as f:
            next(f)  # Skip header
            for line in f:
                line = line.strip().split(",")
                utility = line[self.__boardCSV["space"]] == "Utility"
                railroad = line[self.__boardCSV["space"]] == "Railroad"
                sq = gamesquare.GameSquare(
                    name=line[self.__boardCSV["name"]],
                    price=int(line[self.__boardCSV["price"]]),
                    rent=int(line[self.__boardCSV["rent"]]),
                    color=line[self.__boardCSV["color"]],
                    is_utility=utility, is_railroad=railroad, space=line[self.__boardCSV["space"]]
                )
                properties.append(sq)
        return properties

    def __str__(self):
        board_str = "player - cash - net worth - position\n"
        board_str += f"{self.__current_player} {self.get_board_square(self.__current_player.position).name}\n"
        for player in self.__players:
            if player.bankrupt_declared:
                board_str += f"{player.name} declared bankruptcy\n"
                continue
            board_str += f"{player} {self.get_board_square(player.position).name}\n"
        return board_str
