import os
import view
import random
import gameboard
import player as plr  # avoid naming conflict with the player module
import gamesquare
import observer
from tkinter import simpledialog
from datetime import datetime
class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)

        self._add_listeners()

        self.__dice_rolled = False

        self.__roll_count = 0

        # JAIL FEATURE FORCE TEST
        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        # observer.Event("update_state_box", str(self._gameboard))

        # Test: Uncomment this code to test that jail feature works
        self._gameboard.players[0].send_to_jail()  # Force Player 0 into jail
        # observer.Event("update_state", "TEST: Player 0 sent to jail")
        observer.Event("update_state_box", str(self._gameboard))

        self._set_expected_val()

        # ADDING SAVE/LOAD GAMES TO A FILE FEATURE
        # Create saves directory if needed
        self.save_dir = "game_states"
        os.makedirs(self.save_dir, exist_ok=True)  # Creates folder if doesn't exist

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        # ADDING SAVE/LOAD GAMES TO A FILE FEATURE
        self.observe("save_game", self._save_game_action)
        self.observe("load_game", self._load_game_action)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            # player = plr.Player(f"Player {i}", 1500)
            name = simpledialog.askstring("Name Setup", f"Player {i + 1}: Kindly enter your username")
            if name:
                player = plr.Player(name, money=1500)
                players.append(player)
            else:
                print("Player name cannot be empty.")
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        player = self._gameboard.get_current_player()

        # ADDING JAIL FEATURE
        if player._is_in_jail:
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            observer.Event("update_state", f"Jail roll: {dice1} + {dice2}")

            # Escape by paying $50 if after 3 turns, no doubles
            if player._turns_in_jail >= 2:
                observer.Event("update_state", f"{player.name} (Turn 3 / 3).")
                observer.Event("update_state", f"{player.name} has run out of turns, pays $50 to leave jail.")
                observer.Event("update_state", f"{player.name} rolls again.")
                player.money -= 50
                player._is_in_jail = False
                player._turns_in_jail(0)

                self.__dice_rolled = True
                return False

            # Escape in a case of doubles rolled
            elif player.attempt_to_escape(dice1, dice2):
                observer.Event("update_state", f"{player.name} rolled doubles and can leave jail!")

                #move the player
                player.move(dice1 + dice2)
                position = player.position
                square = self._gameboard.get_square(position)

            else:
                observer.Event("update_state", f"{player.name} stays in jail (Turn {player._turns_in_jail}/3).")

            self.__dice_rolled = True
            return False  # End turn after jail attempt

        dice_sum = self._roll_dice()

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        if square.space == "GotoJail":
            jail_square = self._gameboard.get_square(10)  # Jail position
            jail_square.send_to_jail(player)
            observer.Event("update_state", f"{player.name} was sent to jail!")
            self.__dice_rolled = True
            return False  # End turn

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")

        self._set_expected_val()

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if (self.__roll_count == 0):
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state",f"Square bought: {square}" )
        else:
            observer.Event("update_state",f"Square not bought: {square}" )

        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))

    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))

    # ADDING SAVE/LOAD GAMES TO A FILE FEATURE
    def _save_game_action(self, data):
        """Handle save game request from UI"""
        self.save_game()
        observer.Event("update_state_box", str(self._gameboard))

    def _load_game_action(self, data):
        """Handle load game request from UI"""
        self.load_game()
        observer.Event("update_state_box", str(self._gameboard))

    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    # ADDING SAVE/LOAD GAMES TO A FILE FEATURE
    def save_game(self, filename=None):
        """Saves all game data (with timestamps) including:
        - Player money
        - Positions
        - Jail status
        - Turns spent in jail
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y-%m-%d_at_%H.%M.%S")  # Format: 2025-03-28_at_15.32.36
            filename = os.path.join(self.save_dir, f"monopoly_save_{timestamp}.txt")
        try:
            with open(filename, 'w') as f:
                # Save game metadata
                f.write(f"current_player:{self._gameboard.get_current_player().name}\n")
                f.write(f"total_turns:{self._gameboard._GameBoard__total_turns}\n")

                # Save all players' data
                for player in [self._gameboard.get_current_player()] + self._gameboard.players:
                    # Basic player info
                    f.write(f"player:{player.name},{player.money},{player.position},")
                    f.write(f"{player._is_in_jail},{player._turns_in_jail}\n")

                    # Save properties
                    for prop in player.properties:
                        f.write(f"property:{player.name},{prop.name},{prop.is_mortgaged}\n")

            observer.Event("update_state", f"Game saved successfully to {filename}")
            return True
        except Exception as e:
            observer.Event("update_state", f"Error saving game: {str(e)}")
            return False

    def load_game(self, filename=None):
        """Loads game state from file"""
        try:
            if not filename:
                # Find most recent save file
                saves = [f for f in os.listdir(self.save_dir)
                         if f.startswith("monopoly_save_") and f.endswith(".txt")]
                if not saves:
                    observer.Event("update_state", "No saved games found")
                    return False
                filename = os.path.join(self.save_dir, max(saves))  # Gets most recent

            with open(filename, 'r') as f:
                # Reset all properties to no owner first
                for square in self._gameboard.get_all_squares():
                    if hasattr(square, 'owner'):
                        square.owner = None
                        square.__is_mortgaged = False  # Reset mortgage status

                current_player_name = None
                total_turns = 0

                for line in f.readlines():
                    line = line.strip()
                    if not line:  # Skip empty lines
                        continue

                    try:
                        if line.startswith("current_player:"):
                            current_player_name = line.split(":")[1].strip()
                        elif line.startswith("total_turns:"):
                            total_turns = int(line.split(":")[1].strip())
                        elif line.startswith("player:"):
                            # player:name,money,position,in_jail,turns_in_jail
                            parts = line[len("player:"):].split(",")
                            if len(parts) >= 5:  # Ensure we have all required parts
                                name = parts[0].strip()
                                money = int(parts[1].strip())
                                pos = int(parts[2].strip())
                                in_jail = parts[3].strip() == "True"
                                turns = int(parts[4].strip())

                                player = next((p for p in self._gameboard.players if p.name == name), None)
                                if player:
                                    player.money = money
                                    player.position = pos
                                    player._is_in_jail = in_jail
                                    player._turns_in_jail = turns
                                    # Clear existing properties before loading
                                    player._Player__properties = []
                                    player._Player__utility_count = 0
                                    player._Player__railroad_count = 0
                        elif line.startswith("property:"):
                            # property:player_name,prop_name,is_mortgaged
                            parts = line[len("property:"):].split(",")
                            if len(parts) >= 3:  # Ensure we have all required parts
                                player_name = parts[0].strip()
                                prop_name = parts[1].strip()
                                is_mortgaged = parts[2].strip() == "True"

                                player = next((p for p in self._gameboard.players if p.name == player_name), None)
                                if player:
                                    prop = next((p for p in self._gameboard.get_all_squares()
                                                 if hasattr(p, 'name') and p.name == prop_name), None)
                                    if prop:
                                        prop.owner = player
                                        player._Player__properties.append(prop)
                                        prop.__is_mortgaged = is_mortgaged
                                        # Update utility/railroad counts
                                        if prop.is_utility:
                                            player._Player__utility_count += 1
                                        elif prop.is_railroad:
                                            player._Player__railroad_count += 1
                    except (ValueError, IndexError) as e:
                        observer.Event("update_state", f"Warning: Skipping malformed line: {line}")
                        continue

                # Set current player
                if current_player_name:
                    players = self._gameboard.players
                    current_index = next((i for i, p in enumerate(players)
                                          if p.name == current_player_name), 0)
                    # Rotate players list so current player is first
                    players = players[current_index:] + players[:current_index]
                    self._gameboard._GameBoard__players = players[1:]  # All but current
                    self._gameboard._GameBoard__current_player = players[0]
                    self._gameboard._GameBoard__total_turns = total_turns

                observer.Event("update_state", f"Game loaded from {filename}")
                observer.Event("update_state_box", str(self._gameboard))
                observer.Event("update_card", self._gameboard.get_current_player().position)
                return True

        except Exception as e:
            observer.Event("update_state", f"Error loading game: {str(e)}")
            return False
    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)






