import json
import os
import controller
import observer

from flask import Flask, render_template, redirect, request, session
from flask_socketio import SocketIO, Namespace, send, emit


app = Flask(__name__)
app.secret_key = "c1c4ac9e43a917d35bc7781fa16da19031f082052f29f1f96b1e5ec374e6c360"
socketio = SocketIO(app)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/game")
def play_game():
    hat = request.args.get("hat", "")
    thimble = request.args.get("thimble", "")
    iron = request.args.get("iron", "")
    shoe = request.args.get("shoe", "")

    player_names: list[str] = []
    tokens_used: list[str] = []

    if hat != "":
        player_names.append(hat)
        tokens_used.append("hat")

    if thimble != "":
        player_names.append(thimble)
        tokens_used.append("thimble")

    if iron != "":
        player_names.append(iron)
        tokens_used.append("iron")

    if shoe != "":
        player_names.append(shoe)
        tokens_used.append("shoe")

    if len(player_names) < 2:
        return render_template(
            "index.html",
            error="We need atleast 2 players to play monopoly",
            hat=hat,
            thimble=thimble,
            iron=iron,
            shoe=shoe,
        )

    session["player_names"] = player_names
    session["tokens_used"] = tokens_used
    return render_template("game.html")


class WebSocket(Namespace):
    def on_connect(self):
        self.controller = controller.Controller(self, session["player_names"])
        print("connected")

    def on_disconnect(self, reason): ...

    def on_message(self, data):
        self.controller.view.action_taken(data)


class View(observer.Observer):
    """Class to create the GUI for the Monopoly game"""

    def __init__(self, ws):
        super().__init__()

        self.ws = ws

        self._add_listeners()

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state", self._update_text)
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("choice", self._choose)

    def _update_text(self, info):
        emit("toast", info)
        print(f"Toast: {info}")

    def update_state_box(self, info):
        player_tokens: dict[str, str] = {
            session["player_names"][i]: session["tokens_used"][i]
            for i in range(len(session["tokens_used"]))
        }

        emit("currentState", {"info": info, "player_tokens": player_tokens})

    def update_card(self, position):
        emit("newPosition", position)

    def _choose(self, deeds):
        emit("mortgagableDeeds", deeds)

    def action_taken(self, action):
        if action == "roll":
            # tell the controller roll was clicked
            # print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)

        if action == "end_turn":
            observer.Event("end_turn", None)


"""launch the GUI"""
if __name__ == "__main__":
    socketio.on_namespace(WebSocket("/ws"))
    socketio.run(app, debug=True)
