import tkinter as tk
import os
from tkinter import ttk, simpledialog, messagebox
import controller
import observer


def get_board_square_images():
    """return a List of all the file paths for the board square images"""
    square_images = []
    for i in range(40):
        path = os.path.join("resources", "images", "properties", f"{i}.png")
        square_images.append(path)
    return square_images

class View (observer.Observer):
    """Class to create the GUI for the Monopoly game"""
    width = 1440
    height = 900

    def __init__(self, root):
        super().__init__()
        # Set-up a simple window
        self.images = []
        self.root = root
        root.title("Monopoly 1920")

        #tight coupling with the controller
        #not ideal, but we will refactor later
        #self.controller = controller

        root.geometry(f'{self.width}x{self.height}')
        root.resizable(True, True)

        self.main_frame = ttk.Frame(root, padding=10, relief='groove')

        #create the frames
        logo_frame = self._create_logo_frame()
        middle_frame = self._create_middle_frame()
        msg_frame = self._create_msg_frame()

        #pack the frames
        logo_frame.pack(fill=tk.BOTH, expand=True)
        middle_frame.pack(fill=tk.BOTH, expand=False)
        msg_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._add_listeners()

        #Feature_2: Timer
        self.timer_label = ttk.Label(logo_frame, text="Time Left: 120", font=('Helvetica', 14))
        self.timer_label.pack(side='top', anchor='ne')

        self.timer_canvas = tk.Canvas(logo_frame, width=200, height=20, bg='white')
        self.timer_canvas.pack(side='top', anchor='ne', pady=(0, 10))
        self.timer_bar = self.timer_canvas.create_rectangle(0, 0, 200, 20, fill='green')


        #Feature_3: Dices
        self.dice_frame = ttk.Frame(self.main_frame)
        self.dice_frame.pack(side='bottom', pady=10)  # Position at bottom

        # Load dice images with proper sizing
        self.dice_images = []
        for i in range(1, 7):
            try:
                img = tk.PhotoImage(file=f"resources/images/Dices/dice-{i}.png")
                img = img.subsample(6, 6)  # Reduce size by 4x
                self.dice_images.append(img)
            except:
                # Fallback: create colored rectangles
                img = tk.PhotoImage(width=30, height=30)
                self.dice_images.append(img)

        # Create dice labels with proper sizing
        self.dice_label1 = ttk.Label(self.dice_frame, width=5)
        self.dice_label2 = ttk.Label(self.dice_frame, width=5)
        self.dice_label1.pack(side='left', padx=5)
        self.dice_label2.pack(side='left', padx=5)

        # Initialize with blank dice
        self.update_dice((0, 0))  # 0 will show blank

        #Feature_5: Console/Message box Modifications
        self.width = 1400
        self.height = 900
        root.geometry(f'{self.width}x{self.height}')

    # Feature_1: Ability to add number of players and player names.
    def get_number_of_players(self):
        """Show dialog to get number of players"""
        num_players = simpledialog.askinteger(
            "Number of Players",
            "How many players? (2-8)",
            parent=self.root,
            minvalue=2,
            maxvalue=8
        )
        return num_players

    def get_player_names(self, num_players):
        """Show dialogs to get each player's name (accepts any input)"""
        player_names = []
        for i in range(1, num_players + 1):
            name = simpledialog.askstring(
                f"Player {i} Name",
                f"Enter name for Player {i}:",
                parent=self.root
            )
            if name is None:
                return None
            player_names.append(name)
        return player_names

    #Feature_2: An in-game timer to limit players turn to 2 minutes.

    def update_timer(self, seconds_left):
        """Simplified timer update with basic color change"""
        # Update the time display (in seconds)
        self.timer_label.config(text=f"Time Left: {seconds_left}s")

        # Calculate progress bar width (0-200 pixels)
        progress_width = (seconds_left / 120) * 200
        self.timer_canvas.coords(self.timer_bar, 0, 0, progress_width, 20)

        if seconds_left > 80:
            color = "green"
        elif seconds_left > 40:
            color = "yellow"
        else:
            color = "red"

        self.timer_canvas.itemconfig(self.timer_bar, fill=color)

        # Flash when time is very low
        if seconds_left <= 10:
            self.timer_label.config(foreground='red')
        else:
            self.timer_label.config(foreground='black')

    #Feature_3: Dices
    def update_dice(self, dice_values):
        """Update dice display with proper sizing"""
        dice1, dice2 = dice_values

        # Show blank if value is 0, otherwise show corresponding dice
        img1 = self.dice_images[dice1 - 1] if dice1 > 0 else None
        img2 = self.dice_images[dice2 - 1] if dice2 > 0 else None

        self.dice_label1.config(image=img1)
        self.dice_label2.config(image=img2)
        self.dice_label1.image = img1
        self.dice_label2.image = img2

    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("update_state_box", self.update_state_box)
        self.observe("update_card", self.update_card)
        self.observe("update_state", self._update_text)
        self.observe("choice", self._choose)


    def _create_middle_frame(self):
        """Create the middle frame of the GUI"""
        middle_frame = ttk.Frame(self.main_frame, padding=10)
        board_image = tk.PhotoImage(file=r"resources/images/monopoly.png")
        board = ttk.Label(middle_frame, image=board_image)
        board.pack(side='left', anchor='n', padx=75)
        board.image = board_image

        # preload all the images for the board squares
        self._preload_images()

        card_image = self.images[0]
        self.card = ttk.Label(middle_frame, image=card_image)

        button_frame = ttk.Frame(middle_frame, padding=10)

        #create buttons
        self.mid_buttons = []
        self.roll_button = ttk.Button(button_frame, text="Roll Dice", command=lambda: self._action_taken("roll") )
        self.roll_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.roll_button)

        self.purchase_button = ttk.Button(button_frame, text="Purchase", command=lambda: self._action_taken("purchase"))
        self.purchase_button.pack(side='top', anchor='center', pady=(10, 10))
        self.purchase_button.state(['active'])
        self.mid_buttons.append(self.purchase_button)

        self.mortgage_button = ttk.Button(button_frame, text="Mortgage", command=lambda: self._action_taken("mortgage"))
        self.mortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mortgage_button.state(['active'])
        self.mid_buttons.append(self.mortgage_button)

        self.unmortgage_button = ttk.Button(button_frame, text="Unmortgage", command=lambda: self._action_taken("unmortgage"))
        self.unmortgage_button.pack(side='top', anchor='center', pady=(10, 10))
        self.unmortgage_button.state(['active'])
        self.mid_buttons.append(self.unmortgage_button)

        self.bankrupt_button = ttk.Button(button_frame, text="Go Bankrupt", command=lambda: self._action_taken("bankrupt"))
        self.bankrupt_button.pack(side='top', anchor='center', pady=(10, 10))
        self.bankrupt_button.state(['active'])
        self.mid_buttons.append(self.bankrupt_button)

        self.end_turn_button = ttk.Button(button_frame, text="End Turn", command=lambda: self._action_taken("end_turn"))
        self.end_turn_button.pack(side='top', anchor='center', pady=(10, 10))
        self.end_turn_button.state(['active'])
        self.mid_buttons.append(self.end_turn_button)

        self.suggest_button = ttk.Button(button_frame, text="Suggest Move",
                                         command=lambda: self._action_taken("suggest"))
        self.suggest_button.pack(side='top', anchor='center', pady=(10, 10))
        self.mid_buttons.append(self.suggest_button) #Feature_4: Suggestion button

        button_frame.pack(side='left', anchor='center', pady=(0, 0), padx=50)

        self.card.pack(side='left', anchor='n', padx=100, pady=(100, 0))
        self.card.image = card_image

        return middle_frame

    def _create_msg_frame(self):
        """Create the frame at the bottom of the screen to display messages"""
        msg_frame = ttk.Frame(self.main_frame, padding=10, relief='raised', borderwidth=3)

    #Feature_5: Console/Message box modifications
        self.state_box = tk.Text(msg_frame,
                                 width=80,
                                 height=15,
                                 background='black',
                                 foreground='white',
                                 font=('Consolas', 10))
        self.state_box.pack(side='left', fill='both', expand=True, padx=(20, 10))

        # Main message box (game log) - make significantly larger
        self.text_box = tk.Text(msg_frame,
                                width=80,
                                height=15,
                                background='black',
                                foreground='white',
                                font=('Consolas', 10))
        self.text_box.pack(side='left', fill='both', expand=True, padx=(10, 20))

        for box in [self.state_box, self.text_box]:
            scrollbar = ttk.Scrollbar(box)
            scrollbar.pack(side='right', fill='y')
            box.config(yscrollcommand=scrollbar.set)
            scrollbar.config(command=box.yview)

        return msg_frame

    def _create_logo_frame(self):
        """Create the frame at the top of the screen to display the logo"""
        logo_frame = ttk.Frame(self.main_frame, padding=10)
        # load a logo resource
        logo_image = tk.PhotoImage(file=r"resources/images/monopoly_logo.png")
        logo = ttk.Label(logo_frame, image=logo_image)
        logo.pack(side='top', anchor='n')
        logo.image = logo_image

        return logo_frame

    def _action_taken(self, action):

        if action == "roll":
            #tell the controller roll was clicked
            print("roll clicked")
            observer.Event("roll", None)

        if action == "purchase":
            observer.Event("purchase", None)

        if action == "mortgage":
            observer.Event("mortgage", None)

        if action == "unmortgage":
            observer.Event("unmortgage", None)

        if action == "mortgage_specific":
            observer.Event("mortgage_specific", 0)

        if action == "end_turn":
            #self.text_box.delete(1.0, tk.END)
            observer.Event("end_turn", self._clear_text)

        if action == "suggest":
            observer.Event("suggest_move", None)

    def update_state(self, state, text):
        """Function to update the state of the game"""
        if state == "roll":
            self._await_roll(text)
        elif state == "purchase":
            self._await_purchase()
        elif state == "moves":
            self._await_moves()
        elif state == "moves_or_bankrupt":
            self._await_moves_or_bankrupt()

    def purchase(self):
        observer.Event("purchase", None)

    def update_card(self, index):
        card_image = self.images[index]
        try:
            self.card['image'] = card_image
        except:
            pass

    def _clear_text(self):
        print("clearing text")
        self.text_box.delete(1.0, tk.END)

    def _update_text(self, text=""):
        #self.text_box.delete(1.0, tk.END)
        self.text_box.insert(tk.END, text+"\n")

    def update_state_box(self, text=""):
        self.state_box.delete(1.0, tk.END)
        self.state_box.insert(tk.END, text)

    def _choose(self, choices):
        #good idea disable all buttons

        self.popup_menu = tk.Menu(self.root,
                                       tearoff=0)

        for c in choices:
            self.popup_menu.add_command(label=c,
                                        command=lambda ch=c: self.pick(ch))
        self.popup_menu.add_separator()

        lbl = "Cancel"
        if len(choices) == 0:
                lbl = "No properties to mortgage (click to cancel)"

        self.popup_menu.add_command(label=lbl,
                                    command=self.popup_menu.grab_release)
        try:
            self.popup_menu.tk_popup(600, 300, 0)
        finally:
            self.popup_menu.grab_release()

    def pick(self, s):
        observer.Event("mortgage_specific", s)



    def _preload_images(self):
        '''Function to preload all the images for the board squares'''
        square_images = get_board_square_images()
        for image in square_images:
            img = tk.PhotoImage(file=image)
            self.images.append(img)

'''launch the GUI'''
if __name__ == '__main__':

    free_parking_payout = 0
    players_in_jail_collect = True
    property_auctions = False
    root = tk.Tk()

    controller = controller.Controller(root)

    root.mainloop()

