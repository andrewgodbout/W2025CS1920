import pygame
import sys

class PygameTimer:
    def __init__(self, time_limit):
        pygame.init()
        self.screen = pygame.display.set_mode((200, 100))  # Small window for the timer
        pygame.display.set_caption("Monopoly Timer")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)  # Default font, size 36
        self.time_limit = time_limit
        self.time_remaining = time_limit

    def update(self, time_remaining):
        """Update the timer display"""
        self.time_remaining = time_remaining
        self.screen.fill((0, 0, 0))  # Clear the screen with black
        timer_text = self.font.render(f"Time: {self.time_remaining}", True, (255, 255, 255))  # White text
        self.screen.blit(timer_text, (50, 30))  # Position the text
        pygame.display.flip()  # Update the display

    def close(self):
        """Close the Pygame window"""
        pygame.quit()