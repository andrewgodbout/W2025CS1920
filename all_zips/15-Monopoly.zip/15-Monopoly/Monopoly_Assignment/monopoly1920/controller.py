import os
import view
import random
import gameboard
import player as plr # avoid naming conflict with the player module
import gamesquare
import observer
import json
from tkinter import messagebox


class Controller(observer.Observer):
    """Control the game flow"""

    def __init__(self, root):

        #for now we have references to the backend and frontend objects
        #tight coupling is not ideal, but we will refactor later
        super().__init__()
        self._view = view.View(root)
        self._root = root
        self.__dice_rolled = False
        self.__roll_count = 0
        self.__game_initialized = False
        self._gameboard = None
        self._players = []
        self._add_listeners()

        csv_path = os.path.join("resources", "data", "board.csv")
        players = self._create_players(3)
        self._gameboard = gameboard.GameBoard(csv_path, players)
        self.__game_initialized = True


        self.__dice_rolled = False

        self.__roll_count = 0

        observer.Event("update_state", f"{self._gameboard.get_current_player().name}'s turn")
        observer.Event("update_state_box", str(self._gameboard))
        self._update_player_tokens()

        self._set_expected_val()


    def _add_listeners(self):
        """Add listeners to the view"""
        self.observe("roll", self._roll_action)
        self.observe("end_turn", self._end_player_turn)
        self.observe("purchase", self._buy_square)
        self.observe("mortgage", self._mortgage)
        self.observe("mortgage_specific", self._mortgage_specific)
        self.observe("unmortgage", self._unmortgage)
        self.observe("pay_jail", self._pay_jail_fine)
        self.observe("save_game", self._save_game)
        self.observe("load_game", self._load_game)

    def _update_player_tokens(self):
        positions = {}
        for player in self._gameboard.get_all_players():
            positions[player.name] = (player.position, player.token)
        observer.Event("update_tokens", positions)

    def _test_observers(self, data):
        """Test the observer pattern"""
        print("observed event roll")

    def _create_players(self, num_players):
        """Create num_players players and return a list of them"""
        players = []
        for i in range(num_players):
            player = plr.Player(f"Player {i}", 1500)
            players.append(player)
        return players

    def _set_expected_val(self):
        ev = self._gameboard.calculate_expected_value(self._gameboard.get_current_player().position, 0)
        ev = round(ev, 2)
        observer.Event("update_state", f"Expected value: {ev}")

        player = self._gameboard.get_current_player()
        # add the expected value to the player's luck
        player.luck += ev

    def _roll_dice(self):
        """Simulate the rolling of two dice
            :return the sum of two random dice values
        """
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        dice_sum = dice1 + dice2

        self.__dice_rolled = True
        self.__roll_count += 1

        if dice1 == dice2:
            #double rolled
            observer.Event("update_state", f"Doubles rolled: {dice1}+{dice2} = {dice_sum}")
            self.__dice_rolled = False
        else:
            observer.Event("update_state", f"Dice rolled: {dice1} + {dice2} = {dice_sum}")
        return dice1, dice2, dice_sum

    def _handle_roll_dice(self):
        """Function to handle the roll dice button click event"""

        if self.__dice_rolled and not self._gameboard.get_current_player().in_jail:
            #only one roll per turn
            observer.Event("update_state", "One roll per turn or Doubles required")
            return False

        dice_sum = self._roll_dice()
        player = self._gameboard.get_current_player()

        if player.in_jail:
            if not self._handle_jail(player):
                return False

        if not player.in_jail:
            observer.Event("update_state", f"Dice rolled: {dice_sum}")
        else:
            player.doubles_count += 1
            if player.doubles_count == 3:
                observer.Event("update_state", "Three doubles! Go to jail!")
                player.go_to_jail()
                self._update_player_tokens()
                return True

        #move the player
        player.move(dice_sum)
        position = player.position
        square = self._gameboard.get_square(position)

        if square.space == "GoToJail":
            player.go_to_jail()
            observer.Event("update_state", "Go to Jail!")

        #pay the rent
        #should check if the player has money and if not
        #give them the chance to trade or mortgage
        rent = player.pay_rent(square,dice_sum)
        if rent != 0:
            print(f"rent paid: {rent}")
            player.luck -= rent
            observer.Event("update_state", f"Rent paid: {rent}")

        #no money left?
        if player.money < 0:
            player.declare_bankrupt()

        return True

    def _handle_jail(self, player, dice1, dice2):
        if dice1 == dice2:
            player.in_jail = False
            observer.Event("update_state", "You rolled doubles and got out of jail!")
            return True
        return False

    def _end_player_turn(self, callback):
        """End the current player's turn"""

        if not self.__dice_rolled and not self._gameboard.get_current_player().in_jail:
            #player must roll the dice first
            observer.Event("update_state", "Roll the dice first")
            return
        self.__dice_rolled = False
        self.__roll_count = 0
        player_name = self._gameboard.next_turn()
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", self._gameboard.get_current_player().position)
        callback()
        observer.Event("update_state", f"{player_name}'s turn")
        self._update_player_tokens()
        current_player = self._gameboard.get_current_player()

        if current_player.is_ai and not current_player.bankrupt_declared:
            self._handle_ai_turn()
        self._set_expected_val()

    def _handle_ai_turn(self):
        player = self._gameboard.get_current_player()

        if player.in_jail:
            if random.random() < 0.5:
                self._pay_jail_fine(None)
            else:
                self._roll_action(None)
            return

        self._roll_action(None)
        square = self._gameboard.get_square(player.position)
        if square.can_be_purchased() and player.money > square.price:
            self._buy_square(None)

        self._root.after(1500, lambda: observer.Event("end_turn", self._view._clear_text))



    def _mortgage(self, data):
        """Player has indicated an interest in mortgaging a property
        return their choices as a list of names"""
        player = self._gameboard.get_current_player()
        deeds = player.properties
        # only return the deeds that can be mortgaged
        observer.Event("choice", [d.name for d in deeds if not d.is_mortgaged])
        observer.Event("update_state_box", str(self._gameboard))


    def _mortgage_specific(self, deed_name):
        """Mortgage a specific property"""
        player = self._gameboard.get_current_player()
        res = player.mortgage_property(deed_name)
        print(deed_name)
        if res:
            observer.Event("update_state", f"{deed_name} mortgaged")
        else:
            observer.Event("update_state", f"attempt to mortgage {deed_name} failed")

    def _unmortgage(self, data):
        """Player has indicated an interest in unmortgaging a property
            they must unmortgage in a FIFO order
        """
        player = self._gameboard.get_current_player()
        deed_name = player.unmortgage_property()
        if deed_name != "":
            observer.Event("update_state", f"Unmortgaged: {deed_name}")
            observer.Event("update_state_box", str(self._gameboard))


    def button_clicked(self, button):
        """Handle View button click events"""
        print(f"Button clicked: {button}")
        self._roll_action(None)

    def _roll_action(self, data):
        player = self._gameboard.get_current_player()

        if not self._handle_roll_dice():
            return

        square = self._gameboard.get_square(player.position)
        money = player.money

        msg = f"{player.name} landed on {square}."

        observer.Event("update_state", msg)
        observer.Event("update_state_box", str(self._gameboard))
        observer.Event("update_card", player.position)

        if square.can_be_purchased() and square.owner is None and not player.is_ai:
            observer.Event("offer_auction", square)

    def _buy_square(self, data):
        """try to buy the square the active player is currently on"""

        if self.__roll_count == 0 and not self._gameboard.get_current_player().in_jail:
            observer.Event("update_state", "Roll the dice first")
            return
        player = self._gameboard.get_current_player()
        position = player.position
        square = self._gameboard.get_square(player.position)
        buy = player.buy_property(square)
        if buy:
            print(f"Square bought {square}")
            observer.Event("update_state", f"Square bought: {square}")
        else:
            observer.Event("update_state", f"Square not bought: {square}")

        if not square.can_be_purchased():
            observer.Event("update_state", "Property cannot be purchased")
            return

        observer.Event("update_state_box", str(self._gameboard))

    def _start_auction(self, square):
        players = [p for p in self._gameboard.get_all_players() if not p.bankrupt_declared]
        if len(players) < 2:
            observer.Event("update_state", "Not enough players for auction")
            return

        winner = None
        highest_bid = square.price // 2
        for player in players:
            bid = random.randint(highest_bid, highest_bid + 200)
            if bid > highest_bid and bid <= player.money:
                highest_bid = bid
                winner = player

        if winner:
            winner.money -= highest_bid
            winner.buy_property(square)
            observer.Event("update_state", f"{winner.name} won auction for {square.name} with ${highest_bid}")
        observer.Event("update_state_box", str(self._gameboard))

    def _pay_jail_fine(self, data):
        player = self._gameboard.get_current_player()
        if player.money >= 50:
            player.money -= 50
            player.in_jail = False
            observer.Event("update_state", "Paid $50 to get out of jail")
            self._update_player_tokens()

    def _save_game(self, filename):
        game_state = {
            'players': [{
                'name': p.name,
                'money': p.money,
                'position': p.position,
                'properties': [prop.name for prop in p.properties],
                'in_jail': p.in_jail,
                'token': p.token,
                'is_ai': p.is_ai
            } for p in self._gameboard.get_all_players()],
            'current_player_index': self._gameboard.get_total_turns()}

        try:
            with open(filename, 'w') as f:
                json.dump(game_state, f)
            observer.Event("update_state", "Game saved successfully")
        except Exception as e:
            observer.Event("update_state", f"Error saving game: {str(e)}")

    def _load_game(self, filename):
        try:
            with open(filename, 'r') as f:
                game_state = json.load(f)

            players = []
            for p_data in game_state['players']:
                player = plr.Player(
                    p_data['name'],
                    p_data['money'],
                    p_data['token'],
                    p_data['is_ai']
                )
                player.board_position = p_data['position']
                player.in_jail = p_data['in_jail']
                players.append(player)

            csv_path = os.path.join("resources", "data", "board.csv")
            self._gameboard = gameboard.GameBoard(csv_path, players)
            self._gameboard.set_total_turns(game_state['total_turns'])

            

        for p_data in game_state['players']:
            player = next(p for p in players if p.name == p_data['name'])
            for prop_name in p_data['properties']:
                prop = next(p for p in self._gameboard.get_all_squares() if p.name == prop_name)
                prop.owner = player
                player.properties.append(prop)

        self.__game_initialized = True
        observer.Event("update_state", "Game loaded successfully")
        observer.Event("update_state_box", str(self._gameboard))
        self._update_player_tokens()








